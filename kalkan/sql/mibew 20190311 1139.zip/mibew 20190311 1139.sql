﻿--
-- Скрипт сгенерирован Devart dbForge Studio for MySQL, Версия 8.0.108.0
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 11.03.2019 11:39:17
-- Версия сервера: 5.5.46
-- Версия клиента: 4.1
--

-- 
-- Отключение внешних ключей
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- Установить режим SQL (SQL mode)
-- 
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 
-- Установка кодировки, с использованием которой клиент будет посылать запросы на сервер
--
SET NAMES 'utf8';

DROP DATABASE IF EXISTS mibew;

CREATE DATABASE mibew
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Установка базы данных по умолчанию
--
USE mibew;

--
-- Создать таблицу `visitedpagestatistics`
--
CREATE TABLE visitedpagestatistics (
  pageid int(11) NOT NULL AUTO_INCREMENT,
  date int(11) NOT NULL DEFAULT 0,
  address varchar(1024) DEFAULT NULL,
  visits int(11) NOT NULL DEFAULT 0,
  chats int(11) NOT NULL DEFAULT 0,
  sentinvitations int(11) NOT NULL DEFAULT 0,
  acceptedinvitations int(11) NOT NULL DEFAULT 0,
  rejectedinvitations int(11) NOT NULL DEFAULT 0,
  ignoredinvitations int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (pageid)
)
ENGINE = INNODB,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать таблицу `visitedpage`
--
CREATE TABLE visitedpage (
  pageid int(11) NOT NULL AUTO_INCREMENT,
  address varchar(1024) DEFAULT NULL,
  visittime int(11) NOT NULL DEFAULT 0,
  visitorid int(11) DEFAULT NULL,
  calculated tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (pageid)
)
ENGINE = INNODB,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать индекс `visitorid` для объекта типа таблица `visitedpage`
--
ALTER TABLE visitedpage
ADD INDEX visitorid (visitorid);

--
-- Создать таблицу `translation`
--
CREATE TABLE translation (
  translationid int(11) NOT NULL AUTO_INCREMENT,
  locale varchar(5) NOT NULL,
  context varchar(256) NOT NULL DEFAULT '',
  source text binary CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  translation text DEFAULT NULL,
  hash char(40) NOT NULL,
  PRIMARY KEY (translationid)
)
ENGINE = INNODB,
AUTO_INCREMENT = 758,
AVG_ROW_LENGTH = 224,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать индекс `hash` для объекта типа таблица `translation`
--
ALTER TABLE translation
ADD UNIQUE INDEX hash (hash);

--
-- Создать таблицу `threadstatistics`
--
CREATE TABLE threadstatistics (
  statid int(11) NOT NULL AUTO_INCREMENT,
  date int(11) NOT NULL DEFAULT 0,
  threads int(11) NOT NULL DEFAULT 0,
  missedthreads int(11) NOT NULL DEFAULT 0,
  sentinvitations int(11) NOT NULL DEFAULT 0,
  acceptedinvitations int(11) NOT NULL DEFAULT 0,
  rejectedinvitations int(11) NOT NULL DEFAULT 0,
  ignoredinvitations int(11) NOT NULL DEFAULT 0,
  operatormessages int(11) NOT NULL DEFAULT 0,
  usermessages int(11) NOT NULL DEFAULT 0,
  averagewaitingtime float(10, 1) NOT NULL DEFAULT 0.0,
  averagechattime float(10, 1) NOT NULL DEFAULT 0.0,
  PRIMARY KEY (statid)
)
ENGINE = INNODB,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать таблицу `thread`
--
CREATE TABLE thread (
  threadid int(11) NOT NULL AUTO_INCREMENT,
  username varchar(64) NOT NULL,
  userid varchar(255) DEFAULT NULL,
  agentname varchar(64) DEFAULT NULL,
  agentid int(11) NOT NULL DEFAULT 0,
  dtmcreated int(11) NOT NULL DEFAULT 0,
  dtmchatstarted int(11) NOT NULL DEFAULT 0,
  dtmmodified int(11) NOT NULL DEFAULT 0,
  dtmclosed int(11) NOT NULL DEFAULT 0,
  lrevision int(11) NOT NULL DEFAULT 0,
  istate int(11) NOT NULL DEFAULT 0,
  invitationstate int(11) NOT NULL DEFAULT 0,
  ltoken int(11) NOT NULL,
  remote varchar(255) DEFAULT NULL,
  referer text DEFAULT NULL,
  nextagent int(11) NOT NULL DEFAULT 0,
  locale varchar(8) DEFAULT NULL,
  lastpinguser int(11) NOT NULL DEFAULT 0,
  lastpingagent int(11) NOT NULL DEFAULT 0,
  usertyping int(11) DEFAULT 0,
  agenttyping int(11) DEFAULT 0,
  shownmessageid int(11) NOT NULL DEFAULT 0,
  useragent varchar(255) DEFAULT NULL,
  messagecount varchar(16) DEFAULT NULL,
  groupid int(11) DEFAULT NULL,
  PRIMARY KEY (threadid)
)
ENGINE = INNODB,
AUTO_INCREMENT = 85,
AVG_ROW_LENGTH = 1771,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать таблицу `sitevisitor`
--
CREATE TABLE sitevisitor (
  visitorid int(11) NOT NULL AUTO_INCREMENT,
  userid varchar(255) NOT NULL,
  username varchar(64) DEFAULT NULL,
  firsttime int(11) NOT NULL DEFAULT 0,
  lasttime int(11) NOT NULL DEFAULT 0,
  entry text NOT NULL,
  details text NOT NULL,
  invitations int(11) NOT NULL DEFAULT 0,
  chats int(11) NOT NULL DEFAULT 0,
  threadid int(11) DEFAULT NULL,
  PRIMARY KEY (visitorid)
)
ENGINE = INNODB,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать индекс `threadid` для объекта типа таблица `sitevisitor`
--
ALTER TABLE sitevisitor
ADD INDEX threadid (threadid);

--
-- Создать таблицу `revision`
--
CREATE TABLE revision (
  id int(11) NOT NULL
)
ENGINE = INNODB,
AVG_ROW_LENGTH = 16384,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать таблицу `requestcallback`
--
CREATE TABLE requestcallback (
  callbackid int(11) NOT NULL AUTO_INCREMENT,
  token varchar(64) NOT NULL DEFAULT '',
  function varchar(64) NOT NULL,
  arguments varchar(1024) DEFAULT NULL,
  PRIMARY KEY (callbackid)
)
ENGINE = INNODB,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать индекс `token` для объекта типа таблица `requestcallback`
--
ALTER TABLE requestcallback
ADD INDEX token (token);

--
-- Создать таблицу `requestbuffer`
--
CREATE TABLE requestbuffer (
  requestid int(11) NOT NULL AUTO_INCREMENT,
  requestkey char(32) NOT NULL,
  request text NOT NULL,
  PRIMARY KEY (requestid)
)
ENGINE = INNODB,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать индекс `requestkey` для объекта типа таблица `requestbuffer`
--
ALTER TABLE requestbuffer
ADD INDEX requestkey (requestkey);

--
-- Создать таблицу `plugin`
--
CREATE TABLE plugin (
  id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(255) NOT NULL,
  version varchar(255) NOT NULL,
  installed tinyint(4) NOT NULL DEFAULT 0,
  enabled tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
)
ENGINE = INNODB,
AUTO_INCREMENT = 3,
AVG_ROW_LENGTH = 8192,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать индекс `name` для объекта типа таблица `plugin`
--
ALTER TABLE plugin
ADD UNIQUE INDEX name (name);

--
-- Создать таблицу `opgroup`
--
CREATE TABLE opgroup (
  groupid int(11) NOT NULL AUTO_INCREMENT,
  parent int(11) DEFAULT NULL,
  vcemail varchar(64) DEFAULT NULL,
  vclocalname varchar(64) NOT NULL,
  vccommonname varchar(64) NOT NULL,
  vclocaldescription varchar(1024) NOT NULL,
  vccommondescription varchar(1024) NOT NULL,
  iweight int(11) NOT NULL DEFAULT 0,
  vctitle varchar(255) DEFAULT '',
  vcchattitle varchar(255) DEFAULT '',
  vclogo varchar(255) DEFAULT '',
  vchosturl varchar(255) DEFAULT '',
  PRIMARY KEY (groupid)
)
ENGINE = INNODB,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать индекс `parent` для объекта типа таблица `opgroup`
--
ALTER TABLE opgroup
ADD INDEX parent (parent);

--
-- Создать таблицу `operatortoopgroup`
--
CREATE TABLE operatortoopgroup (
  groupid int(11) NOT NULL,
  operatorid int(11) NOT NULL
)
ENGINE = INNODB,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать индекс `groupid` для объекта типа таблица `operatortoopgroup`
--
ALTER TABLE operatortoopgroup
ADD INDEX groupid (groupid);

--
-- Создать индекс `operatorid` для объекта типа таблица `operatortoopgroup`
--
ALTER TABLE operatortoopgroup
ADD INDEX operatorid (operatorid);

--
-- Создать таблицу `operatorstatistics`
--
CREATE TABLE operatorstatistics (
  statid int(11) NOT NULL AUTO_INCREMENT,
  date int(11) NOT NULL DEFAULT 0,
  operatorid int(11) NOT NULL,
  threads int(11) NOT NULL DEFAULT 0,
  messages int(11) NOT NULL DEFAULT 0,
  averagelength float(10, 1) NOT NULL DEFAULT 0.0,
  sentinvitations int(11) NOT NULL DEFAULT 0,
  acceptedinvitations int(11) NOT NULL DEFAULT 0,
  rejectedinvitations int(11) NOT NULL DEFAULT 0,
  ignoredinvitations int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (statid)
)
ENGINE = INNODB,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать индекс `operatorid` для объекта типа таблица `operatorstatistics`
--
ALTER TABLE operatorstatistics
ADD INDEX operatorid (operatorid);

--
-- Создать таблицу `operator`
--
CREATE TABLE operator (
  operatorid int(11) NOT NULL AUTO_INCREMENT,
  vclogin varchar(64) NOT NULL,
  vcpassword varchar(64) NOT NULL,
  vclocalename varchar(64) NOT NULL,
  vccommonname varchar(64) NOT NULL,
  vcemail varchar(64) DEFAULT NULL,
  dtmlastvisited int(11) NOT NULL DEFAULT 0,
  istatus int(11) DEFAULT 0,
  idisabled int(11) DEFAULT 0,
  vcavatar varchar(255) DEFAULT NULL,
  iperm int(11) DEFAULT 0,
  dtmrestore int(11) NOT NULL DEFAULT 0,
  vcrestoretoken varchar(64) DEFAULT NULL,
  code varchar(64) DEFAULT '',
  PRIMARY KEY (operatorid)
)
ENGINE = INNODB,
AUTO_INCREMENT = 5,
AVG_ROW_LENGTH = 5461,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать таблицу `message`
--
CREATE TABLE message (
  messageid int(11) NOT NULL AUTO_INCREMENT,
  threadid int(11) NOT NULL,
  ikind int(11) NOT NULL,
  agentid int(11) NOT NULL DEFAULT 0,
  tmessage text NOT NULL,
  plugin varchar(256) NOT NULL DEFAULT '',
  data text DEFAULT NULL,
  dtmcreated int(11) NOT NULL DEFAULT 0,
  tname varchar(64) DEFAULT NULL,
  PRIMARY KEY (messageid)
)
ENGINE = INNODB,
AUTO_INCREMENT = 357,
AVG_ROW_LENGTH = 292,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать индекс `idx_agentid` для объекта типа таблица `message`
--
ALTER TABLE message
ADD INDEX idx_agentid (agentid);

--
-- Создать таблицу `mailtemplate`
--
CREATE TABLE mailtemplate (
  templateid int(11) NOT NULL AUTO_INCREMENT,
  locale varchar(5) NOT NULL,
  name varchar(256) NOT NULL,
  subject varchar(1024) NOT NULL,
  body text DEFAULT NULL,
  PRIMARY KEY (templateid)
)
ENGINE = INNODB,
AUTO_INCREMENT = 7,
AVG_ROW_LENGTH = 2730,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать таблицу `locale`
--
CREATE TABLE locale (
  localeid int(11) NOT NULL AUTO_INCREMENT,
  code varchar(5) NOT NULL,
  name varchar(128) NOT NULL DEFAULT '',
  enabled tinyint(4) NOT NULL DEFAULT 0,
  rtl tinyint(4) NOT NULL DEFAULT 0,
  time_locale varchar(128) NOT NULL DEFAULT 'en_US',
  date_format text DEFAULT NULL,
  PRIMARY KEY (localeid)
)
ENGINE = INNODB,
AUTO_INCREMENT = 3,
AVG_ROW_LENGTH = 8192,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать индекс `code` для объекта типа таблица `locale`
--
ALTER TABLE locale
ADD UNIQUE INDEX code (code);

--
-- Создать таблицу `config`
--
CREATE TABLE config (
  id int(11) NOT NULL AUTO_INCREMENT,
  vckey varchar(255) DEFAULT NULL,
  vcvalue varchar(255) DEFAULT NULL,
  PRIMARY KEY (id)
)
ENGINE = INNODB,
AUTO_INCREMENT = 42,
AVG_ROW_LENGTH = 399,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать таблицу `cannedmessage`
--
CREATE TABLE cannedmessage (
  id int(11) NOT NULL AUTO_INCREMENT,
  locale varchar(8) DEFAULT NULL,
  groupid int(11) DEFAULT NULL,
  vctitle varchar(100) NOT NULL DEFAULT '',
  vcvalue varchar(1024) NOT NULL,
  PRIMARY KEY (id)
)
ENGINE = INNODB,
AUTO_INCREMENT = 7,
AVG_ROW_LENGTH = 2730,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать таблицу `ban`
--
CREATE TABLE ban (
  banid int(11) NOT NULL AUTO_INCREMENT,
  dtmcreated int(11) NOT NULL DEFAULT 0,
  dtmtill int(11) NOT NULL DEFAULT 0,
  address varchar(255) DEFAULT NULL,
  comment varchar(255) DEFAULT NULL,
  PRIMARY KEY (banid)
)
ENGINE = INNODB,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать таблицу `availableupdate`
--
CREATE TABLE availableupdate (
  id int(11) NOT NULL AUTO_INCREMENT,
  target varchar(255) NOT NULL,
  version varchar(255) NOT NULL,
  url text DEFAULT NULL,
  description text DEFAULT NULL,
  PRIMARY KEY (id)
)
ENGINE = INNODB,
CHARACTER SET utf8,
COLLATE utf8_general_ci;

--
-- Создать индекс `target` для объекта типа таблица `availableupdate`
--
ALTER TABLE availableupdate
ADD UNIQUE INDEX target (target);

-- 
-- Вывод данных для таблицы visitedpagestatistics
--
-- Таблица mibew.visitedpagestatistics не содержит данных

-- 
-- Вывод данных для таблицы visitedpage
--
-- Таблица mibew.visitedpage не содержит данных

-- 
-- Вывод данных для таблицы translation
--
INSERT INTO translation VALUES
(1, 'en', '', 'Login', 'Login', '4bbe80d6a352d3b14306395152e8554cc051fab4'),
(2, 'en', '', 'Mibew Messenger', 'Mibew Messenger', '64937a11a6473ddf3959d47a94780e1fca004b13'),
(3, 'en', '', 'Mibew Messenger is an open-source live support application.', 'Mibew Messenger is an open-source live support application.', 'e696dcd4d7d23a25ecf637d0e783a256829a7549'),
(4, 'en', '', 'Please enter your username and password to access administrative tools. See your visitors and browse the history.', 'Please enter your username and password to access administrative tools. See your visitors and browse the history.', '01758847b98ce87945408301ce611baa3a4b5fd5'),
(5, 'en', '', 'Login:', 'Login:', '9ad96d5767ee09d9d289a53f8288046ca0bff675'),
(6, 'en', '', 'Password:', 'Password:', 'f8268e113267ffffa02d84fcd3784713760b4642'),
(7, 'en', '', 'Remember', 'Remember', 'd03676fbe38b9915d32c08b15e11271caeb88b00'),
(8, 'en', '', 'Enter', 'Enter', 'd34e71f02efc1421de501d108f30c4f92a9dc412'),
(9, 'en', '', 'Forgot your password?', 'Forgot your password?', 'dee79161438828a2e756733d805788e2898479ff'),
(10, 'en', '', 'Home', 'Home', '6ea90287aa1b99cdd26dc2e40bd770d83fc41474'),
(11, 'en', '', 'You are Offline. <a href="{0}">Connect...</a>', 'You are Offline. <a href="{0}">Connect...</a>', '05c020a682181f6cef30bc2b149e11b2b95f80ed'),
(12, 'en', '', 'Visitors', 'Visitors', '222329d0c99234199c3804a864fce8eeb0c0a0e6'),
(13, 'en', '', 'You can find awaiting visitors.', 'You can find awaiting visitors.', 'b3dbd11be9a38125bba1237825ec1c6a99907e62'),
(14, 'en', '', 'Chat history', 'Chat history', '1e5c94d90f5e085a84301c60aca3c195d19bfdcd'),
(15, 'en', '', 'Search the dialogs history.', 'Search the dialogs history.', 'da5a772dc4f06052eff80e1b129ac0363f296674'),
(16, 'en', '', 'Statistics', 'Statistics', '0e6949e282daea98284ab2c0a832ed306c25af45'),
(17, 'en', '', 'From this page you can generate a variety of usage reports.', 'From this page you can generate a variety of usage reports.', 'ec28057e666d64e475fb01a90df27d725cf90233'),
(18, 'en', '', 'Canned Messages', 'Canned Messages', '6f221ca5a612bae1440e82a78454f5e71237ff0f'),
(19, 'en', '', 'Edit messages that you frequently type into the chat.', 'Edit messages that you frequently type into the chat.', '38a9363b326bbd08b71724e9d566c1037afe83c7'),
(20, 'en', '', 'Button code', 'Button code', '10f3be16c5f8d4deb831d0c2ac9c62cc61b82eed'),
(21, 'en', '', 'Button HTML code generation.', 'Button HTML code generation.', 'baf7de8b35399eb18308839abb50ed3686cfc2ac'),
(22, 'en', '', 'Operators', 'Operators', 'eb392969311f52ed5576471798054d9b9b3b1aac'),
(23, 'en', '', 'Create or delete company operators. Manage their permissions.', 'Create or delete company operators. Manage their permissions.', '559e5d353924ae8481807e4964cc26b79922970e'),
(24, 'en', '', 'Groups', 'Groups', 'df509d26179cad04c267493253b267a3a4603464'),
(25, 'en', '', 'Department or skill based groups.', 'Department or skill based groups.', '59bc1033661eb0d579e3a8aeb30795464d869544'),
(26, 'en', '', 'Settings', 'Settings', '5c2c3e4c018079e8ec36a9a608e8902bee903a3e'),
(27, 'en', '', 'Specify options affecting chat window and common system behavior.', 'Specify options affecting chat window and common system behavior.', '32e1ac138e4c4fe391951a462b03aed38a286454'),
(28, 'en', '', 'Plugins', 'Plugins', '808910ff4e1fc12001727a9e7d9cbd09c75846d9'),
(29, 'en', '', 'Manage plugins.', 'Manage plugins.', 'bf49027b485a1a22716614d4e514d207027586cf'),
(30, 'en', '', 'Styles', 'Styles', '5a72705443ac823880b67f399db27a9080c546ed'),
(31, 'en', '', 'Manage styles.', 'Manage styles.', 'f8a017082a43f9803830b54427d6b7e917ee664b'),
(32, 'en', '', 'Translations', 'Translations', 'efa0400cf2dabf90d8cf1d5f05e001df0a1d1d7a'),
(33, 'en', '', 'Manage translations.', 'Manage translations.', '1fd900d31da48ea04a3eeea0235f5fc33b5f248d'),
(34, 'en', '', 'Mail templates', 'Mail templates', '26b24d27311745235590b0b7fb804fe6eeb16ee9'),
(35, 'en', '', 'Manage mail templates.', 'Manage mail templates.', '70d18d3c1c723329bbd8a7cc94f7586727a3c9f6'),
(36, 'en', '', 'Profile', 'Profile', '3b3c56a4bf5ba7b66be6007f2e1d2c2829d2010b'),
(37, 'en', '', 'You can change your personal information on this page.', 'You can change your personal information on this page.', 'd79dbe164bcee51e79f9c7e8c692606114a8fd1e'),
(38, 'en', '', 'About', 'About', 'ea12bf665baffd9b90a3e2380d15027414a18822'),
(39, 'en', '', 'View about page.', 'View about page.', '88b632c78b123828d5700e8e2fbc9d05de8e4ddd'),
(40, 'en', '', 'Exit', 'Exit', '07e3503243f267d7d143d565fb0ab96faabc614b'),
(41, 'en', '', 'Log out of the system.', 'Log out of the system.', 'ab16b23a9d913204b9cb9de087f435503ececb7b'),
(42, 'en', '', 'You are <a href="{0}">{1}</a>', 'You are <a href="{0}">{1}</a>', '6a4e3359334b052accfe7c50efb25a73b988205b'),
(43, 'en', '', 'List of visitors waiting', 'List of visitors waiting', '3e25be3121147dd0c178ce8c81aabec8ff778c68'),
(44, 'en', '', 'Main', 'Main', 'd2d280598ea751741ee53cb19c7d0d32bd77db2e'),
(45, 'en', '', 'without menu', 'without menu', '814d5b31164020fa863f3a05d87ed4bf33febdba'),
(46, 'en', '', 'Administration', 'Administration', '2fc1e3ebed7fc8cb53f2b95a268e415b3fc3dc90'),
(47, 'en', '', 'Localize', 'Localize', '24067053494d4284dc0ea0a46a2086bcc95a2745'),
(48, 'en', '', 'Other', 'Other', 'fb9e50806ebbb7e65ab021f06150e4ed5f04143d'),
(49, 'en', '', 'Show menu', 'Show menu', '3801a7e24332bce889d2e168cd1d9bc77185d790'),
(50, 'en', '', 'This page displays a list of visitors who are waiting.', 'This page displays a list of visitors who are waiting.', 'a72b3800e7919fc3eaad259522f0f4cb780b896c'),
(51, 'en', '', 'To answer the visitor click their name in the list.', 'To answer the visitor click their name in the list.', '07b633c4ed5dc18217e986934c55e263c9e7f92e'),
(52, 'en', '', 'Messenger settings', 'Messenger settings', '326baafac85362582e216c8c2292c957d63b2b79'),
(53, 'en', '', 'General', 'General', '1da1f10d482816613237eeaebd072729d4add618'),
(54, 'en', '', 'Optional Services', 'Optional Services', 'e33fa803d44cc6d65539607bb7b030636949ad61'),
(55, 'en', '', 'Performance', 'Performance', '6fd7022fba9c81edf91bf8b92d85f55254f01b07'),
(56, 'en', '', 'Email', 'Email', '4f8443d2cca6d437ea2c17372fb535f467cd7a25'),
(57, 'en', '', 'Enter an email to receive system messages', 'Enter an email to receive system messages', 'f28cb8456c6cbcfeddc4d7adb1d14863c56cf03c'),
(58, 'en', '', 'Language of the messages left by visitors', 'Language of the messages left by visitors', '13f205ddb7ce79256234d9f8b35db0387d183a02'),
(59, 'en', '', 'Language of the messages that could be left by visitors when operators aren''t available', 'Language of the messages that could be left by visitors when operators aren''t available', '2e8801f00d6b08ae6889ce439fe4e8f76a651cfc'),
(60, 'en', '', 'Company title', 'Company title', '4239e06ba09c228fde8af72a29f408e3c04ad4a3'),
(61, 'en', '', 'Enter your company title', 'Enter your company title', 'c266a4fc1878e3f44b7630c272784a77628ceab6'),
(62, 'en', '', 'Title in the chat window', 'Title in the chat window', '8afbe12222758cd36f2d044efd51d0fcb58712b9'),
(63, 'en', '', 'Name of your company for example.', 'Name of your company for example.', '42ef41bc19344c65bc6a510ef597bac126de1ba8'),
(64, 'en', '', 'Your company logo', 'Your company logo', '9fe43e24efea046a8a7f3ea7d51227f6b1879fce'),
(65, 'en', '', 'Enter http address of your company logo', 'Enter http address of your company logo', 'f9a1e7f38de99d502bf060e8a47b91ec50e6c1db'),
(66, 'en', '', 'URL of your website', 'URL of your website', 'f0d8314b0b8ebd321a6ad03c6ed736a022ec9f98'),
(67, 'en', '', 'Destination for your company name or logo link', 'Destination for your company name or logo link', '5175f6400084abb8d671bae5a9ce3a688f274a2f'),
(68, 'en', '', 'Link to an external geolocation service', 'Link to an external geolocation service', '19433f7990be95ee562ce7a493e64b9048f84266'),
(69, 'en', '', 'Each IP becomes a link opening in a new window. {ip} is substituted with a real IP.', 'Each IP becomes a link opening in a new window. {ip} is substituted with a real IP.', '9deff99c59127090a78ab9a862f13858b40a996f'),
(70, 'en', '', 'Geolocation window options', 'Geolocation window options', 'eacde188060f15508d746378419a67772ec460a5'),
(71, 'en', '', 'Window size and toolbars hiding', 'Window size and toolbars hiding', 'b92f16bb08f0b583395e116e03e46c3d3f547576'),
(72, 'en', '', 'Visitor''s identifier', 'Visitor''s identifier', 'ec87e4a565db96c285113e84d2eed0e3335be525'),
(73, 'en', '', 'How to build visitor''s identifying string from {name}, {id} or {addr}. Default: {name}', 'How to build visitor''s identifying string from {name}, {id} or {addr}. Default: {name}', 'b4cf6dc5fd0d3e8e1c821a5c570954b29c419f97'),
(74, 'en', '', 'Cron security key', 'Cron security key', 'a223eb2dd705b0ebb8a2c63e602e2c74886afa49'),
(75, 'en', '', 'To run cron use link <a href="{0}">{0}</a>.', 'To run cron use link <a href="{0}">{0}</a>.', '660f5acf03036baf2c1d8a692534ee57b66512f7'),
(76, 'en', '', 'Select a style for your operator pages', 'Select a style for your operator pages', '8896343fe44e7077ebd870082ce55fa1089b3c9b'),
(77, 'en', '', 'A preview for each style is available <a href="{0}">here</a>', 'A preview for each style is available <a href="{0}">here</a>', '124d35dab0e1ee27871078c1e3abfeaf268e0256'),
(78, 'en', '', 'Select a style for your chat windows', 'Select a style for your chat windows', '5c65a14c721affbb9451a9ab006f0019661b4a87'),
(79, 'en', '', 'A preview all pages for each style is available <a href="{0}">here</a>', 'A preview all pages for each style is available <a href="{0}">here</a>', '8e788fbe51cd31c59ea86b1cec378ba3ee5207d3'),
(80, 'en', '', 'Send messages with:', 'Send messages with:', '483e3d5ecc2f5c7c1ec2fea09a5e1f08afd1272b'),
(81, 'en', '', 'Save', 'Save', 'cdfd4ce7480514a5b6b0cbbf96ac5b65ff17c6a9'),
(82, 'en', '', 'mandatory fields', 'mandatory fields', '0a45ca97a62fe325c3bd384003885662fe47ac97'),
(83, 'en', '', 'Changes saved', 'Changes saved', 'b56d5d1c041df295b2dc420fd6b0636048e0946c'),
(84, 'en', '', 'Source string', 'Source string', '5455d7334fcd49485c5cf07b853d84abb3965e3c'),
(85, 'en', '', 'Translation', 'Translation', 'a636b5f6c9b3c43444aec24b25dc14df706a1998'),
(86, 'en', '', 'Translations import', 'Translations import', '1dc353a9be0054bbd609b074c944002c5e847035'),
(87, 'en', '', 'Translations export', 'Translations export', '8ea73eccbed4f38a9b228f6a54309c5e8f0b25da'),
(88, 'en', '', 'Locales', 'Locales', 'd0e069c05cb021671de5f0f5f5289dd58bd89ffd'),
(89, 'en', '', 'If you don''t agree with the translation please send us an update.', 'If you don''t agree with the translation please send us an update.', 'b41bf59f54ae7798d0f037c2cac401171492851f'),
(90, 'en', '', 'For language:', 'For language:', '6bb6ef3c9e198294f5a5bf50f006fd6315399bb3'),
(91, 'en', '', 'Sort by:', 'Sort by:', 'a77d229951748761abca30628eb97f0a51162b56'),
(92, 'en', '', 'Page {0} of {1}, {2}-{3} from {4}', 'Page {0} of {1}, {2}-{3} from {4}', 'a481eee4fa50638e241976d82338a8d3972d1c31'),
(93, 'en', '', 'On this page you can upload a custom translation file.', 'On this page you can upload a custom translation file.', 'b9c21e3a0519aeed119508e4c1711151930136e0'),
(94, 'en', '', 'Override existing translations', 'Override existing translations', '62fe1f0f9fcc8a9ff6025ecbb4c98bc31b92e379'),
(95, 'en', '', 'Replaces translated strings in the database with values from the imported file.', 'Replaces translated strings in the database with values from the imported file.', '44e377b1324dcc59da287cc57d51a1f187dbc2d2'),
(96, 'en', '', 'Upload translation', 'Upload translation', '496c0244df540dc4251c5be116303b5a080bc252'),
(97, 'en', '', 'Choose the translation file to upload.', 'Choose the translation file to upload.', 'dd3306217ac687e9305ba42488c60bbb8668818b'),
(98, 'en', '', 'Upload', 'Upload', '1fec1d3f4939edd9a13e4fdf307ed6004b15c66e'),
(99, 'en', '', 'On this page you can download translations.', 'On this page you can download translations.', '608c954cb9c17e5554766af1b4f72f267e80e073'),
(100, 'en', '', 'Download', 'Download', 'fecdb37c6b89274f9725df1261dbd2a796bfa856'),
(101, 'en', '', 'On this page you can configure locales which are used in the system', 'On this page you can configure locales which are used in the system', 'aaa735f3ad92dbe45d925e2c8f58028e358c40d5'),
(102, 'en', '', 'Code', 'Code', '97c7d8beffb4d8d33cf755933b61488c1bacbc28'),
(103, 'en', '', 'Name', 'Name', '8c1fed8336cfce2e0cae79ee7ba8d1d2579edcb1'),
(104, 'en', '', 'Modify', 'Modify', 'a7d41da68e65df309f8866a61e0425d507a50e9a'),
(105, 'en', '', 'disable', 'disable', '86435b15406050d52c6409bcb963d3ae7626f303'),
(106, 'en', '', 'edit', 'edit', '35927abffce80dc9209150f0cd05535320d5a7ed'),
(107, 'en', '', 'enable', 'enable', 'da73036a7782b0978b040ee3cce2d8c2141a0c5f'),
(108, 'ru', '', '"Mail is sent" window', '"Mail is sent" window', 'f8f8fc2e1ac60ef30f0a6985713fcc197587ca24'),
(109, 'ru', '', '"Max number of threads" field should be a number', 'Поле "Максимальное количество диалогов" должно быть числом', 'ad162f32484ced285b96f4c0e52f210816fac00e'),
(110, 'ru', '', '"Message is delivered" window', '"Message is delivered" window', 'dbc3705c0b20bea1f7f9801cb7b54134a15f4e11'),
(111, 'ru', '', '"Thread lifetime" field should be a number', 'Поле "Время жизни диалога" должно быть числом', '38fced503c2faf109be61b622a313bdc2e26b559'),
(112, 'ru', '', '"Visitor is redirected" window', '"Visitor is redirected" window', '1f1f835e664e346965b57df94833325f0c4b86ed'),
(113, 'ru', '', '&lt;no description&gt;', '&lt;без описания&gt;', '567a08b5f7313dcb647a1c94d580ad324bbfafa0'),
(114, 'ru', '', '(away)', '(отошел)', '447ad1cbe54c77fee5c70f448e03b4cd3738bb25'),
(115, 'ru', '', '(online)', '(доступен)', '69408c74ae6d767ed080278f4846afccc5b4a5b2'),
(116, 'ru', '', '-all operators-', '-все операторы-', 'dddbef9ab803d2fb31dd4a225a8176e6f4463e5e'),
(117, 'ru', '', '-from general settings-', '-из настроек сайта-', 'c9d1bea78ee8f7129e4d5d5d7745a15f145bd096'),
(118, 'ru', '', '-none-', '-нет-', '98c45a89199c6c4d92a5c9e7bb9c7a5f5085360a'),
(119, 'ru', '', '-not found-', '-не найден-', '5353d47d1fc105e753aa31160e54cabbc477c9f5'),
(120, 'ru', '', '0 allows any number of connections', '0 разрешает любое количество соединений', 'a81771fe2fb18e01ccca6d52892b69ab51892c68'),
(121, 'ru', '', '<b>Application installed successfully.</b>', '<b>Установка успешно завершена. </b>', 'db95b609dfa76c60b1227a5259990645541c13d4'),
(122, 'ru', '', '<strong>Caution!</strong> Please don''t change<br/> the code manually because<br/> we don''t guarantee that<br/> it will work!', '<strong>Внимание!</strong> При внесении<br/> каких-либо изменений<br/> в этот код работоспособность<br/> кнопки не гарантируется!', '0cd9002a99bf4e71516d5a2a23ba9d3cd6402613'),
(123, 'ru', '', '{0} plugin', 'Плагин {0}', 'eede3a1d0491156f7be8365fe18eb0fc61f119cd'),
(124, 'ru', '', 'A history of your chat was sent to address {0}', 'История Вашего разговора была отправлена на адрес {0}', 'ec76252f05b9d5ff8ccb83643528e8b9ad77e133'),
(125, 'ru', '', 'A new visitor is waiting for an answer.', 'Новый посетитель ожидает ответа.', 'cfe247762460477b3de5a91f87552736fe964ef3'),
(126, 'ru', '', 'A preview all pages for each style is available <a href="{0}">here</a>', 'Предпросмотр всех страниц каждого стиля доступен <a href="{0}">здесь</a>', '48e22d10a893906f9672ebc60091683b819507a6'),
(127, 'ru', '', 'A preview for each style is available <a href="{0}">here</a>', 'Предпросмотр каждого стиля доступен <a href="{0}">здесь</a>', 'c63dfc9f66f762febd12f53c4935be605f0c8129'),
(128, 'ru', '', 'A preview for invitation style is available <a href="{0}">here</a>', 'Предпросмотр стиля приглашения доступен <a href="{0}">здесь</a>', 'cf9c4bbc0128b2f0199e70eb7b8bd12019c5b763'),
(129, 'ru', '', 'Ability to modify profile', 'Возможность изменять свой профиль', 'a8cf9e7c1b40019513e7ef4bec88dc54cdf43912'),
(130, 'ru', '', 'About', 'О программе', '1dd0c707856c4d1d5953a001058c837ca8c7090a'),
(131, 'ru', '', 'About Mibew Messenger', 'О Mibew Messenger', 'e9dbf8112a5347fa2088ed32706f45cdea84d061'),
(132, 'ru', '', 'Actions', 'Действия', '9829eb51804fe94ac24574331b7c5cd9abd89d9c'),
(133, 'ru', '', 'Add address', 'Добавить адрес', 'a86eec7b88963487eedc15cd3012e453060a0fa1'),
(134, 'ru', '', 'Add message...', 'Добавить сообщение..', 'd4640c3e29842f5aaf1edf14e5c428edc6c7bd71'),
(135, 'ru', '', 'Add new message.', 'Добавить новый шаблон для быстрого ответа.', 'ef5fd991b3391057715ed397f68086a8a2d2badc'),
(136, 'ru', '', 'Add operator...', 'Добавить оператора...', 'f8492b4392c9bd74c15cb8fbdead649d7c6cbda8'),
(137, 'ru', '', 'Address {0} is blocked for a specified number of days.', 'Адрес {0} запрещен на указанное число дней.', '40d34fa807998f30b9733280d9b25c7b046ef63c'),
(138, 'ru', '', 'Adds a page with messenger usage reports.', 'Добавляет страницу с отчетами по использованию мессенджера.', '4a5831fc1eaf8fe49caac86f5402e4146b7ab4df'),
(139, 'ru', '', 'Administration', 'Управление', '0c8ec17dbf3b53d2584d679e3d1f45b251be5d70'),
(140, 'ru', '', 'All strings', 'Все строки', 'eda6c3cdee2c52ae3c22cf9806e6d06b90aad088'),
(141, 'ru', '', 'Allow secure connections (SSL)', 'Разрешать защищенные соединения (SSL)', '33140632fec369a2a5fb72fe6aab23b91f63198c'),
(142, 'ru', '', 'Allow tracking system to treat operators as normal visitors and add show in the visitors on site list.', 'Позволяет системе слежения трактовать операторов как обычных пользователей и показывать их в списке посетителей на сайте.', '70cf2ad758b999fa1496c24a22b633e17b7fe4bc'),
(143, 'ru', '', 'Allows a visitor to choose department/group', 'Позволять посетителю выбирать группу операторов', '729826802dd72c2a2760dd96763bd1016b2e0cfe'),
(144, 'ru', '', 'Allows users to change their names', 'Разрешать посетителям менять имена', '6eb0f3788d12733464b9034d8102b9fb93a6721a'),
(145, 'ru', '', 'Answer', 'Ответить', '3559952cc7751fdc0b5bd00f8c579d2f3bf49f5a'),
(146, 'ru', '', 'Application path is {0}', 'Приложение найдено по адресу {0}', '8778f881a0f864bdd5b86de917efcf58612b046c'),
(147, 'ru', '', 'Are you sure that you want to delete address {0} from the blocked list?', 'Вы уверены что хотите убрать адрес {0} из списка заблокированных?', '76f91c504000774086b68ab0981c5fb3fe46ed26'),
(148, 'ru', '', 'Are you sure that you want to delete operator "{0}"?', 'Вы уверены что хотите удалить оператора "{0}"?', '7ccf1cb13a345854e19fbbcf6676207efd2bda81'),
(149, 'ru', '', 'Are you sure that you want to delete the group "{0}"?', 'Вы уверены что хотите удалить группу "{0}"?', '7fe73b251558881ea3f9ae9184271eb29c8c8f54'),
(150, 'ru', '', 'Are you sure that you want to uninstall plugin "{0}"?', 'Вы уверены что хотите удалить плагин "{0}"?', '949b2d7b4618f7caec62a5e09d82c9a953e09326'),
(151, 'ru', '', 'Are you sure want to leave chat?', 'Вы действительно хотите покинуть диалог?', '94be903d437d5149f0540b3fb24f3df836a2902a'),
(152, 'ru', '', 'Ask for visitor''s email', 'Спрашивать e-mail адрес', 'ba3be4cc986da1ae987a9f2a4290478a75572c46'),
(153, 'ru', '', 'Ask your question', 'Задайте вопрос', '3bc5ea94fcbba3f92e76fad62956961a66066c45'),
(154, 'ru', '', 'Available updates', 'Доступные обновления', 'e92a6b1749cfe44d2c5099d2708f91a91b35d093'),
(155, 'ru', '', 'Average chat time (in seconds)', 'Среднее время диалога (в секундах)', 'e1318bbc982cfd9d571506bf04bb11d512be8692'),
(156, 'ru', '', 'Average message length (in chars)', 'Средняя длина сообщения (в символах)', '836944e336172415e78dcebf67b210a4f4a3ae63'),
(157, 'ru', '', 'Average waiting time (in seconds)', 'Среднее время ожидания (в секундах)', '3a59faecd98a4e16ba858d0b92f25a2ca8dfb3c5'),
(158, 'ru', '', 'Away', 'Отошел', '0be0f904fba91689a7b87dcf49d96ade64f5a5fe'),
(159, 'ru', '', 'Back to login', 'Вернуться на главную', '73cf115f35a9fe0e2d547b2312e4b53c8696ac4b'),
(160, 'ru', '', 'Back...', 'Назад...', '91c52c18bcb6db71f08567673abbec475cf5cdd7'),
(161, 'ru', '', 'Ban List', 'Запреты', '0257c0e949c62e13350a999f83cfad8eacc0956b'),
(162, 'ru', '', 'Ban this visitor', 'Пометить посетителя как нежелательного', '634082e4daf52cb5df4779c24710496cd3f1c7c0'),
(163, 'ru', '', 'Beware that statistics is aggregated up to yesterday.', 'Помните, что статистика агрегируется до вчерашнего дня.', '57c9eb863108e1d7ee4205d46862ec8f7c1d15e8'),
(164, 'ru', '', 'Block address', 'Запрет адреса', 'e791553866e5731dc76560e89a4cbe58dfcc4a6a'),
(165, 'ru', '', 'Blocked visitors', 'Нежелательные посетители', 'd656f620e88e1513ec43dc509d90e1c245e64844'),
(166, 'ru', '', 'Browser', 'Браузер', 'aff5d9c42be0bd62d0335717bedcfe183be3ac91'),
(167, 'ru', '', 'Button HTML code generation', 'Получение HTML-кода кнопки', 'b9c540aad4b244afd1504aa1d63aaa938f94ec7b'),
(168, 'ru', '', 'Button HTML code generation.', 'Получение HTML-кода для кнопки "Веб Мессенджера".', '40eb26e61146e634e75b3b3ad823479cbc3f53f2'),
(169, 'ru', '', 'Button code', 'Код кнопки', '45d8521893537686e80975d183394fe459df1d95'),
(170, 'ru', '', 'Can slow down the update rate of the list', 'Может замедлить обновление списка', '87e4d3adb526e3ffb0264c095a430f74f3195edd'),
(171, 'ru', '', 'Cancel', 'Отмена', 'b5c4117958bd4c056ea7eeeb009284bb1529247f'),
(172, 'ru', '', 'Canned Messages', 'Шаблоны ответов', '4ed794ec0e12a17dfbb92b5f42d530e5f9bd33ac'),
(173, 'ru', '', 'Cannot delete: wrong argument.', 'Невозможно удалить: неверный аргумент.', '3823729da1678b6c36c2b42ce1cdfd5f415bc7a4'),
(174, 'ru', '', 'Cannot disable "admin".', 'Невозможно заблокировать оператора "admin".', 'f47c7be701446753e4ce43507a04ee04d1ecf650'),
(175, 'ru', '', 'Cannot disable all locales.', 'Невозможно отключить все языки.', '9c21b80487f6472a3ef5e0ab59083c95e87487b2'),
(176, 'ru', '', 'Cannot disable self.', 'Невозможно заблокировать себя.', 'debbb1a0b5ee7a5089892d5ff43ebddbf4b683f4'),
(177, 'ru', '', 'Cannot execute:', 'Невозможно выполнить:', 'bb94bc6eddcace7967b06b359e58eed2ed5b7791'),
(178, 'ru', '', 'Cannot read file {0}', 'Невозможно прочитать файл {0}', '03493720946bbf229613289ccf85a309bd6aed88'),
(179, 'ru', '', 'Cannot remove operator "admin".', 'Нельзя удалить оператора "admin".', '1eb27165caa5e9f1441bd504a45dcadedfe87e0f'),
(180, 'ru', '', 'Cannot remove self.', 'Нельзя удалить себя.', 'b1342e621af57c404f4d6c8a264526468f133b0e'),
(181, 'ru', '', 'Cannot take over', 'Вы не можете перехватывать диалоги', '150495cefbed72c45f52e8d9c4566e28d9a9093d'),
(182, 'ru', '', 'Cannot take thread', 'Невозможно установить диалог', '66ecd03e357ac31efaa4418312c9c556d25b3812'),
(183, 'ru', '', 'Cannot view threads', 'Вы не можете просматривать диалоги', '0902531c26682e52190c965d70d7139d8dd60636'),
(184, 'ru', '', 'Change', 'Изменить', '7197755df2f37f88feba1d646d38a6fbcfd3953b'),
(185, 'ru', '', 'Change locale.', 'Выбрать язык системы.', 'a57c124b9052b5a55ee1cec24dde03478e7b9e32'),
(186, 'ru', '', 'Change name', 'Изменить имя', 'ae64f2d462cd352773284642d9c0cde613534da5'),
(187, 'ru', '', 'Change operator', 'Сменить оператора', 'abdc9f943586a1844b194668b3a5b9d96f37d2bf'),
(188, 'ru', '', 'Change restrictions and available features for this operator.', 'Здесь вы можете управлять возможностями оператора.', '2e61851ca322514d109027175f58969ff5ad2570'),
(189, 'ru', '', 'Change your password', 'Изменение вашего пароля', '624223957337f8ca63d86fdab17536e44468d3b1'),
(190, 'ru', '', 'Changes saved', 'Изменения сохранены', 'dc330d2bd13b486d806d392f77597f4878256887'),
(191, 'ru', '', 'Chat Threads', 'Диалогов', '83db8b24b5a1c196e34364418f7e63e82f7c442c'),
(192, 'ru', '', 'Chat history', 'История диалогов', '4a4fd087afab04d5a7ec69f9a1cde8a1318f0cde'),
(193, 'ru', '', 'Chat log', 'Протокол разговора', '43c7d3b1e7216e9a2109363a51b3202a2168ebac'),
(194, 'ru', '', 'Chat refresh time', 'Периодичность обновления сообщений в чате', 'bbbaccad1231a53d7fb19ab3e7e37789223f9a65'),
(195, 'ru', '', 'Chat themes preview', 'Просмотр стилей диалогов', '4789361969234fd9bb53f0f1bca4f2c2afb53d54'),
(196, 'ru', '', 'Chat threads', 'Диалогов', 'f838c677ddee55a543c7f89b859917fba2eda0a1'),
(197, 'ru', '', 'Chat threads by page', 'Статистика по страницам', '45d2d67856e29c973110807b63e0610bce55e3b6'),
(198, 'ru', '', 'Chat window (operator-mode)', 'Окно чата (со стороны оператора)', '0b8330eb3ec7c2cf148e58b85bfa87f7d61d4668'),
(199, 'ru', '', 'Chat window (user-mode)', 'Окно чата (со стороны посетителя)', 'db6a1fcb6da3b6c5a222deeec9ade80cdd8ae91e'),
(200, 'ru', '', 'Chat window style', 'Стиль чат-окна', 'cb205643400eb8b4c7d05ab25304ef2b3634b27a'),
(201, 'ru', '', 'Check for available updates', 'Проверить доступные обновления', '6b4eca3f96c3519500ca0cb29fdf0e9bfc71dcfa'),
(202, 'ru', '', 'Check updates automatically', 'Проверять обновления автоматически', 'd9f51d02fd95563e0692407c78e65e2097f55d18'),
(203, 'ru', '', 'Checksum differs for {0}', 'Контрольная сумма не совпадает для {0}', 'e30a976d371553736b409b3c05fa488445c1266c'),
(204, 'ru', '', 'Choose Department:', 'Выберите отдел:', '46f62c7d2b7f34b5c9ffa23c1f72a08ccd6fe271'),
(205, 'ru', '', 'Choose groups according to operator skills.', 'Группы в которых состоит оператор.', '304cac69bf5de3b7c5e7719fa259fe213567b4ee'),
(206, 'ru', '', 'Choose image', 'Выбор картинки', '11f13e84c28884cdcf494b7079ed168368ea0b9b'),
(207, 'ru', '', 'Choose style', 'Выберите стиль', '2707dd8641e5266e8f30e3d8ae4425cb8064d171'),
(208, 'ru', '', 'Choose template', 'Выберите шаблон', '9e3472e56dca0838ffafd300e778e4fbb3a1c743'),
(209, 'ru', '', 'Choose the avatar file to upload.<br/>The picture size should not exceed 100x100 px.', 'Выберите файл на локальном диске. Для наилучшего отображения размер <br/>картинки не должен превосходить 100x100 px.', '59a81aba5335cc3a094379d7cac847c069dd9c19'),
(210, 'ru', '', 'Choose the translation file to upload.', 'Выберите файл переводов для загрузки.', 'fe520b86899c9d794c35921383eb4e04d487e269'),
(211, 'ru', '', 'Choose your language', 'Выберите ваш язык', 'feba9caa1a9c23e27d773725489e65922ab8f86a'),
(212, 'ru', '', 'Choose:', 'Выберите:', '63b64d3883e6ca29d4900c0d850b243601e8132a'),
(213, 'ru', '', 'Click on this link to close the window', 'Нажмите на эту ссылку чтобы закрыть окно', 'cad810ec30fbf950eb8231b204111b75f2661d50'),
(214, 'ru', '', 'Click to chat', 'Начать диалог', 'ab0acd974444faa01ce0cda4bc9f089a8298d329'),
(215, 'ru', '', 'Click to chat with the visitor', 'Нажмите для того, чтобы обслужить посетителя', '58453809b4442505ad4d6195e7c10661d5cc1e5c'),
(216, 'ru', '', 'Click to check the sound: {0} and {1}', 'Проверьте звук: {0} и {1}', '6f46ee5c0fa654064e1aefa6ccedad87da90143a'),
(217, 'ru', '', 'Click to close the window', 'Нажмите на эту ссылку чтобы закрыть окно', '0a4cc655581d57200ed118d740dd55960c4ca32e'),
(218, 'ru', '', 'Close', 'Закрыть', '1a6fd68d0223337502149284389d0156a1cd6e4f'),
(219, 'ru', '', 'Close chat', 'Закрыть диалог', '42c624f221554b493a144497e8c68f7fb31172b8'),
(220, 'ru', '', 'Close...', 'Закрыть...', '9986b357e00d8c5fdecb5e0b3fc8e67a4cf7494b'),
(221, 'ru', '', 'Closed', 'Закрыто', '97295f69020754f5c126cd1548deca073881500b'),
(222, 'ru', '', 'Code', 'Код', '4aa05fb2e1e72bed75908bcc1d2b569da766e3e2'),
(223, 'ru', '', 'Code for group', 'Для группы', 'bebb657ce32be83f74470edb2454aeae8d44a69c'),
(224, 'ru', '', 'Code for language', 'Для какой локали создавать кнопку', '3579edbbbd9ac0de1b735ccae08db25237887c36'),
(225, 'ru', '', 'Code should contain only latin characters, numbers and underscore symbol.', 'Код должен состоять из латинских символов, цифр и знака подчеркивания.', 'a2121326c724dddfaa6fb5569d872c470bd9095d'),
(226, 'ru', '', 'Comment', 'Комментарий', 'ba613eacb03566930935a61740bb31471e92f464'),
(227, 'ru', '', 'Company title', 'Название компании', 'ab31c260ed9af1324a4bc48d0afc617daab5a311'),
(228, 'ru', '', 'Compatibility with mod_security (modsecurity.org), turn on only if you have problems with it', 'Совместимость с mod_security (modsecurity.org), включите если окно с чатом открывается с http ошибкой', '5763bc79f0ee4bd64cdf4fc1c3a497f0f7dfd2af'),
(229, 'ru', '', 'Completed:', 'Выполнено:', '028098e949f777d4dc30f317cd876d8bab749429'),
(230, 'ru', '', 'Confirm new password.', 'Подтвердите введенный пароль.', '41853e67823d1b28d066f3b46a5174ded4a77f36'),
(231, 'ru', '', 'Confirmation', 'Подтверждение', 'e6488e5ed2608db988ffa75a8c7d77a9e7179ac3'),
(232, 'ru', '', 'Connection timeout for messaging window', 'Таймаут соединения для окна сообщений', '71ea5db267dbcd6a31f1b0310bcb2f0ba53e9f99'),
(233, 'ru', '', 'Copyright &copy; {0} Contributors of the Mibew Messenger project.', 'Авторские права &copy; {0} Участники проекта Mibew Messenger.', '613e182c816125a7cfa3ea3b82d55ea5ecee2743'),
(234, 'ru', '', 'Correct the mistakes:', 'Исправьте ошибки:', 'b4358261ae3451b66ce6e7d7d79e9753367782ed'),
(235, 'ru', '', 'Could not connect. Please check server settings in config.yml. Error: {0}', 'Нет доступа к MySQL серверу, проверьте настройки в config.yml. Ошибка: {0}', 'ae12456fc21a8a6e757b1972d86aeb07482b9a62'),
(236, 'ru', '', 'Create database "{0}"', 'Создать базу данных "{0}"', '9bfdfcaf9799c202fb6fc04c535053acbdb5a9fd'),
(237, 'ru', '', 'Create new group', 'Добавить группу...', 'ff64e4d3d76ac2bc6ed080ed0142fb97db8424ae'),
(238, 'ru', '', 'Create new group here.', 'Здесь вы можете создать новую группу.', '98b862bdfb48ca5e1b432217917a092c1c90dffc'),
(239, 'ru', '', 'Create or delete company operators. Manage their permissions.', 'Создание, удаление операторов компании. Управление их правами и возможностями.', 'c5e199dd5ba5765c909005e5894eb27dd400df74'),
(240, 'ru', '', 'Create required tables.', 'Создать необходимые таблицы.', '94f7fcdc4f13d834f1d2f466ca0538a3c5d02a81'),
(241, 'ru', '', 'Cron security key', 'Ключ безопасности cron', 'f8a9accc062c90d7a5753f265f78248c07bd1745'),
(242, 'ru', '', 'Current avatar image', 'Изображение текущей аватарки', '51bd9afaefb5221e96e110f0367e6661f963e9e4'),
(243, 'ru', '', 'Database "{0}" is created.', 'Создана база данных "{0}".', 'ca01281ee0478791f20af2d036f562ff2dc3f657'),
(244, 'ru', '', 'Date', 'Дата', '185810c963169d319d0385748a3cbfc3877dae0a'),
(245, 'ru', '', 'Date format (date)', 'Формат даты (дата)', 'd389ff20dba0a0fe265f3cc5c6806d71aed91f04'),
(246, 'ru', '', 'Date format (full)', 'Формат даты (дата и время)', '6fac2a25ae0f6638697b8bf6475ff156682096d6'),
(247, 'ru', '', 'Date format (time)', 'Формат даты (время)', '5154a3eaa628d1079796101a66a67d56329c52da'),
(248, 'ru', '', 'Days', 'Дни', 'e05592503a4373649b7170aee540e8bcea6ae2b1'),
(249, 'ru', '', 'Delete', 'Удалить', 'bd5664064522e5311b7f03289db0eff4760f809f'),
(250, 'ru', '', 'Department description:', 'Описание отдела:', '18b7b93c333f6effda8aba59bf9e4167bd3d93fe'),
(251, 'ru', '', 'Department or skill based groups.', 'Объединения операторов на основе отделов или областей знаний.', '850bcc812364f14fdb25d6180191176b0f1fea07'),
(252, 'ru', '', 'Dependencies', 'Зависимости', '55d45940bbc5a2284db80bad1ef1deeb3fdd77e1'),
(253, 'ru', '', 'Description', 'Описание', '4752c5486d44834c704cc1ccfc7c93217e6caf7d'),
(254, 'ru', '', 'Description in English.', 'Описание для посетителей из других стран.', 'b196925e43356c86efc67de5397e6287fd114e05'),
(255, 'ru', '', 'Description of the group.', 'Будет доступно посетителям при выборе группы.', '04e0a59d15bf507a2f306cce54d7e9dc8382ebe0'),
(256, 'ru', '', 'Destination for your company name or logo link', 'Будет открываться по нажатию на логотип или название компании в чат окне', '9ec6725425bf51fc524c4951ea4dd730247a3f41'),
(257, 'ru', '', 'Direction:', 'Направление перевода:', 'c59e273c4fa2d540270a7928164f33d1a97a4ba1'),
(258, 'ru', '', 'Disable all the dependencies first', 'Сначала отключите все зависимости', 'b2d4dda18cbd6a5dfd47235de01edff8ad444a47'),
(259, 'ru', '', 'Download', 'Скачать', 'd5fe34ae9ab7e28b0aa7b598fb3d83e680f0e536'),
(260, 'ru', '', 'Drop existing tables from database', 'Удалить существующие таблицы', '6a0c603d823126389cfb739c3593c32e2669dbb0'),
(261, 'ru', '', 'E-Mail: {0}', 'E-Mail: {0}', '1e07ffdb5e49ec2c6f1d04ae501adc8e96105813'),
(262, 'ru', '', 'E-mail', 'Адрес электронной почты', 'aa52c9fc79ee5b6347fb0b85f72a7648343f265f'),
(263, 'ru', '', 'Each IP becomes a link opening in a new window. {ip} is substituted with a real IP.', 'На любом IP адресе можно будет открыть небольшое окно с геоинформацией. Можно использовать {ip}.', '4948e138620c0c569336054d33728c777ca8a542'),
(264, 'ru', '', 'Edit', 'Изменить', 'e5467a727eb72fd27ff20cb5a6ba022c07de3f00'),
(265, 'ru', '', 'Edit Message', 'Редактировать шаблон', '0228182c22979f573ab807772fd5288d3776056b'),
(266, 'ru', '', 'Edit an existing message.', 'Отредактируйте существующее сообщение.', '608d7d06d415856af46dd36e3ee558bb00b6208b'),
(267, 'ru', '', 'Edit general operator settings.', 'На этой странице вы можете просмотреть детали оператора и отредактировать их.', '8a56c5b123ad4fca8c66e73108327f05be4a1bb0'),
(268, 'ru', '', 'Edit locale settings.', 'На этой странице вы можете изменить настройки языка.', '334f55211dc5edd6c2bb49ebd93b4d7d7509347f'),
(269, 'ru', '', 'Edit messages that you frequently type into the chat.', 'Создавайте текстовые сообщения, которыми будете часто пользоваться в чате.', 'e57518dc477081e92c40dd95d8f774e2f23e1ee5'),
(270, 'ru', '', 'Email', 'Адрес электронной почты', 'fa47cb2a56a76d0b0cdcb3de8d06240b9f5a11a3'),
(271, 'ru', '', 'Email:', 'E-mail:', 'd39916a35a4049ac20806ec7a8232909bbad5f1f'),
(272, 'ru', '', 'Enable "Groups Isolation"', 'Включить функцию "Изоляция групп"', 'a0677db9781ff45281d2f621785e72dc7a9635cb'),
(273, 'ru', '', 'Enable "Groups"', 'Включить функцию "Группы"', '2f60635ad45b69f691c01cf8591ab7c0e9f05aa3'),
(274, 'ru', '', 'Enable "Popup dialog notification of the new visitor".', 'Показывать небольшой диалог при появлении новых посетителей в очереди.', '3badaec55a807f6e7eaf7d0e3830d4fcbaa6bd82'),
(275, 'ru', '', 'Enable "Pre-chat survey"', 'Включить "Опрос перед началом диалога"', '644f67ada743d1d10389c2351a7406521b6e772a'),
(276, 'ru', '', 'Enable "Statistics"', 'Включить функцию "Статистика"', '4c9cd16b78494557d7a14b962af2f30319abd7ea'),
(277, 'ru', '', 'Enable "Tracking and inviting"', 'Включить функцию "Отслеживание и приглашение"', 'a55ca22687f7bc2356408c8288e852e3fe4eafa8'),
(278, 'ru', '', 'Enable all the dependencies first', 'Сначала включите все зависимости', 'ae5e12630da79be2356fdefa28e28c821efc010c'),
(279, 'ru', '', 'Enable feature "Malicious Visitors"', 'Включить функцию "Нежелательные посетители"', '8da5c1e14a1d6c226af15116f5967ae192e50f76'),
(280, 'ru', '', 'Enable tracking of visitors'' activity on your site and ability to invite visitors to chat.', 'Добавляет функцию отслеживания перемещений посетителей по Вашему сайту и возможность отправки им приглашений к диалогу.', '8b867938325c2ece7b04a81e014d18c5ddbc501c'),
(281, 'ru', '', 'Enter', 'Войти', '79b1a20ed872dc4dbd7ba66bdd91616f9d049581'),
(282, 'ru', '', 'Enter a new password or leave the field empty to keep the previous one.', 'Введите новый пароль или оставьте поле пустым, чтобы сохранить старый.', 'c3e53762f125d4d74b98b35d26c5a25869c915e9'),
(283, 'ru', '', 'Enter a valid email address', 'Введите правильный адрес электронной почты', '8c274fcd5a9f881f1c6e48dab9f30ab20733de86'),
(284, 'ru', '', 'Enter an email to receive system messages', 'Введите адрес электронной почты для получения сообщений от системы', '6818097f4d0f0fa27d921a8e2ca77bb35505d5d5'),
(285, 'ru', '', 'Enter http address of your company logo', 'Введите ссылку на логотип компании', '6c193082c3a34c8d60c9662e94b5f6d2b3371186'),
(286, 'ru', '', 'Enter your company title', 'Введите название Вашей компании', 'a7c5559f2680786e7fa9379320644c3bbd560908'),
(287, 'ru', '', 'Enter your email:', 'Введите Ваш E-mail:', 'bffeda26ef690065d6a9d2b3576a02445a7d29cf'),
(288, 'ru', '', 'Enter your translation.', 'Введите ваш вариант перевода.', '3551569d070b088a1579d48a47bb42ea0370aeac'),
(289, 'ru', '', 'Entered login/password is incorrect', 'Введен неправильный логин или пароль', '03963b3fb35529cdc851fd3a55d0e295ae4dfed6'),
(290, 'ru', '', 'Entered passwords do not match', 'Введенные пароли должны совпадать', 'b26663ead44ef8f6be466efd9f0064cb2dfe2f25'),
(291, 'ru', '', 'Environment:', 'Окружение:', '5bf078cc6c8e9990ce3904850f41648f340c5900'),
(292, 'ru', '', 'Error', 'Ошибка', 'f20d5bb33c33a4f795520da853aefee6f214abbb'),
(293, 'ru', '', 'Error moving file', 'Ошибка копирования файла', 'b96dc4f32effc2d77462b2c7cf4cab2b71a69a93'),
(294, 'ru', '', 'Error occurred:', 'Произошла ошибка:', '9e2eb61236a377ab5a32dc15e5240a501339e4b0'),
(295, 'ru', '', 'Error uploading file "{0}": {1}.', 'Ошибка выгрузки файла "{0}": {1}.', 'c7f975adf1667936a5093f15b7b23b7f940a9160'),
(296, 'ru', '', 'Error window', 'Error window', '153900f6ef4e7f6cce39af81272737ea8b5e5b6b'),
(297, 'ru', '', 'Ex: 127.0.0.1 or example.com', 'Например: 127.0.0.1 или example.com', 'f707eb12433fb8f3ba3f1b3ae2c20c1bbbe21fa2'),
(298, 'ru', '', 'Example', 'Пример', '0736dfeba32f1ec63ae9fd5502d0d71653b7c275'),
(299, 'ru', '', 'Exit', 'Выход', 'baec44c98ce254427a19f6da68df9dc58064200c'),
(300, 'ru', '', 'Features activated', 'Набор сервисов изменен', '35fa0697ff1265582e087dd6cf5bae780456a464'),
(301, 'ru', '', 'File is absent: {0}', 'Не хватает файла: {0}', '05c309a2c6448c8d94b22bf88981af835e97a71d'),
(302, 'ru', '', 'First seen', 'Впервые замечен', 'a68815c8b58b309a2104f78d1bd976a207efee98'),
(303, 'ru', '', 'Follow the wizard to setup your database.', 'Следуйте указаниям мастера для правильной настройки базы данных.', '16b9504a62db07d6aa05cdffff0a5ccaca3c3c88'),
(304, 'ru', '', 'For group:', 'Для группы:', '5d07231740439c01073e55be6b6d17c46447be3b'),
(305, 'ru', '', 'For more information visit the official site of the project: <a href="https://mibew.org/">https://mibew.org/</a>', 'Для получения более подробной информации посетите официальный сайт проекта: <a href="https://mibew.org/">https://mibew.org/</a>', '445a8435839b88571cd43ab2097d222527fc317b'),
(306, 'ru', '', 'For language:', 'Для языка:', 'c8a75ab9fdc487796c64caea1930cc0e61991d2e'),
(307, 'ru', '', 'For notifications and password retrieval.', 'Для получения извещений и восстановления пароля.', '6f4a5cead9635d112c00bce091a1395589c9152a'),
(308, 'ru', '', 'Force all chats to be secure', 'Принудительно переводить все чаты в защищенный режим', '669e5b1183e5777c0298ffe12889d68f6731e524'),
(309, 'ru', '', 'Force visitor to enter a verification code when leaving message', 'Разрешать оставлять сообщение только после ввода специального кода с картинки', '3850b2ba2408baf85dc9209a3a4dad244cafd433'),
(310, 'ru', '', 'Forces the user to fill out a special form to start a chat.', 'Предлагает посетителю заполнить специальную форму перед началом чата.', '17f5739ff700c94b445b67a7040e7585848d27e5'),
(311, 'ru', '', 'Forgot your password?', 'Забыли пароль?', 'e4d90692f9ce2845ed3f7845c8d4afa43fb92a9d'),
(312, 'ru', '', 'Found 0 elements', 'Ничего не найдено', '359bb0a2ff78c4d5398d7008b0ef268dcb031d99'),
(313, 'ru', '', 'From this page you can generate a variety of usage reports.', 'Различные отчеты по посетителям и использованию мессенджера.', '960c58429f92073083732a49c2c52307ef4e52be'),
(314, 'ru', '', 'From this page you can generate a variety of usage reports. Last time statistics was calculated {0}. You can calculate it <a href="{1}" target="_blank">manually</a>.', 'Различные отчеты по посетителям и использованию мессенджера. Последний раз статистика собиралась {0}. Вы можете собрать ее <a href="{1}" target="_blank">вручную</a>.', '0944bdcd1a213e4db16a60892cd90415b1466727'),
(315, 'ru', '', 'From:', 'С:', 'b0f073620b2cb155040a2ee9ba28ad4bd1daf9c5'),
(316, 'ru', '', 'Full list of operators:', 'Полный список операторов:', 'cab9702fb02ff9fbdce8f4d8cb07845352e44aed'),
(317, 'ru', '', 'Functions available for site operators.', 'Набор функций, доступный только зарегистрированным операторам.', 'dc248baf72316786023dc01f26cbef0b3760dc29'),
(318, 'ru', '', 'General', 'Общее', '11e24a09d4e11d1ef4df9769018243839a8f8142'),
(319, 'ru', '', 'Generating code type', 'Тип генерируемого кода', 'f163cf75cdaa623aa4e88a399b776753037d4b68'),
(320, 'ru', '', 'Geolocation window options', 'Опции для окна с геоинформацией', '28c220187895e46a572b13ad44e57363b494afc0'),
(321, 'ru', '', 'Go to search', 'Перейти в поиск', '75e67944f9fa6d3f240c043f498a7aa67bc06258'),
(322, 'ru', '', 'Group', 'Группа', '61fe1e5cf5ff70ec58f958421b3f93fdccd84c9a'),
(323, 'ru', '', 'Group details', 'Детали группы', 'e67cefd31f8231d928b4987a52c06d628459190d'),
(324, 'ru', '', 'Group email for notifications. Leave empty to use the default address.', 'Адрес для извещений. Оставьте пустым, чтобы использовать глобальный адрес.', 'd8500cf4472d625fb58122269f9cbed14068c8ab'),
(325, 'ru', '', 'Group:', 'Группа:', '1dd8987a95404e323707294972675f2853c852d9'),
(326, 'ru', '', 'Groups', 'Группы', '64e57fbb2611f80be895a0fbd0ae76df94430e69'),
(327, 'ru', '', 'Groups can be organized in a hierarchical structure', 'Группы могут быть организованы в иерархическую структуру', '773b9b0029dba75942751d4a32698801d0158c46'),
(328, 'ru', '', 'Groups with lower weight display higher in groups list. Group weight is a positive integer value.', 'Группы с меньшим весом отображаются выше в списке групп. Вес - это целое положительное число.', '1e24a0b3e8ffee07b34993da9e87b395b46b662a'),
(329, 'ru', '', 'Guest', 'Посетитель', '80294f33e470afd8ed3b2eff919284b19f712482'),
(330, 'ru', '', 'HTML code', 'HTML-код', '4ca8d6face0d81539972c336e343b3f6aed9f5b9'),
(331, 'ru', '', 'Hello, how can I help you?', 'Здравствуйте! Могу ли я Вам помочь?', 'ab34dd99f3cb8339a2ea35c0171a35043c135415'),
(332, 'ru', '', 'Hello. How may I help you?', 'Здравствуйте! Чем я могу Вам помочь?', '64649052971441392454478b117eba66f72e7d05'),
(333, 'ru', '', 'Here you can block malicious visitors that affect your work with spam messages.', 'С помощью механизма запрета Вы можете бороться с нежелательными посетителями, которые нарушают работу консультантов, открывая большое количество окон или присылая спам сообщения.', '84dd6e6b6c2b5d90e464a512f05ec217ec49f144'),
(334, 'ru', '', 'Here you can block malicious visitors.', 'Здесь можно защищаться от спама и вредных посетителей.', 'cbe2cf6b689fbd8c41931b5e3d468636466593fa'),
(335, 'ru', '', 'Here you can manage plugins. Notice that plugins are configured via the main config file.', 'Здесь вы можете управлять плагинами. Обратите внимание: плагины настраиваются через основной конфигурационный файл.', '9e4e9ec0c08f31000634e19674563b6776ef958b'),
(336, 'ru', '', 'Hide menu', 'Спрятать меню', '067dd18a678b5ab865e95ddfa97abec365a4b89a'),
(337, 'ru', '', 'Hide menu >>', 'Спрятать меню >>', '5fb8cf0f9e9c1a591b4a5f0d0b8194b370ce4831'),
(338, 'ru', '', 'Home', 'Главная', '49cf52a1cb200713ab07140bbbc3624c2b1e1b9f'),
(339, 'ru', '', 'How to build visitor''s identifying string from {name}, {id} or {addr}. Default: {name}', 'Укажите как отобразить имя посетителя операторам. Можно использовать {name}, {id} и {addr}. По умолчанию: {name}', '44a821a742f46447c087620ea26003123ebf76bf'),
(340, 'ru', '', 'If you don''t agree with the translation please send us an update.', 'Если вам не нравится перевод, пришлите нам ваш вариант.', '72bdd9cf154c59ffda6a36ef00104fb541ec6006'),
(341, 'ru', '', 'Impossible to update tables structure. Try to do it manually or recreate all tables (warning: all your data will be lost).', 'Невозможно обновить структуру таблиц. Попробуйте сделать это вручную или пересоздайте все таблицы заново (внимание: все данные будут утеряны).', '4e2d80341f4e41573259de9798db1d59de428917'),
(342, 'ru', '', 'In chat', 'В диалоге', 'cb6a712063682579d92a045431a2100e6f7ad27d'),
(343, 'ru', '', 'In queue', 'В очереди', '529d23fda2a0fe35583a77327bc02ce3068341e3'),
(344, 'ru', '', 'Include host name into the code', 'Включать имя сайта в код', '6c0a7e8da87593428fe154bb81d1d50979050d56'),
(345, 'ru', '', 'Info: {0}', 'О Посетителе: {0}', 'ec7a2e0873222cb18698384c44f54249fe872765'),
(346, 'ru', '', 'Initial Question:', 'Ваш вопрос:', '8f745e8c88130086a273f5758ba2959531e17176'),
(347, 'ru', '', 'Installation', 'Установка', '1554f7daecf0bdb17bc6dd18e7fe4089b8bfbc85'),
(348, 'ru', '', 'Installed localizations:', 'Установленные языковые пакеты:', '78862ab61c1886507822964f31f7a60ed19ca9da'),
(349, 'ru', '', 'Insufficient file permissions {0}', 'Не хватает прав {0}', '465d9522c69f3dc2da1750d2659e1c2207145572'),
(350, 'ru', '', 'International description', 'Интернациональное описание', '50138ab8ef8ce20e6f816aa5f5b35841bbeb2d96'),
(351, 'ru', '', 'International name', 'Интернациональное имя', '08fc6f865f7e4c1dce81c680fd6a92cc027d4147'),
(352, 'ru', '', 'International name (Latin)', 'Интернациональное имя (латиницей)', 'f64d659cb427ad7b9616713dbba95a6c67e3d32e'),
(353, 'ru', '', 'Invalid file type', 'Недопустимый формат файла', 'd876e1d2fe811e79c627da70d5492d6ca8975126'),
(354, 'ru', '', 'Invitation lifetime', 'Срок действия приглашения', '9f43dd5a22f7e334140942a4ee0e580548d3b879'),
(355, 'ru', '', 'Invitation style', 'Стиль приглашения', '3d7e0ef33321c3f99fab154ea8737c3c542a5d9e'),
(356, 'ru', '', 'Invitation themes preview', 'Просмотр стилей приглашений', '4cee6e8c3600047ae7298478c820213281bb4870'),
(357, 'ru', '', 'Invitation time', 'Время приглашения', '73242b8b1df0b2a88fcaca2d75726681db08b339'),
(358, 'ru', '', 'Invitations / Chats', 'Приглашений / Диалогов', '0c6896efae6feb9bcddef445044e4f3b83fa18a3'),
(359, 'ru', '', 'Invitations accepted', 'Приглашений принято', 'c6f1e4acf5d5455f621aed9b06342bd775a33647'),
(360, 'ru', '', 'Invitations ignored', 'Приглашений проигнорировано', 'f086bdd5b977458e3c032360c7be8eb1fbb07986'),
(361, 'ru', '', 'Invitations rejected', 'Приглашений отклонено', '0c86ec8e7a8e3a2ea3419e4a235113dd2e3503f6'),
(362, 'ru', '', 'Invitations sent', 'Приглашений отправлено', 'a91533cbbf3635cf0a2d0d123851498afb2c505e'),
(363, 'ru', '', 'Invite to chat', 'Отправить приглашение к диалогу', 'dfb5e3b22b8914f4bc15d4a2bd2ed3cc458570f3'),
(364, 'ru', '', 'Invited by', 'Кем приглашён', '5a5805557390122b264603138e74d67f4e0c5be2'),
(365, 'ru', '', 'Key identifier', 'По ключу ресурса', '6d3d148120179478dcaaac63d45da67295a20dec'),
(366, 'ru', '', 'Language', 'Язык', 'c4051661f9aa5131729ff4e578790eac676effbc'),
(367, 'ru', '', 'Language of the messages left by visitors', 'Язык сообщений, оставляемых посетителями', '868053c5c4b187bf592ff07214012407871e0944'),
(368, 'ru', '', 'Language of the messages that could be left by visitors when operators aren''t available', 'Язык сообщений, который могут быть оставлены посетителями в отсутствие операторов.', '34531467e8b028a07c261c490fcaebe06b9401af'),
(369, 'ru', '', 'Last active', 'Последний раз', '9d497af00207be05b0db64b00edd66b9859f36b7'),
(370, 'ru', '', 'Last seen', 'Последний раз замечен', '2edcbbf839a74d1b56122a6b28dec4d5dd6b4c0b'),
(371, 'ru', '', 'Leave message window', 'Leave message window', 'c8dd19d57af1c22429a87f56bdcd935b39976280'),
(372, 'ru', '', 'Leave your message', 'Оставьте ваше сообщение', 'beda4838dc37c99d83fc671630a76391854215c5'),
(373, 'ru', '', 'License', 'Лицензия', 'e751d497912628e376ac9a5ac71b3018e3b48ce4'),
(374, 'ru', '', 'Limit for tracked visitors list', 'Ограничение на число выводимых в списке отслеживаемых посетителей', '202240adf1fb015f37dc073264ddf2d2be55b828'),
(375, 'ru', '', 'Link to an external geolocation service', 'Ссылка на внешний geolocation сервис', 'c6d411e0262c2affa8f4d68f062193325d30a2c6'),
(376, 'ru', '', 'List of banned IPs:', 'Список запрещенных адресов:', 'f52b3e18a0f453d1f3ebc05928e270f5c82a806e'),
(377, 'ru', '', 'List of supported browsers window', 'List of supported browsers window', 'e162205cc37f3513427ca1852ee8072731367d75'),
(378, 'ru', '', 'List of visitors waiting', 'Список ожидающих посетителей', '907ed797e70af1f8e63667859c4132bb3b4e10cb'),
(379, 'ru', '', 'Live support', 'Веб Мессенджер', '71db66843b2cad254f072857163e821d992b68f1'),
(380, 'ru', '', 'Loading', 'Загружается', '2b5ea44454c0067acf614ccfd94177a2863c6b74'),
(381, 'ru', '', 'Locale details', 'Детали языка', 'c8f5db4040d4095ea31cb3b6437bea922a9738ac'),
(382, 'ru', '', 'Locales', 'Языки', 'c1caeb9f682f88071b6b161345e0905edb145ea6'),
(383, 'ru', '', 'Localize', 'Локализация', '77aeaf7d92e1dad0526d5021b7c2fef9d92f2b76'),
(384, 'ru', '', 'Log out of the system.', 'Покинуть систему.', '45bd525dd098ee02e0ac9efdf0555272fc38c14f'),
(385, 'ru', '', 'Login', 'Вход в систему', '791f32caf2d436da5abb0496e6238b14f805845c'),
(386, 'ru', '', 'Login can consist of small Latin letters and underscore.', 'Логин может состоять из маленьких латинских букв и знака подчеркивания.', 'b1e019c1eaba7b236634c2e380d307beb412332e'),
(387, 'ru', '', 'Login or E-mail:', 'Логин или E-Mail:', '255254d4d7fa26628696b47a0778af7cb7b318a8'),
(388, 'ru', '', 'Login should contain only latin characters, numbers and underscore symbol.', 'Логин должен состоять из латинских символов, цифр и знака подчеркивания.', '37253f48c77ba6b155fc862245ab151953b301fc'),
(389, 'ru', '', 'Login using your new password.', 'Войдите в систему, используя ваш новый пароль.', '42e74af203c5e66b261b7cf648b56f863cf929f6'),
(390, 'ru', '', 'Login:', 'Логин:', '01b4e540ff25c99d878e397c6fe2505d0cacae3a'),
(391, 'ru', '', 'Machine name', 'Машинное имя', '50f42ec62d9b154ce75e6ee80acdcfd3a84dde17'),
(392, 'ru', '', 'Mail body', 'Тело письма', '38e993492f032c1d0719ff0286ea4a8c1e52ff58'),
(393, 'ru', '', 'Mail subject', 'Тема письма', '643bb42ced58c19c62a1c315235f0079db9654bf'),
(394, 'ru', '', 'Mail templates', 'Шаблоны писем', '1f934cfaa4d6940398dc9944fbb8062794983ded'),
(395, 'ru', '', 'Mail thread window', 'Mail thread window', '227286aedcb2f0bb627874b153b15c7a83aee8b2'),
(396, 'ru', '', 'Main', 'Посетители', '8f03a6ac1db7669bc1597584114d8b8a1f5e8d92'),
(397, 'ru', '', 'Manage mail templates.', 'Управление шаблонами писем.', 'c5eab55c36beeec893e077cb525294bbabaec95c'),
(398, 'ru', '', 'Manage plugins.', 'Управление плагинами.', 'd5a7a8be49fdbea4c04e8dce17e56cd5afb11f07'),
(399, 'ru', '', 'Manage styles.', 'Управление стилями.', 'a9a1e41dd52885fdc23e1432f93587345ae5da30'),
(400, 'ru', '', 'Manage translations.', 'Управление переводами.', 'cfa0e81d43bea59388e955c3aebbdc6b0a2ed330'),
(401, 'ru', '', 'Max number of threads from one address', 'Максимальное количество диалогов с одного адреса', '07a86cfcd636c38a94d4bd74ba0f33e08cec69a7'),
(402, 'ru', '', 'Maximum size of uploaded files', 'Максимальный размер загружаемых файлов', '5218b53d90b1da83f86fe6865f9f0e424784d251'),
(403, 'ru', '', 'Members', 'Состав', 'd0938f79024842e51855da736fd6491fda7e8c7c'),
(404, 'ru', '', 'Message', 'Сообщение', '1e6136f4e711d398312608663c197ebf27bf7270'),
(405, 'ru', '', 'Messages', 'Сообщений', '8220a6c05fdf2fda29ea754b71d16079cdcb347e'),
(406, 'ru', '', 'Messages from operators', 'Сообщений операторов', 'd791ba1e7bd529143254a0bc348b988792fda7a9'),
(407, 'ru', '', 'Messages from visitors', 'Сообщений посетителей', '24e264870d3fac4c674c397e8e337e0c86fafb6a'),
(408, 'ru', '', 'Messenger settings', 'Настройки мессенджера', 'aad686b9a0ffcbc4015284a718e64ef4eec97e20'),
(409, 'ru', '', 'Mibew <span class="grey">Messenger</span>', 'Mibew <span class="grey">Мессенджер</span>', '3abd910b0f647a92a7ef98b62c50a7228cb54ebd'),
(410, 'ru', '', 'Mibew Messenger', 'Mibew Мессенджер', '5e7da8020ad604262f91307d9c89d20502334293'),
(411, 'ru', '', 'Mibew Messenger Community', 'Mibew Messenger Community', 'ffcd3f4a8934cfed33509d439462eb38a604650e'),
(412, 'ru', '', 'Mibew Messenger is an open-source live support application licensed under the terms of the Apache License 2.0.', 'Mibew Messenger - это приложение с открытым исходным кодом для консультирования посетителей сайта, доступное на условиях Apache Software License 2.0.', 'f5adcf4d8682059f50a1375a640d7fa36b816692'),
(413, 'ru', '', 'Mibew Messenger is an open-source live support application.', 'Мибью Веб Мессенджер это приложение для консультирования посетителей вашего сайта.', 'ebfe153ec0bc1f4e7400596e720c0b9637bde5b6'),
(414, 'ru', '', 'Mibew package is valid.', 'Контрольная сумма файлов проверена.', '4ed9a37841f6c400e0728f263328f341b2d84791'),
(415, 'ru', '', 'Misc', 'Разное', 'db6f2bf5a67359a0b93391bacda084866cf5d5a8'),
(416, 'ru', '', 'Missed threads', 'Диалогов пропущено', '69a9232d832913f4ecd93a58d76e93baee83cc4b'),
(417, 'ru', '', 'Modify', 'Изменить', '0c3fc634a15ea4f43839f6582fb16338513519e4'),
(418, 'ru', '', 'Name', 'Имя', '26319f16a623ec0417cbc86245e313855b635f08'),
(419, 'ru', '', 'Name in English.', 'Это название увидят ваши посетители из других стран.', 'dec98fb13901df251cec907924adbc183a27f058'),
(420, 'ru', '', 'Name is required.', 'Укажите имя.', 'f9c4e362f80efc66a4607c39bb8efa7e4bcd1eaa'),
(421, 'ru', '', 'Name of your company for example.', 'Например, название отдела вашей компании.', 'd2c0e1499b366c9b6a08cb880849c72c70421d26'),
(422, 'ru', '', 'Name to identify the group.', 'Может быть названием отдела в вашей компании.', '2baf2b4e3c876085386cef966370baee64325198'),
(423, 'ru', '', 'Name:', 'Ваше имя:', 'e739c4209118ceea40811a6fd44a71baf721fd22'),
(424, 'ru', '', 'Network problems detected. Please refresh the page.', 'Обнаружены проблемы с сетью. Пожалуйста, перезагрузите страницу.', 'd524b9adb40de1eb6c7bbcbedee41ed8750d72d6'),
(425, 'ru', '', 'Never', 'Никогда', '32dde8e495eb937fee841204e3030be14cd2a3b8'),
(426, 'ru', '', 'New Message', 'New Message', 'b7041de46568d591995c791b50d2528b534c8fae'),
(427, 'ru', '', 'New Visitor', 'New Visitor', 'd8e8bceae5b6c689ad17bfa41b37e6b1f257dd82'),
(428, 'ru', '', 'Next step:', 'Следующий шаг:', '9a3f408356bf99dabb8503918e01bf679367fdef'),
(429, 'ru', '', 'No elements', 'Нет элементов для отображения', '4ddc8773b103afb414e69a63bd328d346fc3f20f'),
(430, 'ru', '', 'No such Operator', 'Запрашиваемая учетная запись не существует', '7d3e9d971bbe3be0e5e3be351fd459fdd1261630'),
(431, 'ru', '', 'No such group', 'Такой группы не существует', 'bbfd468537c7cba284a5e578e33ed11c9254eb49'),
(432, 'ru', '', 'No such message', 'Сообщение, возможно, уже было удалено', '51545679648b31fdabc944899fcd483476d29ead'),
(433, 'ru', '', 'No. Close the window', 'Нет, закрыть окно', 'ca30524c2715edca01b1a34e62f5a688b93888b5'),
(434, 'ru', '', 'Not enough data', 'Мало данных', '0fb7cfc0f1db7d889d9ba8ce4af5efa6b1e08af8'),
(435, 'ru', '', 'Numbers of days this address is blocked', 'Количество дней, <br/> на которое будет запрещен адрес', 'e35b03d31cdb54762764170f524eeaecf0f30e30'),
(436, 'ru', '', 'OFFLINE', 'OFFLINE', '3c3c2aceb3aa3fa82db636f80c5c842bfeb2523a'),
(437, 'ru', '', 'ONLINE', 'ONLINE', '6f4d4599754169dcc8dd2d1e35b048216dfdbc22'),
(438, 'ru', '', 'Old browsers need to refresh the whole page to get messages. Default is 7 seconds.', 'Старым браузерам приходится перезагружать целиком диалог для получения новых сообщений. По умолчанию, 7 секунд.', '5ebe90e6cec1155b2918fd93281410e93ddedeb5'),
(439, 'ru', '', 'On this page you can configure locales which are used in the system', 'На этой странице вы можете настроить языки, которые используются в системе.', '6b694d5d39649522bcaaf69b57bc1957ed8725b6'),
(440, 'ru', '', 'On this page you can download translations.', 'На этой странице вы можете скачивать переводы.', '899dc6e0e1dd55cc934b36a69d4edd1108cb4118'),
(441, 'ru', '', 'On this page you can edit group details.', 'Здесь вы можете отредактировать детали группы.', 'ed5357f625235b64658019bd8fb11d2d1992aaf1'),
(442, 'ru', '', 'On this page you can edit mail templates which are used in the system.', 'На этой странице Вы можете изменить шаблоны писем, которые используются в системе.', 'e3f14d183f6e8eacb61cdc20a2b0d7ca7c938850'),
(443, 'ru', '', 'On this page you can upload a custom translation file.', 'На этой странице Вы можете загружать дополнительные файлы перевода.', 'e8fcfe7fae73f7466a72ac723852ba49f783f4eb'),
(444, 'ru', '', 'Online', 'Доступен', 'a3a51db87c62df1f8c4d47e52acbf66d273b9927'),
(445, 'ru', '', 'Operator', 'Оператор', '2530c6d429f40c9b6af190e209c51d23b7eddc48'),
(446, 'ru', '', 'Operator <strong>{0}</strong> changed operator <strong>{1}</strong>', 'Оператор <strong>{0}</strong> сменил оператора <strong>{1}</strong>', '2764b8d25cab396a3814353b0184548ed7257f7e'),
(447, 'ru', '', 'Operator canceled invitation', 'Оператор отменил приглашение', '022097f5ad5da3916b6b7e87728749e3660681c4'),
(448, 'ru', '', 'Operator details', 'Детали оператора', 'b64e7684e6230e16e441a801f0d823406725d151'),
(449, 'ru', '', 'Operator groups', 'Группы', '892482c5002228a97214c13858550ee8450b0462'),
(450, 'ru', '', 'Operator online time threshold', 'Временной интервал доступности оператора', '7c2305e5f8906224bee8cfdb5cd75bb7117bd6f3'),
(451, 'ru', '', 'Operator pages themes preview', 'Просмотр стилей страниц оператора', '8463c80115841c530ebd74eeb089640d42ab91a0'),
(452, 'ru', '', 'Operator {0} invites visitor at {1} page', 'Оператор {0} пригласил посетителя на странице {1}', '06c69ebd394503f4f3d9adf9f78e0ce8806ae03d'),
(453, 'ru', '', 'Operator {0} is back', 'Оператор {0} вернулся в диалог', '5830e7587a136dcde101fe8f363867da314eebbf'),
(454, 'ru', '', 'Operator {0} joined the chat', 'Оператор {0} включился в разговор', '962716d0eb6ac34203e3d020ed1301b95d0dd96a'),
(455, 'ru', '', 'Operator {0} left the chat', 'Оператор {0} покинул диалог', '653e1abb1cc97b6520849464773bdbcab73ab9cd'),
(456, 'ru', '', 'Operator {0} redirected you to another operator. Please wait a while.', 'Оператор {0} переключил Вас на другого оператора, пожалуйста, подождите немного', 'bc099b333d45d0783dc99bbde8b24f8afc5b7d5c'),
(457, 'ru', '', 'Operator''s console refresh time', 'Периодичность обновления консоли оператора', 'a4146aefd094a1742b3649884ce409aea64573e2'),
(458, 'ru', '', 'Operator:', 'Оператор:', '8470a21ed83df3a5c9e0a81350ee5664cb3086a2'),
(459, 'ru', '', 'Operators', 'Операторы', 'ce231660777b7040d00ee9174e9d2a312d7a43a6'),
(460, 'ru', '', 'Operators list', 'Список операторов', '8ec84c3512b63aa763a025f31055106a671d7cc4'),
(461, 'ru', '', 'Optional Services', 'Расширения', '7111f817e622ebd9336b5179692e4838d125a090'),
(462, 'ru', '', 'Other', 'Остальное', '5a953553fb82213b85116dfacd63386791a08d0b'),
(463, 'ru', '', 'Override existing translations', 'Заменять существующие переводы', '2ae1eaeaac0751d3130bf54b77948893b484eaa7'),
(464, 'ru', '', 'PHP version {0}', 'PHP версии {0}', '9c91edd5ce1bea7df8bd6c7950b432c09a00fd39'),
(465, 'ru', '', 'Page', 'Страница', '5fef9f993dc6aa02859747ea988c1acdbfc02cf0'),
(466, 'ru', '', 'Page refresh time for old browsers', 'Периодичность обновления всего диалога для старых браузеров', 'c7531757f401e2723b678fd0f2dd42c7ff3c4e23'),
(467, 'ru', '', 'Page {0} of {1}, {2}-{3} from {4}', 'Страница {0} из {1}, показаны {2}-{3} из {4}', '4d08ab0f9b5ad75243e162225da51c516d9c9611'),
(468, 'ru', '', 'Parent group', 'Родительская группа', 'd92a6272edb1ff89d7c4246ca850b63b2c2cec69'),
(469, 'ru', '', 'Password', 'Пароль', '44e1f58616859eb4ca70a2e52359cd9b190c004e'),
(470, 'ru', '', 'Password retrieval', 'Запрос на смену пароля', '80fb9943f1f63cc67726c4997666c4a9d19e8ff6'),
(471, 'ru', '', 'Password:', 'Пароль:', '22c83b7b32656159f5e10dd472154d5701732ee7'),
(472, 'ru', '', 'Performance', 'Производительность', '1adf600a44a6cf4d92aafcb519e15b5a73a85b37'),
(473, 'ru', '', 'Permissions', 'Возможности оператора', '41ff2b8959352a3c4030c1a4c014e2d43dbf5b04'),
(474, 'ru', '', 'Photo', 'Фотография', '07b02db3b5ad9b76dd62b9bb00d5941be9b4cb00'),
(475, 'ru', '', 'Please choose a password to use with your account.', 'Пожалуйста, выберите пароль для использования в вашей учетной записи.', 'b497b2aa3bc70e67fbd1fd5ea853edbf63b84952'),
(476, 'ru', '', 'Please choose another email because an operator with that email is already registered in the system.', 'Выберите другой адрес электронной почты, т.к. оператор с введенным адресом уже зарегистрирован в системе.', 'd234241320f828a745abc5860cebfc8c933c68fc'),
(477, 'ru', '', 'Please choose another login because an operator with that login is already registered in the system.', 'Выберите другой логин, т.к. оператор с введенным логином уже зарегистрирован в системе.', '9802cb94f974ec9c6838c2ac4d3e372cd5d0ce1a'),
(478, 'ru', '', 'Please choose another name because a group with that name already exists.', 'Пожалуйста, выберите другое имя. Группа с таким именем уже существует.', 'd587b1ac09a963a9af5fa0f5b244705e7f7d67fb'),
(479, 'ru', '', 'Please enter your company title', 'Введите имя Вашей компании', '784ff1288ee3a52b016e2788d3d284dde1ccc1a6'),
(480, 'ru', '', 'Please enter your username and password to access administrative tools. See your visitors and browse the history.', 'Пожалуйста, введите ваши имя и пароль для получения операторского доступа к системе.', 'ca6ce133d072ec0105496b375a2210238e8a087b'),
(481, 'ru', '', 'Please fill "{0}" correctly.', 'Неправильно заполнено поле "{0}".', '1c12a49dbf8edaf9d3a0eefbaa6efbc243075b94'),
(482, 'ru', '', 'Please fill "{0}".', 'Заполните поле "{0}".', '425ddca257809952cb45d754a2582b7315f47739'),
(483, 'ru', '', 'Please note that your web server should be configured to support https requests.', 'Ваш сервер должен быть настроен для обработки https запросов.', 'a0e8b693f2cc2e124fdfcafb9be86f9e0094427f'),
(484, 'ru', '', 'Please run the <a href="{0}">Update wizard</a> to adjust your database.', 'Пожалуйста, запустите <a href="{0}">Мастер обновления базы данных</a>.', '735666386b027a3e9eb23ad3e585d7e75aefa74a'),
(485, 'ru', '', 'Please use a more recent browser', 'Используйте более новый browser', 'cd39bcbe9d9177b795102e5cc772674639c0a563'),
(486, 'ru', '', 'Please, re-upload files to the server.', 'Попробуйте заново загрузить файлы на сервер.', 'bd799b5e783c3283d9522ee46a15e999d2383b34'),
(487, 'ru', '', 'Plugins', 'Плагины', '1db1191afa4146293d6a9a2407fd90bc17e26ac3'),
(488, 'ru', '', 'Plugin "{0}" cannot be disabled.', 'Плагин "{0}" не может быть отключен.', 'eb64a2f8ea3313eb79d99ed7d25367cbb4c1fcfd'),
(489, 'ru', '', 'Plugin "{0}" cannot be enabled.', 'Плагин "{0}" не может быть включен.', '8d6d04a2f60367694082194e7cabe88c1aeebddf'),
(490, 'ru', '', 'Plugin "{0}" cannot be uninstalled.', 'Плагин "{0}" не может быть удален.', '98bb28cd37bbcbf618b72a66e3fd76f43b5366f4'),
(491, 'ru', '', 'Plugin "{0}" cannot be updated.', 'Плагин "{0}" не может быть обновлен.', '73a2f3a54462dcd814230cd2ad2ec1d6f7b26f1d'),
(492, 'ru', '', 'Powered by:', 'Предоставлено:', 'a18ba47462d97eff568ab19b900b0507274c611b'),
(493, 'ru', '', 'Pre-chat survey', 'Форма опроса посетителя перед началом диалога', 'becc213e4491a695763eeac1a2d939e5de78e793'),
(494, 'ru', '', 'Priority visitors'' queue', 'Приоритетная очередь посетителей', '7de04271856742c0765b6d7913da14066bf23227'),
(495, 'ru', '', 'Problem', 'Ошибка', '89b2b2eba5ac77c4f0c2497876dac66cf3356ec2'),
(496, 'ru', '', 'Proceed to login', 'Войти в систему', 'f43f0342f8ba104e240d08a34a52201adeb653bc'),
(497, 'ru', '', 'Proceed to the login page', 'Войти в систему', 'f74c551e7c9018c47a7bc0ed09065a6259d24bed'),
(498, 'ru', '', 'Profile', 'Профиль', '7839019d8fcc0a2803fab443cc3a2096d5871d76'),
(499, 'ru', '', 'Protection against automated spam (captcha)', 'Защита от автоматизированного спама (captcha)', 'ccd0472b9311699cfcc387b33e9db4ce481e97d1'),
(500, 'ru', '', 'Reason for block', 'Причина запрета', 'cc4958250cce4659f4519863279b985a362835d5'),
(501, 'ru', '', 'Redirect to<br/>another operator', 'Перенаправить<br/>другому оператору', '07db3441492d614d5b0ccbd238b4cbb522c31106'),
(502, 'ru', '', 'Redirect visitor to another operator', 'Перенаправить посетителя другому оператору', '7c14d7a22564b13d8c9f9dc35a3fdaa326474106'),
(503, 'ru', '', 'Redirect visitor to another operator window', 'Redirect visitor to another operator window', '98b43f17a930688d1b9727e7a68cd3c5005dd73b'),
(504, 'ru', '', 'Refresh', 'Обновить содержимое диалога', '2ed98355fa92dbb4f739016e7971439d15c4da30'),
(505, 'ru', '', 'Remember', 'Запомнить', '708b05607fd919d2b6fdda1236dcca3f79b06fd4'),
(506, 'ru', '', 'Remote user is typing...', 'Ваш собеседник набирает текст...', '06ebf7eb1b48ea7ae9d3c959ed1c783b08610941'),
(507, 'ru', '', 'Remove avatar', 'Удалить аватарку', 'aee5d4f424f4b854372194db0306bbb46f4e8428'),
(508, 'ru', '', 'Replaces translated strings in the database with values from the imported file.', 'Заменяет переведенные строки в базе данных значениями из импортируемого файла.', '0976668d13536380b3ca6665a7c4de559f0f229d'),
(509, 'ru', '', 'Required tables are created.', 'Необходимые таблицы созданы.', 'ea113a7002f46e02428abc33c7d58ac667265671'),
(510, 'ru', '', 'Reset password', 'Поменять пароль', '0f754dec1210cefff2967ecdf5e1ee0ee5f2e24a'),
(511, 'ru', '', 'Resolve the problem and try again. Press <a>back</a> to return to the wizard.', 'Исправьте проблему и попробуйте еще раз. Нажмите <a>назад</a> чтобы вернуться к мастеру установки.', '2dc56c253fb8031d1be3ee8978520402569d20ad'),
(512, 'ru', '', 'Save', 'Сохранить', '2ff329d1091e5230a6986de6153cc54a008b1dfc'),
(513, 'ru', '', 'Saved', 'Сохранено', 'a25431a4cd8d3bc0ccc0eefe78f24b239eca732e'),
(514, 'ru', '', 'Search', 'Искать', 'dfb3ada0cc3cf3b395cd07bcd41675e0c93c6826'),
(515, 'ru', '', 'Search in system messages', 'Искать в системных сообщениях', '1899e62d3a940b29658199683dfa71d04b63c0cd'),
(516, 'ru', '', 'Search the chat history for a specified user, an operator or a specified phrase in messages.', 'На данной странице можно осуществить поиск диалогов по имени пользователя, имени оператора или фразе, встречающейся в сообщении.', '9eada29876e50925f5d1cd8741c9b58c2cfb4d55'),
(517, 'ru', '', 'Search the dialogs history.', 'Поиск по истории диалогов.', '7a7a6438b4ad4de9793a14adb0eac9126f0ac7d3'),
(518, 'ru', '', 'Search:', 'Искать:', '406da68f4b5e56ca2a9b5a014d1a517e9a6b20bd'),
(519, 'ru', '', 'Select a style for your chat windows', 'Выберите вид вашего чат окна', '6429b7b60fcece02cbd16368bed9ea26b14f8766'),
(520, 'ru', '', 'Select a style for your invitation', 'Выберите вид приглашения', '9ccedfef951314ed6d4b9bbcf3c8d865d411a8d0'),
(521, 'ru', '', 'Select a style for your operator pages', 'Выберите стиль страниц оператора', '6ad9374eba127c6973798920a8e33874d4e6da64'),
(522, 'ru', '', 'Select answer...', 'Выберите ответ...', '534f25df4a08bc0374a03f2b8219488130a9a0ab'),
(523, 'ru', '', 'Select dates', 'Выберите даты', '2f3ddc94da849af1e34ca88fda914ec87a2253b8'),
(524, 'ru', '', 'Send', 'Отправить', 'bcdef17e6dced7988df88b8bf2f9c7c6266149f4'),
(525, 'ru', '', 'Send ({0})', 'Отправить ({0})', 'f06a87a9ec369d745327048cbce09291784f00c5'),
(526, 'ru', '', 'Send chat history by e-mail', 'Отправить историю диалога по электронной почте', '832266ff65cd9aa79e1a713e4cc23bde23873300'),
(527, 'ru', '', 'Send chat history<br/>by mail', 'Отправить историю разговора<br/>на почтовый ящик', 'a9ef1951ef2b5ac8dc59fda1aecba54a0b42c2a4'),
(528, 'ru', '', 'Send message', 'Отправить сообщение', 'eca32412751278f907f4c0da87f044c8392c6f14'),
(529, 'ru', '', 'Send messages with:', 'Посылать сообщение по:', '7ecc11607d6c59f577e66e31f281ac475ae37498'),
(530, 'ru', '', 'Sent', 'Отправлено', 'acabe2b1ff4303176f3e24103bb226ba6a38ecd1'),
(531, 'ru', '', 'Set status as "Available"', 'Выставить статус "Доступен"', '78064a7b089e1332d3bc0b6a40a1efee294a789b'),
(532, 'ru', '', 'Set status as "Away"', 'Выставить статус "Отошел"', '57ab669fd62f90d4d3ff961a7813f29447a4f06e'),
(533, 'ru', '', 'Set the number of seconds to show an operator as online. Default is 30 seconds.', 'Количество секунд, в течение которых оператор определяется как онлайн после последнего обновления. По умолчанию, 30 секунд.', 'c7bd3aad84c16abc304b90bd5f4445a1554b5372'),
(534, 'ru', '', 'Set the number of seconds after the last ping to consider the chat window still connected. Default is 30 seconds.', 'Количество секунд с момента последнего пинга, в течение которых окно чата считается подключённым. По умолчанию, 30 секунд.', '879317355ab831b0aff4d92b5a43a600448e0256'),
(535, 'ru', '', 'Settings', 'Настройки', 'ad5f0c1985543192b7dc5460723e57ca76d2d7e6'),
(536, 'ru', '', 'Show chats only through https connection', 'Показывать чаты используя только защищенное соединение', 'bb0f6dd84966b87312c0ec903310e3a170d3f37f'),
(537, 'ru', '', 'Show errors', 'Отобразить ошибки', 'faa1c73e11aaa6db0bc6b10ebc93984a699ca208'),
(538, 'ru', '', 'Show initial question field', 'Предлагать сразу же задать вопрос', '6deb048bb91a5a2abf9ffec828c1df80e70b8cd7'),
(539, 'ru', '', 'Show menu', 'Показать меню', '20421fef33d6f2e753745202bc9e217f551e21f0'),
(540, 'ru', '', 'Show menu >>', 'Показать меню >>', '2298ba4dd05aec1b912af59051b414990bd96425'),
(541, 'ru', '', 'Show online operators on "List of awaiting visitors" page', 'Показывать доступных операторов на странице ожидающих посетителей', 'e7130d50cd56c70c507001a6ccafe7889ee80b10'),
(542, 'ru', '', 'Show/hide department selection field in the survey', 'Показать/спрятать выбор группы в диалоге перед началом чата', 'b4167183de381f59df3b8c4959d2b6567e8c4e27'),
(543, 'ru', '', 'Show/hide email field in the survey', 'Показать/спрятать поле ввода адреса электронной почты', '8449325b447c014f238c5e67143e786ab2a7d3f4'),
(544, 'ru', '', 'Show/hide initial question field in the survey', 'Показать/спрятать поле ввода первого вопроса', 'd3352afd19386393bf6cb716a804c83e58d56e31'),
(545, 'ru', '', 'Show:', 'Показать:', 'd866a2b4e04a2631aece89a04cba9752e3a50f0c'),
(546, 'ru', '', 'Simple chat window. Refresh to post messages (IE 5, Opera 7)', 'Simple chat window, refresh to post messages (IE 5, Opera 7)', '6448117a9efde7428d6f98455269a93ac699a3d8'),
(547, 'ru', '', 'Site consultant', 'Консультант сайта', 'f4c55f71b20c6c1562b3b7e21e9724889f13ece1'),
(548, 'ru', '', 'Site style', 'Стиль мессенджера', 'ea9e430bc33f5f3521c7f8651c82f662b6048155'),
(549, 'ru', '', 'Small dialog appears to attract your attention.', 'Позволяет привлечь ваше внимание, если звукового и визуального оповещения недостаточно.', 'fdb2b06ba4b1dea034ae36b27ec47b74333b469f'),
(550, 'ru', '', 'Software license agreement', 'Лицензионное соглашение о программном обеспечении', '58f24fdf6f0cece0ad263cb9519811303f8882a6'),
(551, 'ru', '', 'Sorry. None of the support team is available at the moment. <br/>Please leave a message and someone will get back to you shortly.', 'К сожалению, сейчас нет ни одного доступного оператора. Попробуйте обратиться позже или оставьте нам свой вопрос и мы свяжемся с Вами по оставленному адресу.', '2c0fc6685d70d108789d9ed1f26d2980434ce357'),
(552, 'ru', '', 'Sort by:', 'Сортировка:', '74328eb1a02360378ee7ba0b42a220dbf9ac791a'),
(553, 'ru', '', 'Sort direction:', 'Направление сортировки:', '497b420a4d19539cb7a345c0d4ccd63be2c1c5b2'),
(554, 'ru', '', 'Sound on/off', 'Вкл/выкл звук', '5ddde1d95daae453ee8f763fc1191b0976c29386'),
(555, 'ru', '', 'Source language string', 'По строке из первого языка', 'ff96e1b5ce59336741fe4058f84918f08979664a'),
(556, 'ru', '', 'Source string', 'Исходная строка', '5f27798f9dbf16ea485aea07e87f7d0fe2ddb1a9'),
(557, 'ru', '', 'Specify options affecting chat window and common system behavior.', 'Здесь вы можете задать опции влияющие на отображение чат окна и общее поведение системы.', '72fd95a3986d1bfcd964343c0926dc00f986202c'),
(558, 'ru', '', 'Specify the lifetime of invitation in seconds. Default is 60 seconds.', 'Укажите срок действия приглашения к диалогу в секундах. По умолчанию, 60 секунд.', '3f36261613d64e02ae6f6e4786d1dd7aad7a7fd9'),
(559, 'ru', '', 'Specify the lifetime of old visitor''s tracks in seconds. Default is 600 seconds.', 'Укажите срок хранения старых отслеженных путей в секундах. По умолчанию, 600 секунд.', '21462d4f542916c2a747e55eec3cac8ac3092cd9'),
(560, 'ru', '', 'Specify the lifetime of the thread after closing the dialog box in seconds. Default is 600 seconds. Set 0 for unlimited thread lifetime.', 'Укажите время жизни диалога после закрытия диалогового окна в секундах. По умолчанию, 600 секунд. Укажите 0 для снятия ограничения.', 'cc9f73bc29e97cff438b079ad6a0ca1a687b5884'),
(561, 'ru', '', 'Specify the number of items to display in tracked visitors list. Default is 20. Set 0 for all visitors (not recommended).', 'Укажите количество выводимых в списке отслеживаемых посетителей сайта. По умолчанию, 20. Укажите 0 для снятия ограничения (не рекомендуется).', '1194b30048216c3163f5c094796ef14eaed5e0d2'),
(562, 'ru', '', 'Specify the poll interval in seconds. Default is 10 seconds.', 'Укажите частоту опроса блока слежения за посетителями в секундах. По умолчанию, 10 секунд.', '8199addbd627ff9bce7e777d34ee414ac16b89e0'),
(563, 'ru', '', 'Specify the poll interval in seconds. Default is 2 seconds.', 'Укажите частоту опроса сервера в секундах. По умолчанию, 2 секунды.', '323a5700ed97e580d2c9cdbce81da9c516cfe095'),
(564, 'ru', '', 'Start Chat', 'Начать диалог', 'c00d089415ba150c11b945971affc7c09be80317'),
(565, 'ru', '', 'State', 'Состояние', 'b3cd03fab928215ed2aca28773392df8fa5daf6b'),
(566, 'ru', '', 'Statistics', 'Статистика', '0901a3317fce7ad533ab69a21bbd4cedfef9e7fd'),
(567, 'ru', '', 'Strings for administrator', 'Строки для администратора', '08de430b9c1edeb365a3365e5af1cbb49f7a588a'),
(568, 'ru', '', 'Strings for operator', 'Строки для оператора', '8ece7662d08d6f5ae8c95aa68e30bc8d548d2022'),
(569, 'ru', '', 'Strings for visitor', 'Строки для посетителя', '584f8ffee466109b945746a9bbe35714fa813ea9'),
(570, 'ru', '', 'Structure of your tables should be adjusted for new version of Messenger.', 'Необходимо обновить структуру таблиц для корректной работы Веб Мессенджера.', '5ebb56452e8953f2bee8a6c02a3d73629d815ecf'),
(571, 'ru', '', 'Styles', 'Стили', '36a0c7dd1bf1f8436844fbe28945efcc14c27f30'),
(572, 'ru', '', 'Submit', 'Передать', 'ddda1709b474298545a517005b32c6ea97a9fd11'),
(573, 'ru', '', 'System administration: settings, operators management, button generation', 'Администрирование системы: настройка, управление операторами, генерация кнопки', 'c70732096ed73ad13701f1ae79613a4bfc3b6503'),
(574, 'ru', '', 'System information', 'Информация о системе', '178787dd5153573f00585d14e32a0bbd9735e0a2'),
(575, 'ru', '', 'System will check updates for the core and plugins automatically using cron', 'Система будет проверять обновления для ядра и плагинов автоматически с использованием cron', '12661ae6ee820921910220cf6a83e0374ad6d54a'),
(576, 'ru', '', 'Tables structure is up to date.', 'Структура таблиц готова к использованию.', '81c663a6027a72d6fc1c462edaeacdbee91e91d2'),
(577, 'ru', '', 'Take over chat thread', 'Перехватывать диалоги у других операторов', '1c47fe44d36ee9b66a200b11591bd34808e13700'),
(578, 'ru', '', 'Thank you for contacting us. An operator will be with you shortly.', 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '65dd68172d55b2476375fcff35ed85d48694d768'),
(579, 'ru', '', 'Thank you for contacting us. Please fill out the form below and click the Start Chat button.', 'Спасибо, что связались с нами! Заполните, пожалуйста, небольшую форму и нажмите "Начать диалог".', '75fe89f322736596792a79109ad9e2dbf4fa04dd'),
(580, 'ru', '', 'Thank you for contacting us. We are sorry, but requested operator <strong>{0}</strong> is offline. Another operator will be with you shortly.', 'Нам очень жаль, но запрошенный оператор <strong>{0}</strong> сейчас недоступен. Пожалуйста, подождите немного, к Вам присоединится другой оператор...', '0105dd82078472cc07dd584eba516f6c7b47898a'),
(581, 'ru', '', 'Thank you for your message. We''ll answer your query by email as soon as possible.', 'Спасибо за ваш вопрос, мы постараемся ответить на него как можно быстрее.', '1720ed6fa9314a08f88ee79ad8efc5562136e37d'),
(582, 'ru', '', 'The database was not found on the server. If you have permissions to create it now, click on the following link.', 'База, которую вы выбрали не существует на сервере. Если у вас есть права <br/>на ее создание, ее можно создать сейчас.', 'f7424156f5bdc11ad9022815c90a0fb193dcb74a'),
(583, 'ru', '', 'The fields that located below are extra fields. These fields are only available for the top level groups and override corresponding system settings if specified.', 'Поля, расположенные ниже - дополнительные. Эти поля доступны только для групп верхнего уровня и, если заданы, переопределяют соответствующие настройки системы.', 'bd6f5a8ffeebd56107f78946540efd2de3942db1'),
(584, 'ru', '', 'The letters you typed don''t match the letters that were shown in the picture.', 'Введенные символы не соответствуют изображению.', 'c2f114c62ffb20308dbc709113f0f2b54c35316b'),
(585, 'ru', '', 'The list of visitors waiting is empty', 'В этой очереди ожидающих посетителей нет', '5ad6fd68b2a4100589e1137c1abc0ce8923ee77b'),
(586, 'ru', '', 'The specified address is already in use. Click <a href="{1}">here</a> if you want to edit it.', 'Адрес уже зарегестрирован в системе, нажмите <a href="{1}">здесь</a> чтобы отредактировать его.', '8c8b132b6457150b69614279f8a0a337c4b639fd'),
(587, 'ru', '', 'The table below represents a list of visitors ready to chat on your site.', 'В расположенной ниже таблице представлен список готовых к диалогу посетителей на Вашем сайте.', '72c2ea52e04d32ee806bd736a7c43e52fe39c62e'),
(588, 'ru', '', 'The upper limit of uploaded files (avatars) in bytes. Default is 100000 bytes.', 'Верхний лимит загружаемых файлов (аватарок) в байтах. По умолчанию, 100000 байтов.', '6f4b171d2f8c61bea83cdcd8aa035ba24416ee30'),
(589, 'ru', '', 'The visitor changed their name <strong>{0}</strong> to <strong>{1}</strong>', 'Посетитель сменил имя <strong>{0}</strong> на <strong>{1}</strong>', '39ca4bb2d7c823c6dd308f3bbe859a5c9885dfd7'),
(590, 'ru', '', 'The visitor has been placed in a priorty queue of the group {0}.', 'Посетитель помещен в привелегированную очередь группы {0}.', '7c395adf73c5f322ffa39440a8c7dcc97a8e1ec9'),
(591, 'ru', '', 'The visitor has been placed in the priorty queue of the operator {0}.', 'Посетитель помещен в привелегированную очередь оператора {0}.', 'de81d3da3e8598b1d042e4277f5b04c80a07e472'),
(592, 'ru', '', 'The visitor has been redirected to another operator', 'Посетитель переведен другому оператору', '924562c766e91615d550ef9b68ec8e6b8be84869'),
(593, 'ru', '', 'There is no available updates.', 'Нет доступных обновлений.', 'dbc263fa67529f59ff83ad1672312c1992e04b90'),
(594, 'ru', '', 'There are no visitors ready to chat on your site at present time', 'В настоящее время на Вашем сайте нет готовых к диалогу посетителей', '6aed5dfb43fd55abd54f23565d81dd799ad826de'),
(595, 'ru', '', 'There are so many browsers to choose from. Which ones do you recommend?', 'Посоветуйте мне, пожалуйста, хороший браузер?', '1a0292afff43f6a7477049f459c5867d6b7b2ef6'),
(596, 'ru', '', 'This name will be seen by your visitors.', 'Под этим именем Вас увидят ваши посетители, по нему же к <br/>Вам будет обращаться система.', '7e92c46d48040c2632dd70e61410753b8638125e'),
(597, 'ru', '', 'This page displays a list of company operators.', 'На этой странице можно просмотреть список операторов компании и добавить нового при наличии соответствующих прав доступа.', '6c5079c87093a0a4608591b722120ea998b753c9'),
(598, 'ru', '', 'This page displays a list of groups. Each group can have separate button and canned responses.', 'На этой странице вы можете управлять группами операторов. Каждая группа может иметь отдельную кнопку начала чата и свои шаблоны ответов.', '6fce237520b0d755b517789f12d43c38201b5233'),
(599, 'ru', '', 'This page displays a list of visitors who are waiting.', 'На этой странице можно просмотреть список ожидающих ответа посетителей.', 'b2b539cb829c876d6f9f6a8d3d9d42b5b4308aef'),
(600, 'ru', '', 'This page displays chat details and content.', 'На данной странице Вы можете просмотреть диалог.', '00d7565db97437c715ec788e6b65bc2884a6973d'),
(601, 'ru', '', 'This page displays tracked history of visitor''s activity on site.', 'На этой странице отображается отслеженная история активности посетителя сайта.', '2be039b1ca88f71f903b7dab991dedea0d347b2d'),
(602, 'ru', '', 'This value will be passed to PHP''s setlocale function to localize words in date/time string.', 'Это значение будет передано PHP функции setlocale для перевода слов в строках даты/времени.', 'd7fd82898af34891d9458d337358ec2931f891f9'),
(603, 'ru', '', 'This value will be used with PHP''s strftime to format date only.', 'Это значение будет использовано в PHP функции strftime для форматирования даты.', '7ecbd0fc13e1cc0631653a26fa5b0c66ca493798'),
(604, 'ru', '', 'This value will be used with PHP''s strftime to format date with time.', 'Это значение будет использовано в PHP функции strftime для форматирования даты и времени.', '2cd1218f10bd77da98367fc1c4e636290e3cdeeb'),
(605, 'ru', '', 'This value will be used with PHP''s strftime to format time only.', 'Это значение будет использовано в PHP функции strftime для форматирования времени.', '26f3b782b8d487e0c4f289b30c72611702fad55a'),
(606, 'ru', '', 'Thread lifetime', 'Время жизни диалога', 'f42af512ae24c2d30f7e9510a2c87da4f1283541'),
(607, 'ru', '', 'Threads by operator', 'Статистика по операторам', '38205bb2b7273affed6c666d18baa78ceeb712d6'),
(608, 'ru', '', 'Till', 'До', 'c2d4aafb3aaf1b6cdf658296bced5adc20ba0fd2'),
(609, 'ru', '', 'Till:', 'По:', 'f271178b97a337b3841e21791827ca330d11eb1f'),
(610, 'ru', '', 'Time in chat', 'Время в диалоге', 'cbd29c0a1d495fbc4564bd0019da04d7f57f1ab0'),
(611, 'ru', '', 'Time locale', 'Язык времени', '71945b8d492dd0df58a20dd6e3878708b14fd8f4'),
(612, 'ru', '', 'Title', 'Заголовок', '041022bafd417c227f327dd9e945629e5de3d255'),
(613, 'ru', '', 'Title in the chat window', 'Заголовок в чат окне', 'faa11b0ba481e5c5cd4e666e7a52da687daeaf39'),
(614, 'ru', '', 'To answer the visitor click their name in the list.', 'Для ответа посетителю кликните на соответствующее имя в списке.', '1e0e76f22ddf95127061e5695f6ec7eba879608f'),
(615, 'ru', '', 'To invite the visitor to chat click on his/her name in the list.', 'Для приглашения посетителя к диалогу кликните на его или её имя в списке.', '21c7549f3ff09c262de133c4271b3584a4466eb1'),
(616, 'ru', '', 'To run cron use link <a href="{0}">{0}</a>.', 'Для запуска cron используйте ссылку <a href="{0}">{0}</a>.', '78852443c14ce394a8b25799b7d8f084a6b7e29f'),
(617, 'ru', '', 'Today at {0}', 'Сегодня в {0}', '03ce938f4a88811f6d20c9effb2881f8c8883311'),
(618, 'ru', '', 'Total time', 'Общее время', '3a4a7883e608b6f49a05d31d0180d62e9eceac74'),
(619, 'ru', '', 'Total:', 'Итого:', 'a1460dc13712365c168b779455c9831cdd73e233'),
(620, 'ru', '', 'Track lifetime', 'Срок хранения отслеженных путей', '24a545303495e58062efdedfc8ae727cb99f074f'),
(621, 'ru', '', 'Track operators', 'Отслеживать операторов', '3027ca2b60ddd6cf7e2e0c0145ff7b2c92f3bf4f'),
(622, 'ru', '', 'Tracked path of visitor', 'Отслеженный путь посетителя', 'cf8e873396623e9655f6dbc65ff531bdce5b9f37'),
(623, 'ru', '', 'Tracked visitor''s path', 'Отслеженный путь посетителя', '9f94a98b3a16805ed8c7be4da65bdd27b471aaa5'),
(624, 'ru', '', 'Tracking refresh time', 'Периодичность опроса блока слежения', '43b7dba93ec84dd83a2ddc25f28719e59733a8d5'),
(625, 'ru', '', 'Translation', 'Текст перевода', 'a41eeaba30198c1654ea1c5b8400a9274c40ac9f'),
(626, 'ru', '', 'Translations', 'Переводы', 'a64d339f5962a1848051660a0baf97188ac4310b'),
(627, 'ru', '', 'Translations export', 'Экспорт переводов', 'e372a6562554fddccd0ebe9d7afff0842a1db000'),
(628, 'ru', '', 'Translations import', 'Импорт переводов', 'bca87a88cc8329adf933fa1ca5221f9cf98e59bc'),
(629, 'ru', '', 'Translation imported', 'Перевод импортирован', 'e6683744778dbb77caedc357b062040c6f6c64f2'),
(630, 'ru', '', 'Trouble Accessing Your Account?', 'Не можете войти?', '84432eedf1cd6d3c5ef4f4dd1008d319998046b9'),
(631, 'ru', '', 'Turn off sound', 'Выключить звук', 'b01d8e38959c329dfdcec36e162fce96cdd0963f'),
(632, 'ru', '', 'Turn off to hide edit box from chat window', 'Возможность убрать поле смены имени из чат окна', '5cbdfa2c7a433562a294fe7013077c4844d9a522'),
(633, 'ru', '', 'Turn on sound', 'Включить звук', '811249bd7fb54c23b574c7220dda858d49eaf16a'),
(634, 'ru', '', 'URL of your website', 'Ссылка на ваш веб сайт', '117d772d619581e87e0f0fe63189aaa8b727d793'),
(635, 'ru', '', 'Uninstall all the dependencies first', 'Сначала удалите все зависимости', '3c84ce34777b35b6efaf95943c3a5a5173f4980e'),
(636, 'ru', '', 'Up to date', 'Доступен', '00b67fc3faeac90370823d97ba8d51ec4ba179ff'),
(637, 'ru', '', 'Update all the dependencies first', 'Сначала обновите все зависимости', '5e7250a585148c0d68972e215b98102f5c41f13a'),
(638, 'ru', '', 'Update tables', 'Обновить', 'fbf321a12351e730cec287641b776f131fe16052'),
(639, 'ru', '', 'Upload', 'Загрузить', 'd868f7d1d8b37d09b0bef24eacd48abc56065dab'),
(640, 'ru', '', 'Upload avatar', 'Загрузить аватарку', '30000e81c72220ef20eac110c478eea0d08af772'),
(641, 'ru', '', 'Upload photo', 'Загрузка фотографии', '895541624136b6f03b3ae27f7f81492e14410efd'),
(642, 'ru', '', 'Upload translation', 'Загрузить перевод', '7e52a6fc8c2e52ea5c1d15d8629a0b6805b4d4c0'),
(643, 'ru', '', 'Uploaded file size exceeded', 'Превышен допустимый размер файла', '658e7ca7c139f1dd533e1982c72d2fa21d636776'),
(644, 'ru', '', 'Usage statistics for each date', 'Использование мессенджера по дням', 'de7d78b75b4267ba137f6e914b5964f2d1ca97dc'),
(645, 'ru', '', 'Use it to completely isolate groups from each other.', 'Позволяет полностью изолировать группы друг от друга.', '54cd6f74f5c6a42a5631c2fdeb52ac8a29adc20d'),
(646, 'ru', '', 'Use it to have separate queues for different questions.', 'Позволяет объединять операторов в группы и организовывать для них отдельные очереди.', '3dae8defb7ac46149c1f9e1a88430bc8738d2090'),
(647, 'ru', '', 'Use only Latin letters(upper and lower case) and numbers in cron key.', 'Используйте только Латинские буквы(верхнего и нижнего регистра) и цифры в ключе безопасности cron.', '189a6127393eb0de9dcbbbdd3d562f5c0dcdd6cf'),
(648, 'ru', '', 'Use secure links (https)', 'Использовать защищенное соединение (https)', '3dfa569ae0a7fc11a37188d8a5f9caa86711ff47'),
(649, 'ru', '', 'Use to start chat with determined operator', 'Используется для начала диалога с определенным оператором', '9e58cb7b4e678f49dbd2435c520e31d5ac54c891'),
(650, 'ru', '', 'Use windows (even for modern browsers)', 'Использовать всплывающие окна (даже для современных браузеров)', '8f30d6c99f4e313183b26641fd8908492170cd9e'),
(651, 'ru', '', 'User name, operator name or message text search:', 'Поиск по имени посетителя, имени оператора или по тексту сообщения:', 'b3307a1c5463b6d3556b1978ddaa4e86bd988f18'),
(652, 'ru', '', 'Using it you can block attacks from specific IPs', 'С ее помощью можно блокировать атаки с определенных адресов', 'e969e153a70296b065586cfcb67dfa0df9ff06e3'),
(653, 'ru', '', 'Version', 'Версия', '684f961804b49cc8754816c85e0a8f2431707e69'),
(654, 'ru', '', 'View Chat window (operator in read-only mode)', 'Окно просмотра чата (для оператора)', '464c4380fd3513376d9bd9efd4725f3f3fa4f788'),
(655, 'ru', '', 'View about page.', 'Посмотреть страницу с информацией о программе.', 'dee21da475b031615a5ac44cc96aa219975d2da2'),
(656, 'ru', '', 'View and edit the member list.', 'Выберите операторов, которые будут составлять эту группу.', 'fd40960d2c55797aae1d6322717649ce994a2d30'),
(657, 'ru', '', 'View another operator''s chat thread', 'Просматривать диалоги других операторов в режиме реального времени', '83f33cf99a54471fea1a69537aae00e376561d6d'),
(658, 'ru', '', 'View times', 'Просмотров', 'f74fc564b222fbe66fa6a581c85b19cf1e88179f'),
(659, 'ru', '', 'Visit history', 'История диалогов', 'b377458dedb20d55fc911c7b62e1229ce1327ec8'),
(660, 'ru', '', 'Visit time', 'Время визита', 'df2705caae367256e38bf28b063597968e2a6906'),
(661, 'ru', '', 'Visit your <a href="{0}">Profile Page</a>.', 'Посетите свой <a href="{0}">Профиль</a>.', 'e94008f46d0f2ce3f7e249e21cd660edf73df4cf'),
(662, 'ru', '', 'Visited page', 'Посещённая страница', '7767310be3ac7850a59723ffd438ed7cddbef791'),
(663, 'ru', '', 'Visitor <span class="visitor">{0}</span> is already being assisted by <span class="operator">{1}</span>.<br/> Are you really sure you want to start chatting the visitor?', 'С посетителем <span class="visitor">{0}</span> уже общается <span class="operator">{1}</span>.<br/>Вы уверены что хотите сменить его?', 'b38c08bbb4a65367b5ed94498c31c684f8fcc123'),
(664, 'ru', '', 'Visitor accepted invitation from operator {0}', 'Посетитель принял приглашение от оператора {0}', '851505c075a7da44d011860def7d9c3010089252'),
(665, 'ru', '', 'Visitor came from', 'Посетитель пришёл со страницы', '934d87de3f74839db468b7fe049a4ffb4dd33ca5'),
(666, 'ru', '', 'Visitor closed chat window', 'Посетитель закрыл окно диалога', '4bef6c84e99213a1f4cfd65c7c5cc1dcc5e671f0'),
(667, 'ru', '', 'Visitor ignored invitation and it was closed automatically', 'Посетитель проигнорировал приглашение и оно было закрыто автоматически', '75591199f741313ab7f7d07341fc0c2cc703eae6'),
(668, 'ru', '', 'Visitor joined chat again', 'Посетитель заново вошел в диалог', 'a8e09faa7c5f3ab55ccdabef63135bae13056852'),
(669, 'ru', '', 'Visitor navigated to {0}', 'Посетитель перешел на {0}', '65f78e7a2f319ea5b70da7d9395d9f86248df67a'),
(670, 'ru', '', 'Visitor rejected invitation', 'Посетитель отклонил приглашение', 'bcbc4d7b9ca23c11fb09357c2976a7e10acfd1d0'),
(671, 'ru', '', 'Visitor {0} left the chat', 'Посетитель {0} покинул диалог', '3bf08645b7811ff89c2667487c8aeae2c063db85'),
(672, 'ru', '', 'Visitor''s Address', 'Адрес посетителя', 'fda5573299a5384e5530e9bda58a8f58f5b8699c'),
(673, 'ru', '', 'Visitor''s address', 'Адрес посетителя', '9c897d24653e317b9d1820cea281237a1e9dcf7c'),
(674, 'ru', '', 'Visitor''s identifier', 'Отображаемое имя посетителя', 'fc458dc6a7cff4e502d179065da28a640873dc72'),
(675, 'ru', '', 'Visitor''s messages', 'Сообщений посетителя', 'f7f230c84c106c35b21299380120c7bcc5876308'),
(676, 'ru', '', 'Visitors', 'Посетители', 'ec9e570618db7c5a434d2ee73229423c515617c3'),
(677, 'ru', '', 'Visitors in dialogs', 'Посетители в диалогах', '1bb39a8084be6021af93f54faf6ab26974d9f717'),
(678, 'ru', '', 'Visitors on site', 'Посетители на сайте', '05ed54e794c0fd7aee7e76e102b82b178c10bdc0'),
(679, 'ru', '', 'Vistor came from page {0}', 'Посетитель пришел со страницы {0}', 'a95533f14c27cebf1f1e2292e99bcaa38b0f70f8'),
(680, 'ru', '', 'Waiting an operator for the first time', 'Ожидающие оператора в первый раз', '6bcdeb8e531dd98f028328ca0446e2f126c826b3'),
(681, 'ru', '', 'Waiting for operator', 'Ожидание оператора', '2b96aecb3e807e6e0a4c26fe40d8561729ef2eb6'),
(682, 'ru', '', 'Waiting time', 'Время ожидания', '2ef6afa7b980f2bcb3975de362b05bd5c5bd7227'),
(683, 'ru', '', 'Watch the chat', 'Подключиться к диалогу в режиме просмотра', 'b10704a6288bdec73518631fa042c1c31ce4c51e'),
(684, 'ru', '', 'We''ve sent the instructions to your email. Please check it.', 'Мы отправили инструкции по смене пароля на ваш почтовый адрес. Проверьте ваш почтовый ящик!', 'f8e678ed60b6304f28ba03832529efe4de470dca'),
(685, 'ru', '', 'Weight', 'Вес', 'd71b1605e4162820ab52b8d0dbbde645bdbe19e1'),
(686, 'ru', '', 'Window size and toolbars hiding', 'Размер окна и наличие тулбаров', '00203881125ab3c68165cdc79f7843a101d12af1'),
(687, 'ru', '', 'Wrong email address.', 'Неверный адрес электронной почты.', '1968b49ea2bc3402c6714ac60c8e15303e09b360'),
(688, 'ru', '', 'Wrong thread', 'Диалог не существует', '3938af1dd6c0a9680acd4bf281d6962e7b8e8173'),
(689, 'ru', '', 'Yes. I''m sure', 'Да, я уверен', 'dd1a8df73a86044824feb63546c6b058b531d07f'),
(690, 'ru', '', 'Yesterday at {0}', 'Вчера в {0}', '1abfce5989e3d5018b9eb326041259cac24ed8c6'),
(691, 'ru', '', 'You are', 'Вы', '29e324153e99e863cbd011b1243c28ba846c53e0'),
(692, 'ru', '', 'You are Offline. <a href="{0}">Connect...</a>', 'Вы Оффлайн. <a href="{0}">Подключиться..</a>', 'b0c1bcb06e2e06f8c7f647dd72fa1d0d20039e6a'),
(693, 'ru', '', 'You are Offline.<br/><a href="{0}">Connect...</a>', 'Вы Оффлайн.<br/><a href="{0}">Подключиться..</a>', '588198a6c97ba6241b2866cb918fffba2086b508'),
(694, 'ru', '', 'You are chatting with:', 'Вы общаетесь с:', '41112ea212b43ccbcc8d2a8028024faface8172f'),
(695, 'ru', '', 'You are connected to MySQL server version {0}', 'Вы подсоединены к серверу MySQL версии {0}', 'e547e39449203231de08ba1b001673a3871e4241'),
(696, 'ru', '', 'You are not allowed to change this person''s profile.', 'Вы не можете изменять профиль этого оператора.', '05ffdecf5cea6f6f4a80f5ba82d4e346ceea2362'),
(697, 'ru', '', 'You are not allowed to create operators.', 'Вы не можете создавать операторов.', '0f22d30b011fafd488b94cd7724e32e6b73f95c6'),
(698, 'ru', '', 'You are not allowed to disable operators.', 'Вы не можете блокировать операторов.', '856262c3fcfbdb08151e0566f195f1a3404c0869'),
(699, 'ru', '', 'You are not allowed to enable operators.', 'Вы не можете разблокировать операторов.', '47f66b43b321de8a0265b2c58987ee909beb8962'),
(700, 'ru', '', 'You are not allowed to remove groups.', 'Вы не можете удалять группы.', '36a3b26c35fb016c67d2c33b10476c2f528be6dd'),
(701, 'ru', '', 'You are not allowed to remove operators.', 'Вы не можете удалять операторов.', '8030a9870539cf0ed66aedce36a4ea3ef8997f77'),
(702, 'ru', '', 'You are not chatting with the visitor.', 'Вы не обслуживаете этого посетителя.', 'fd9c949f1a06eb9b90180785e13299ac0f6054f8'),
(703, 'ru', '', 'You are using:', 'Вы используете:', '5fa1e29fa71f5010ee51bce7679732c18b21265e'),
(704, 'ru', '', 'You are <a href="{0}">{1}</a>', 'Вы <a href="{0}">{1}</a>', '6e0779826bf6c187706833dfcb698e0ad817d4d9'),
(705, 'ru', '', 'You can change your personal information on this page.', 'На этой странице вы можете отредактировать свою персональную информацию.', '94795088ac582fba236d7ee1b5961646b725e0d4'),
(706, 'ru', '', 'You can create a new operator here.', 'Создание нового оператора.', '5c96555b2d32b2c124089a7817ee67650cde7691'),
(707, 'ru', '', 'You can find awaiting visitors.', 'На этой странице можно просмотреть список ожидающих ответа посетителей.', '40a68da7a35f153decf4ef87bd896b89d378ba52'),
(708, 'ru', '', 'You can find the chat history of your visitors here.', 'На данной странице Вы можете увидеть все диалоги с Вашим посетителем.', '52415e670bb7a36d5effe7395282e575caca09cd'),
(709, 'ru', '', 'You can generate HTML code to place at your site here.', 'На этой странице Вы можете получить HTML-код кнопки "Веб Мессенджера" для размещения на своем сайте.', '08bf274cded68ddc791370dfa1d8ebac249bb93e'),
(710, 'ru', '', 'You can logon as <b>admin</b> with empty password.<br/><br/><span class="warning">!!! For security reasons please change your password immediately and remove the {0} folder from your server.</span>', 'Вы можете войти в систему как <b>admin</b> с пустым паролем.<br/><br/><span class="warning">!!! В целях безопасности, удалите, пожалуйста, каталог {0} с вашего сервера и поменяйте пароль.</span>', 'b148a3b8e76aef9afa278aeb00930d06e29d9c7e'),
(711, 'ru', '', 'You can upload your photo only as JPG, GIF, PNG or TIF image files.', 'Вы можете загрузить фотографию расширения JPG, GIF, PNG или TIF.', '964d77937951683b44148638c7cc27543882158f'),
(712, 'ru', '', 'You can view the list of themes you currently have installed here.', 'Здесь вы можете посмотреть на стиль вашего сайта.', 'eb76903be7565ab5e8e79e4203b2b903ae71ef9e'),
(713, 'ru', '', 'You cannot retrieve your password, but you can set a new one by following a link sent to you by email.', 'Из соображений безопасности мы не высылаем текущий пароль, но вы можете заменить его на новый, воспользовавшись ссылкой из письма.', '0927c5a52ff0173dc9d976b09b367e10b0113c0c'),
(714, 'ru', '', 'You have selected From date after Till date', 'Вы выбрали дату для начала отчета после даты конца', 'fbb26de1c3fc03fbffd3629f4610fb341661ae7c'),
(715, 'ru', '', 'You opened this window for "{0}" thread. <i>Address</i> field is already filled. Select a number of days and click <i>Send</i>.', 'Вы открыли это окно для диалога с "{0}", поэтому поле <i>Адрес</i> уже заполнено. Выберите количество дней и нажмите <i>Отправить</i>.', 'c42d4ad7028fa1ae2e4805f67ee6c0f20bf2d73b'),
(716, 'ru', '', 'Your account is temporarily blocked. Please contact system administrator.', 'Ваша учетная запись временно заблокированна. Пожалуйста, свяжитесь с администратором системы.', '2db9a179c08469e771acc4b42347c9731c148d12'),
(717, 'ru', '', 'Your avatar image.', 'Данное изображение посетители будут видеть своем чат окне, <br/> когда будут общаться с Вами. Нажав на ссылку под изображением,<br/>Вы можете удалить аватарку.', '0e76b902f1b95992aa308ac8fc23eeaed4d3ca34'),
(718, 'ru', '', 'Your company logo', 'Лого компании', '0fd84b3244e475bd3c0f920ee02c546776830667'),
(719, 'ru', '', 'Your email', 'Ваш email', '30a36632a58efa6d7b81013375b5a2e0b0f232c0'),
(720, 'ru', '', 'Your message has been sent', 'Ваше сообщение сохранено', 'b75febb876e3342baa3dfb77fd5f33387825b5db'),
(721, 'ru', '', 'Your name', 'Ваше имя', 'cc4674c02062216ea0b4859f683a5b932c18de70'),
(722, 'ru', '', 'Your operator has connection issues. We have moved you to a priorty position in the queue. Sorry for keeping you waiting.', 'У оператора возникли проблемы со связью, мы временно перевели Вас в приоритетную очередь. Приносим извинения за Ваше ожидание.', '9ff7153418cd0e7aefb65667eff5da9984a92341'),
(723, 'ru', '', 'Your password has been changed.', 'Ваш пароль был изменен.', 'd0d6ce41eca7c2fe2dc0679335762834878fa0f9'),
(724, 'ru', '', 'Your session has expired. Please login again', 'Ваша сессия устарела, войдите, пожалуйста, снова', 'b671c53daa58769708b8ac81e613dec1840e9396'),
(725, 'ru', '', 'Your translation is saved.', 'Ваш перевод сохранен.', '41a1784faf40f5b23024d2116cad96c9ff0e5390'),
(726, 'ru', '', '[spam]', '[спам]', '91dad7590129446e28d561015363b4a15918e16a'),
(727, 'ru', '', 'ascending', 'по возрастанию', '8880e82deeabcd209ef3296d378674d3526b622a'),
(728, 'ru', '', 'button', 'кнопка', 'f25c67f158f880254285455d6b6a919ff56e80ad'),
(729, 'ru', '', 'by operator', 'по оператору', 'fc4d769a142ee9002d434f837a6ed4a508051aba'),
(730, 'ru', '', 'by visitor', 'по посетителю', '155586f817944d9a3ea51dbea279b82f4e8ff1fe'),
(731, 'ru', '', 'descending', 'по убыванию', 'c1ebcefd5893f30fc69d18fd4fc2c0bede49d78c'),
(732, 'ru', '', 'direct visit', 'прямое посещение', '5034112dbb631e41da32e0235c1111a4be280b93'),
(733, 'ru', '', 'disable', 'отключить', 'a380f8cef89c490bba6576e5e918a287275387f1'),
(734, 'ru', '', 'disabled', 'отключен', '47a5147cdc860005211813d047d1a61c20084439'),
(735, 'ru', '', 'edit', 'редактировать', 'ba3018d85dd6bb4dab0d64ea360d7fb47d0a0ad6'),
(736, 'ru', '', 'enable', 'включить', 'be0878cb5a59db5dd317e94f392c94d01e01898c'),
(737, 'ru', '', 'everywhere', 'везде', 'baab0f8f5b7b5f91ec03df0d640dad41825daba6'),
(738, 'ru', '', 'in messages', 'в сообщениях', '325d9b035a1728759dce44f02881482df1205fc7'),
(739, 'ru', '', 'mandatory fields', 'поля, обязательные для заполнения', 'a4814e295607b3c1b44bd7bff8060c173bd7be22'),
(740, 'ru', '', 'needs update', 'необходимо обновление', '22a7c91623a959d07192bcafdc3b70a396b09b95'),
(741, 'ru', '', 'next', 'следующая', 'ea825c88d09ea987702dd13be655698fda6382b3'),
(742, 'ru', '', 'not initialized', 'не инициализирован', '3c4c464ca1ead07ad617ed85a9e7125fbd6c9814'),
(743, 'ru', '', 'operator code field', 'поле для ввода кода оператора', '2092dc4682414837732388f3281b0a76d9e83a35'),
(744, 'ru', '', 'previous', 'предыдущая', '05e2d124a63415a33d28d434255ee343cfdced4d'),
(745, 'ru', '', 'remove', 'удалить', '5efdac092b0a9cf4489980d6333a2c09cbfa071a'),
(746, 'ru', '', 'text link', 'текстовая ссылка', 'dbe6c200a10caf90935c8f1e1f1042be3559d239'),
(747, 'ru', '', 'uninstall', 'удалить', 'fcfdcda8ca3417d08775d1ffd03432290d8dcbc6'),
(748, 'ru', '', 'update', 'обновить', 'bf3e5056ca2ce16e5e429612fa02998267919f36'),
(749, 'ru', '', 'without menu', 'без меню', '9ec4719a592c74eb887b55e00d727d38006a0e27'),
(750, 'ru', '', 'working', 'работает', '7796011f66074bef3eef26b7a5083bea0d35517a'),
(751, 'en', '', 'Language', 'Language', '896ae45a15bb6ab793630caeaa203c33254a7aa2'),
(752, 'en', '', 'Change locale.', 'Change locale.', 'd0f66b4532234cf6ad5c0e544313780930fd2db8'),
(753, 'en', '', 'Choose your language', 'Choose your language', '8d9a72a1a0f279588de6bc2d199cf64134acde7e'),
(754, 'ru', '', 'No file selected', 'No file selected', '9ef7f12209039582ae9549a51b082d0a4d3834b0'),
(755, 'en', '', 'No file selected', 'No file selected', '1316b9d9972dc97206350e7edb784f56b2542624'),
(756, 'en', '', 'Guest', 'Guest', '8bfdd92ba68bebc9ae27071decf0443422c953f0'),
(757, 'en', '', 'Leave your message', 'Leave your message', 'de7331b08e3941018afa4069908c74fedc29679b');

-- 
-- Вывод данных для таблицы threadstatistics
--
-- Таблица mibew.threadstatistics не содержит данных

-- 
-- Вывод данных для таблицы thread
--
INSERT INTO thread VALUES
(1, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1463394970, 0, 1463394970, 1463394970, 30, 5, 0, 4346196, '194.60.232.33', 'https://kc-ets.kz/index.php?p=contacts\nhttps://kc-ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(2, 'Посетитель', '5739a270468184.42303490', 'Administrator', 1, 1463394985, 1463395011, 1463395028, 1463395028, 64, 3, 0, 85689072, '194.60.232.33', 'https://kc-ets.kz/index.php?p=contacts\nhttps://kc-ets.kz/', 0, 'ru', 0, 1463395381, 0, 0, 6, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '3', 0),
(3, 'Посетитель', '5739a270468184.42303490', 'Administrator', 1, 1463395037, 1463395052, 1463395377, 1463395377, 141, 3, 0, 26571485, '194.60.232.33', 'https://kc-ets.kz/index.php?p=contacts\nhttps://kc-ets.kz/', 0, 'ru', 1463395387, 1463395377, 0, 0, 15, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '1', 0),
(4, 'Посетитель', '5739a270468184.42303490', 'Administrator', 1, 1463543200, 1463543206, 1463543287, 1463543287, 28266, 3, 0, 88544417, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php', 0, 'ru', 1463543290, 1463543287, 0, 0, 22, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '1', 0),
(5, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1463543964, 0, 1463543964, 1463543964, 28277, 5, 0, 37982723, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(6, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1463548736, 0, 1463548736, 1463548736, 28288, 5, 0, 33719482, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(7, 'Посетитель', '5739a270468184.42303490', 'Zhassulan Tokbayev', 2, 1463548752, 1463548771, 1463548819, 1463548819, 28333, 3, 0, 16568895, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php', 0, 'ru', 1463548822, 1463548819, 0, 0, 35, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '1', 0),
(8, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1463549102, 0, 1463549102, 1463549102, 28340, 5, 0, 93553630, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(9, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1463549385, 0, 1463549385, 1463549385, 28341, 5, 0, 93658878, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(10, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1463549438, 0, 1463549438, 1463549438, 28342, 5, 0, 58800719, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(11, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1463550253, 0, 1463550253, 1463550253, 28343, 5, 0, 57835782, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(12, 'Посетитель', '573c03a87f6401.06218843', 'Lyazzat Undirbekova', 3, 1463550888, 1463550908, 1463551041, 1463551041, 28394, 3, 0, 51279181, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', 0, 'ru', 1463551041, 0, 0, 0, 54, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36', '1', 0),
(13, 'Посетитель', '573c0602f0f000.24330070', NULL, 0, 1463551490, 0, 1463552093, 1463552093, 28750, 3, 0, 11760531, '66.249.64.83', NULL, 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', '0', 0),
(14, 'Брокер', '573c0d00db6201.63614393', NULL, 0, 1463553280, 0, 1463553977, 1463553977, 29383, 3, 0, 3053147, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/s90', 0, 'ru', 1463556794, 0, 0, 0, 61, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(15, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1463556460, 0, 1463557491, 1463557491, 30558, 3, 0, 95035271, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', 0, 'ru', 1463558066, 0, 0, 0, 65, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(16, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1463558068, 0, 1463558093, 1463558093, 30771, 3, 0, 98000730, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php', 0, 'ru', 1463558093, 0, 0, 0, 69, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '1', 0),
(17, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1463566649, 0, 1463566660, 1463566660, 32144, 3, 0, 36138136, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', 0, 'ru', 1463566660, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(18, 'Посетитель', '573d7da6908ae4.03728548', NULL, 0, 1463647654, 0, 1463647686, 1463647686, 35986, 3, 0, 65687122, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/ru/members.aspx', 0, 'ru', 1463647686, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(19, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1463649985, 0, 1463650598, 1463650598, 36960, 3, 0, 7578738, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', 0, 'ru', 1463657593, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(20, 'Посетитель', '573da3e13253a9.39663564', 'Lyazzat Undirbekova', 3, 1463657441, 1463657512, 1463709685, 1463709685, 39786, 3, 0, 27656653, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttps://www.ets.kz/', 0, 'ru', 0, 1463658621, 0, 0, 81, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(21, 'Посетитель', '5739a270468184.42303490', 'Zhass', 4, 1463713401, 1463713493, 1463714031, 1463714031, 41234, 3, 0, 5246321, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', 0, 'ru', 1463714031, 1463714045, 0, 0, 90, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '2', 0),
(22, 'Посетитель', '57428a5e389f25.06948997', NULL, 0, 1463978590, 0, 1463979193, 1463979193, 43551, 3, 0, 64425877, '89.163.148.58', NULL, 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (compatible; MJ12bot/v1.4.5; http://www.majestic12.co.uk/bot.php?+)', '0', 0),
(23, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1463981568, 0, 1463982175, 1463982175, 44443, 3, 0, 44089588, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', 0, 'ru', 1463981573, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(24, 'Посетитель', '5742d464745ea8.58052499', 'Administrator', 1, 1463997540, 1464000729, 1464002266, 1464002266, 48936, 3, 0, 33765531, '80.242.209.129', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s39', 0, 'ru', 0, 1464000746, 0, 0, 99, 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 YaBrowser/16.3.0.7146 Safari/537.36', '0', 0),
(25, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1464770838, 0, 1464771399, 1464771399, 61418, 3, 0, 2902160, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php', 0, 'ru', 1464771399, 0, 0, 0, 104, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '1', 0),
(26, 'Посетитель', '5739a270468184.42303490', 'Lyazzat Undirbekova', 3, 1464779674, 1464780184, 1464780321, 1464780321, 64983, 3, 0, 4610639, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php', 0, 'ru', 1464780321, 1464780332, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(27, 'Посетитель', '5739a270468184.42303490', NULL, 0, 1464780325, 0, 1464780335, 1464780335, 64993, 3, 0, 16620888, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php', 0, 'ru', 1464780335, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(28, 'Посетитель', '5756a5481b34f8.10245946', 'Lyazzat Undirbekova', 3, 1465296200, 1465296270, 1465296941, 1465296941, 66578, 3, 0, 12058492, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', 0, 'ru', 1465296313, 1465296340, 0, 0, 115, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36', '0', 0),
(29, 'Посетитель', '573c0d00db6201.63614393', 'Lyazzat Undirbekova', 3, 1465296407, 1465296506, 1465297195, 1465297195, 66697, 3, 0, 13078483, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php', 0, 'ru', 1465296593, 1465296573, 0, 0, 121, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:46.0) Gecko/20100101 Firefox/46.0', '0', 0),
(30, 'Посетитель', '575fb100c04759.16031792', NULL, 0, 1465889024, 0, 1465889626, 1465889626, 95814, 3, 0, 7215222, '66.249.69.195', NULL, 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', '0', 0),
(31, 'Посетитель', '575fb102641e02.83220549', NULL, 0, 1465889026, 0, 1465889629, 1465889629, 95816, 3, 0, 10166751, '66.249.66.129', NULL, 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', '0', 0),
(32, 'Посетитель', '573c0d00db6201.63614393', 'Lyazzat Undirbekova', 3, 1465962025, 1465962031, 1465963127, 1465963127, 104146, 3, 0, 6798675, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://www1.ets.kz/a55/?gd=aa3d8baa645a49b4a9a8a8b3cd58066c', 0, 'ru', 0, 1465962526, 0, 0, 131, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', '0', 0),
(33, 'Посетитель', '576383e2f381a0.33359884', 'Lyazzat Undirbekova', 3, 1466139618, 1466139796, 1466140678, 1466140678, 119190, 3, 0, 12512966, '52.23.170.193', NULL, 0, 'ru', 0, 1466140678, 0, 0, 0, 'ltx71 - (http://ltx71.com/)', '0', 0),
(34, 'Посетитель', '5767b84f28ed69.59652449', 'Lyazzat Undirbekova', 3, 1466415183, 1466415202, 1466415588, 1466415588, 137388, 3, 0, 9766281, '92.238.122.46', NULL, 0, 'ru', 0, 1466415588, 0, 0, 0, 'Mozilla/5.0 (compatible; MJ12bot/v1.4.5; http://www.majestic12.co.uk/bot.php?+)', '0', 0),
(35, 'Посетитель', '573c03a87f6401.06218843', 'Lyazzat Undirbekova', 3, 1466415602, 1466415626, 1466415654, 1466415654, 137418, 3, 0, 3038626, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', 0, 'ru', 0, 1466415791, 0, 0, 146, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36', '1', 0),
(36, 'Посетитель', '576b5d91ad1368.39515240', 'Lyazzat Undirbekova', 3, 1466654097, 1466654107, 1466655482, 1466655482, 168025, 3, 0, 12316764, '87.247.43.112', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/ru/members.aspx', 0, 'ru', 1466655572, 0, 0, 0, 155, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '6', 0),
(37, 'Посетитель', '576b5d91ad1368.39515240', 'Lyazzat Undirbekova', 3, 1466740804, 1466740856, 1466744727, 1466744727, 184122, 3, 0, 3626918, '5.34.26.235', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/ru/members.aspx', 0, 'ru', 1466744767, 0, 0, 0, 174, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '17', 0),
(38, 'Юрий', '573c0d00db6201.63614393', NULL, 0, 1470222379, 0, 1470222379, 1470222379, 216145, 5, 0, 4555298, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/ru/newslist.aspx?ncat=101', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0', '0', 0),
(39, 'Посетитель', '573c0d00db6201.63614393', 'Lyazzat Undirbekova', 3, 1470222609, 1470222629, 1470281083, 1470281083, 216216, 3, 0, 15406832, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 1470223192, 0, 0, 218, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0', '0', 0),
(40, 'Станислав', '57aab1e49d71d5.34998903', NULL, 0, 1470804694, 0, 1470804694, 1470804694, 245149, 5, 0, 8134023, '91.216.129.84', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/ru/members.aspx', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko', '0', 0),
(41, 'Канат', '57da40cdd9d032.51812638', NULL, 0, 1473921349, 0, 1473921349, 1473921349, 261361, 5, 0, 11000757, '37.150.73.75', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s219', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0', '0', 0),
(42, 'Посетитель', '5864f8f47311d0.99312741', NULL, 0, 1483012392, 0, 1483012392, 1483012392, 261362, 5, 0, 14775708, '178.90.226.23', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0', '0', 0),
(43, 'Посетитель', '5878573c87ee65.67174384', NULL, 0, 1484282530, 0, 1484282530, 1484282530, 261363, 5, 0, 5886038, '82.200.195.178', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0', '0', 0),
(44, 'Посетитель', '58a1700ca05217.81414012', NULL, 0, 1486976074, 0, 1486976074, 1486976074, 261364, 5, 0, 5773180, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '0', 0),
(45, 'Посетитель', '59031950dc43c0.72366451', NULL, 0, 1493375326, 0, 1493375326, 1493375326, 261368, 5, 0, 11118470, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', '0', 0),
(46, 'Айгерим', '597b0799b00d89.93611636', NULL, 0, 1501235352, 0, 1501235352, 1501235352, 261369, 5, 0, 923752, '212.154.140.12', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s233', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:39.0) Gecko/20100101 Firefox/39.0', '0', 0),
(47, 'Айгерим', '597b0799b00d89.93611636', NULL, 0, 1501235426, 0, 1501235426, 1501235426, 261370, 5, 0, 13479069, '212.154.140.12', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:39.0) Gecko/20100101 Firefox/39.0', '0', 0),
(48, 'Круглик Игорь Владимирович', '599be375909b60.16169835', NULL, 0, 1503388747, 0, 1503388747, 1503388747, 261371, 5, 0, 11415656, '5.251.97.14', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', '0', 0),
(49, 'Игорь', '59c4abd69badb8.93442157', NULL, 0, 1506061326, 0, 1506061326, 1506061326, 261372, 5, 0, 8403355, '89.40.193.11', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0', '0', 0),
(50, 'Посетитель', '5a867c687096a9.82881748', NULL, 0, 1518763131, 0, 1518763131, 1518763131, 261373, 5, 0, 9348475, '37.150.36.12', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', '0', 0),
(51, 'Посетитель', '5a8bf95aa2be43.74067315', NULL, 0, 1519122816, 0, 1519122816, 1519122816, 261374, 5, 0, 1201914, '77.94.9.112', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s42', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.168 Safari/537.36', '0', 0),
(52, 'Посетитель', '5aa6191317c702.08818433', NULL, 0, 1520834905, 0, 1520834905, 1520834905, 261375, 5, 0, 8082464, '212.96.87.77', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/a4329', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0', '0', 0),
(53, 'Сергей Александрович Прохоров', '5aa64f94f33fe0.48286358', NULL, 0, 1520848819, 0, 1520848819, 1520848819, 261376, 5, 0, 8385401, '178.88.55.71', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/a4133/?print=1', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '0', 0),
(54, 'Посетитель', '598d2585d2f708.81327390', NULL, 0, 1523943677, 0, 1523943677, 1523943677, 261377, 5, 0, 10133947, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '0', 0),
(55, 'Посетитель', '598d2585d2f708.81327390', NULL, 0, 1523944078, 0, 1523944078, 1523944078, 261378, 5, 0, 2616524, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '0', 0),
(56, 'Arman', '5aed82e4caa992.21760674', NULL, 0, 1525515042, 0, 1525515042, 1525515042, 261379, 5, 0, 7074824, '147.30.112.221', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '0', 0),
(57, 'Arman', '5aed82e4caa992.21760674', NULL, 0, 1525517833, 0, 1525517833, 1525517833, 261380, 5, 0, 14422514, '147.30.112.221', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '0', 0),
(58, 'Посетитель', '5b1642e82e61b1.81250773', NULL, 0, 1528185677, 0, 1528185677, 1528185677, 261381, 5, 0, 7340234, '5.76.191.120', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/a141', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '0', 0),
(59, 'Ира', '5b18df80c1ddb1.42950998', NULL, 0, 1528357038, 0, 1528357038, 1528357038, 261382, 5, 0, 9590080, '212.96.87.244', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/s114', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0', '0', 0),
(60, 'Ира', '5b18df80c1ddb1.42950998', NULL, 0, 1528357040, 0, 1528357040, 1528357040, 261383, 5, 0, 3404517, '212.96.87.244', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/s114', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0', '0', 0),
(61, 'Ира', '5b18df80c1ddb1.42950998', NULL, 0, 1528357189, 0, 1528357189, 1528357189, 261384, 5, 0, 4625320, '212.96.87.244', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/s114', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0', '0', 0),
(62, 'Посетитель', '5b39c2d0595674.70699877', NULL, 0, 1530512098, 0, 1530512098, 1530512098, 261385, 5, 0, 11367024, '149.27.4.92', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s114', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36', '0', 0),
(63, 'Valentin', '5b444523e915a4.53935959', NULL, 0, 1531200873, 0, 1531200873, 1531200873, 261386, 5, 0, 11020157, '178.155.4.215', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.1 Safari/605.1.15', '0', 0),
(64, 'Азат', '5b46de9b5d3f32.01355685', NULL, 0, 1531372734, 0, 1531372734, 1531372734, 261387, 5, 0, 1473121, '147.30.185.6', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134', '0', 0),
(65, 'Азат', '5b46de9b5d3f32.01355685', NULL, 0, 1531373585, 0, 1531373585, 1531373585, 261388, 5, 0, 16571497, '147.30.185.6', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134', '0', 0),
(66, 'Азат', '5b46de9b5d3f32.01355685', NULL, 0, 1531373588, 0, 1531373588, 1531373588, 261389, 5, 0, 15818030, '147.30.185.6', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134', '0', 0),
(67, 'Азат', '5b46de9b5d3f32.01355685', NULL, 0, 1531373591, 0, 1531373591, 1531373591, 261390, 5, 0, 3564542, '147.30.185.6', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134', '0', 0),
(68, 'Ракым', '5b99fc90a8e831.77097138', NULL, 0, 1536818342, 0, 1536818342, 1536818342, 261391, 5, 0, 6810015, '194.60.232.33', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:62.0) Gecko/20100101 Firefox/62.0', '0', 0),
(69, 'Посетитель', '5bc421b6cb3206.16591330', NULL, 0, 1539580511, 0, 1539580511, 1539580511, 261392, 5, 0, 13439003, '176.110.126.36', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s51', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 YaBrowser/18.9.1.954 Yowser/2.5 Safari/537.36', '0', 0),
(70, 'Посетитель', '5bc421b6cb3206.16591330', NULL, 0, 1539580600, 0, 1539580600, 1539580600, 261393, 5, 0, 6973042, '176.110.126.36', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s51', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 YaBrowser/18.9.1.954 Yowser/2.5 Safari/537.36', '0', 0),
(71, 'Посетитель', '5bc421b6cb3206.16591330', NULL, 0, 1539584306, 0, 1539584306, 1539584306, 261394, 5, 0, 13562906, '176.110.126.36', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s46', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 YaBrowser/18.9.1.954 Yowser/2.5 Safari/537.36', '0', 0),
(72, 'Аят', '5bee798464a189.68064585', NULL, 0, 1542355372, 0, 1542355372, 1542355372, 261395, 5, 0, 2327178, '5.76.101.97', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s68', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36 OPR/56.0.3051.99', '0', 0),
(73, 'Александра Жиронкина', '5bfe9702cd44d8.04217223', NULL, 0, 1543411550, 0, 1543411550, 1543411550, 261396, 5, 0, 2280249, '85.10.231.44', 'https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/ru/members.aspx', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36', '0', 0),
(74, 'DASDAS WWW.GOODLE.COM', '5c39e1889e3849.89861247', NULL, 0, 1547297202, 0, 1547297202, 1547297202, 261397, 5, 0, 1467399, '35.237.153.27', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '0', 0),
(75, 'DASDAS WWW.GOODLE.COM', '5c39e1889e3849.89861247', NULL, 0, 1547297233, 0, 1547297233, 1547297233, 261398, 5, 0, 16538280, '35.237.153.27', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '0', 0),
(76, 'DASDAS WWW.GOODLE.COM', '5c39e1889e3849.89861247', NULL, 0, 1547297263, 0, 1547297263, 1547297263, 261399, 5, 0, 7227799, '35.237.153.27', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '0', 0),
(77, 'Посетитель www.google.com', '5c39e1889e3849.89861247', NULL, 0, 1547297328, 0, 1547297328, 1547297328, 261400, 5, 0, 14962043, '35.237.153.27', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '0', 0),
(78, 'Илхом Жабборов', '5c448ed85b5152.20671367', NULL, 0, 1547996982, 0, 1547996982, 1547996982, 261401, 5, 0, 4156428, '84.54.114.139', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '0', 0),
(79, 'Илхом Жабборов', '5c448ed85b5152.20671367', NULL, 0, 1547997032, 0, 1547997032, 1547997032, 261402, 5, 0, 10898229, '84.54.114.139', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '0', 0),
(80, 'Илхом Жабборов', '5c448ed85b5152.20671367', NULL, 0, 1547997033, 0, 1547997033, 1547997033, 261403, 5, 0, 10765517, '84.54.114.139', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '0', 0),
(81, 'Илхом Жабборов', '5c448ed85b5152.20671367', NULL, 0, 1547997036, 0, 1547997036, 1547997036, 261404, 5, 0, 12305697, '84.54.114.139', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '0', 0),
(82, 'Илхом Жабборов', '5c448ed85b5152.20671367', NULL, 0, 1547997039, 0, 1547997039, 1547997039, 261405, 5, 0, 14999037, '84.54.114.139', 'https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '0', 0),
(83, 'Роман', '5c7e458e1d31f8.15077484', NULL, 0, 1551779404, 0, 1551779404, 1551779404, 261406, 5, 0, 1418632, '178.91.17.126', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/s51', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '0', 0),
(84, 'Роман', '5c7e458e1d31f8.15077484', NULL, 0, 1551779465, 0, 1551779465, 1551779465, 261407, 5, 0, 7867189, '178.91.17.126', 'https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/s51', 0, 'ru', 0, 0, 0, 0, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '0', 0);

-- 
-- Вывод данных для таблицы sitevisitor
--
-- Таблица mibew.sitevisitor не содержит данных

-- 
-- Вывод данных для таблицы revision
--
INSERT INTO revision VALUES
(261407);

-- 
-- Вывод данных для таблицы requestcallback
--
-- Таблица mibew.requestcallback не содержит данных

-- 
-- Вывод данных для таблицы requestbuffer
--
-- Таблица mibew.requestbuffer не содержит данных

-- 
-- Вывод данных для таблицы plugin
--
INSERT INTO plugin VALUES
(1, 'AARInnovations:TrayNotification', '1.0.0', 1, 1),
(2, 'Mibew:TitleNotification', '1.0.0', 1, 1);

-- 
-- Вывод данных для таблицы opgroup
--
-- Таблица mibew.opgroup не содержит данных

-- 
-- Вывод данных для таблицы operatortoopgroup
--
-- Таблица mibew.operatortoopgroup не содержит данных

-- 
-- Вывод данных для таблицы operatorstatistics
--
-- Таблица mibew.operatorstatistics не содержит данных

-- 
-- Вывод данных для таблицы operator
--
INSERT INTO operator VALUES
(1, 'admin', '$2y$08$6GAj8LdLdOR1WIcCGc.TkuZxZEln6i9Bqs6ZZMne7N2FA249kJzt2', 'Administrator', 'Administrator', 'support@ets.kz', 1486976179, 0, 0, '', 65535, 0, NULL, ''),
(3, 'Undirbekova', '$2y$08$Hn8JqUmavNLA7aH67Wynz.avpNNR8XVO3RZLmOc4y0QdoX7WznOHy', 'Ундирбекова Ляззат Алтаевна', 'Lyazzat Undirbekova', 'Undirbekova@ets.kz', 1471261183, 0, 0, 'files/avatar/3.jpg', 6, 0, NULL, ''),
(4, 'ztokbayev', '$2y$08$v1imPifOW5PLsyeB98k7tubkvolLW3X0ZZFHU.1pyrSP5CGUAq5ze', 'Zhass', 'Zhass', 'tokbayev@ets.kz', 1463714012, 0, 1, 'files/avatar/4.png', 0, 0, NULL, '');

-- 
-- Вывод данных для таблицы message
--
INSERT INTO message VALUES
(1, 1, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/index.php?p=contacts\nhttps://kc-ets.kz/', '', 'a:0:{}', 1463394970, NULL),
(2, 1, 3, 0, 'E-Mail: a@aa.kz', '', 'a:0:{}', 1463394970, NULL),
(3, 1, 1, 0, 'aaa', '', 'a:0:{}', 1463394970, 'Посетитель'),
(4, 2, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/index.php?p=contacts\nhttps://kc-ets.kz/', '', 'a:0:{}', 1463394985, NULL),
(5, 2, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463394985, NULL),
(6, 2, 1, 0, 'dsfsf', '', 'a:0:{}', 1463394991, 'Посетитель'),
(7, 2, 1, 0, 'fsdfdsfsdf', '', 'a:0:{}', 1463394995, 'Посетитель'),
(8, 2, 1, 0, 'wewwe', '', 'a:0:{}', 1463395002, 'Посетитель'),
(9, 2, 6, 0, 'Оператор Administrator включился в разговор', '', 'a:0:{}', 1463395011, NULL),
(10, 2, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1463395028, NULL),
(11, 3, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/index.php?p=contacts\nhttps://kc-ets.kz/', '', 'a:0:{}', 1463395037, NULL),
(12, 3, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463395037, NULL),
(13, 3, 6, 0, 'Оператор Administrator включился в разговор', '', 'a:0:{}', 1463395052, NULL),
(14, 3, 2, 1, 'ответ', '', 'a:0:{}', 1463395061, 'Administrator'),
(15, 3, 1, 0, 'привет', '', 'a:0:{}', 1463395067, 'Посетитель'),
(16, 3, 6, 0, 'Оператор Administrator покинул диалог', '', 'a:0:{}', 1463395377, NULL),
(17, 2, 6, 0, 'Оператор Administrator покинул диалог', '', 'a:0:{}', 1463395381, NULL),
(18, 3, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1463395387, NULL),
(19, 4, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php', '', 'a:0:{}', 1463543200, NULL),
(20, 4, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463543200, NULL),
(21, 4, 6, 0, 'Оператор Zhassulan Tokbayev включился в разговор', '', 'a:0:{}', 1463543206, NULL),
(22, 4, 1, 0, 'Здравствуйте\n', '', 'a:0:{}', 1463543218, 'Посетитель'),
(23, 4, 2, 2, 'Здравствуйте!', '', 'a:0:{}', 1463543228, 'Zhassulan Tokbayev'),
(24, 4, 6, 0, 'Оператор <strong>Administrator</strong> сменил оператора <strong>Zhassulan Tokbayev</strong>', '', 'a:0:{}', 1463543281, NULL),
(25, 4, 6, 0, 'Оператор Administrator покинул диалог', '', 'a:0:{}', 1463543287, NULL),
(26, 4, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1463543290, NULL),
(27, 5, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php', '', 'a:0:{}', 1463543964, NULL),
(28, 5, 3, 0, 'E-Mail: ztokbayev@gmail.com', '', 'a:0:{}', 1463543964, NULL),
(29, 5, 1, 0, 'adsadsada', '', 'a:0:{}', 1463543964, 'Посетитель'),
(30, 6, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php', '', 'a:0:{}', 1463548736, NULL),
(31, 6, 3, 0, 'E-Mail: ztokbayev@gmail.com', '', 'a:0:{}', 1463548736, NULL),
(32, 6, 1, 0, 'aaa', '', 'a:0:{}', 1463548736, 'Посетитель'),
(33, 7, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php', '', 'a:0:{}', 1463548752, NULL),
(34, 7, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463548752, NULL),
(35, 7, 1, 0, '111', '', 'a:0:{}', 1463548768, 'Посетитель'),
(36, 7, 6, 0, 'Оператор Zhassulan Tokbayev включился в разговор', '', 'a:0:{}', 1463548771, NULL),
(37, 7, 2, 2, 'dasdasd', '', 'a:0:{}', 1463548796, 'Zhassulan Tokbayev'),
(38, 7, 6, 0, 'Оператор Zhassulan Tokbayev покинул диалог', '', 'a:0:{}', 1463548819, NULL),
(39, 7, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1463548822, NULL),
(40, 8, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php', '', 'a:0:{}', 1463549102, NULL),
(41, 8, 3, 0, 'E-Mail: ztokbayev@gmail.com', '', 'a:0:{}', 1463549102, NULL),
(42, 8, 1, 0, '1122', '', 'a:0:{}', 1463549102, 'Посетитель'),
(43, 9, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php', '', 'a:0:{}', 1463549385, NULL),
(44, 9, 3, 0, 'E-Mail: ztokbayev@gmail.com', '', 'a:0:{}', 1463549385, NULL),
(45, 9, 1, 0, '12321', '', 'a:0:{}', 1463549385, 'Посетитель'),
(46, 10, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php', '', 'a:0:{}', 1463549438, NULL),
(47, 10, 3, 0, 'E-Mail: ztokbayev@gmail.com', '', 'a:0:{}', 1463549438, NULL),
(48, 10, 1, 0, '231', '', 'a:0:{}', 1463549438, 'Посетитель'),
(49, 11, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php', '', 'a:0:{}', 1463550253, NULL),
(50, 11, 3, 0, 'E-Mail: ztokbayev@gmail.com', '', 'a:0:{}', 1463550253, NULL),
(51, 11, 1, 0, '123', '', 'a:0:{}', 1463550253, 'Посетитель'),
(52, 12, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', '', 'a:0:{}', 1463550888, NULL),
(53, 12, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463550888, NULL),
(54, 12, 1, 0, 'оллолло', '', 'a:0:{}', 1463550899, 'Посетитель'),
(55, 12, 6, 0, 'Оператор Lyazzat Undirbekova включился в разговор', '', 'a:0:{}', 1463550908, NULL),
(56, 12, 5, 0, 'У оператора возникли проблемы со связью, мы временно перевели Вас в приоритетную очередь. Приносим извинения за Ваше ожидание.', '', 'a:0:{}', 1463550964, NULL),
(57, 12, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1463551041, NULL),
(58, 13, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463551490, NULL),
(59, 14, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/s90', '', 'a:0:{}', 1463553280, NULL),
(60, 14, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463553280, NULL),
(61, 14, 1, 0, 'Добрый день.\n', '', 'a:0:{}', 1463553299, 'Посетитель'),
(62, 14, 6, 0, 'Посетитель сменил имя <strong>Посетитель</strong> на <strong>Брокер</strong>', '', 'a:0:{}', 1463553334, NULL),
(63, 15, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', '', 'a:0:{}', 1463556460, NULL),
(64, 15, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463556460, NULL),
(65, 15, 1, 0, 'проверка, от Жасулана :)', '', 'a:0:{}', 1463556474, 'Посетитель'),
(66, 15, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1463558066, NULL),
(67, 16, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php', '', 'a:0:{}', 1463558068, NULL),
(68, 16, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463558068, NULL),
(69, 16, 1, 0, 'test\n', '', 'a:0:{}', 1463558072, 'Посетитель'),
(70, 16, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1463558093, NULL),
(71, 17, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', '', 'a:0:{}', 1463566649, NULL),
(72, 17, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463566649, NULL),
(73, 17, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1463566660, NULL),
(74, 18, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/ru/members.aspx', '', 'a:0:{}', 1463647654, NULL),
(75, 18, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463647654, NULL),
(76, 18, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1463647686, NULL),
(77, 19, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', '', 'a:0:{}', 1463649985, NULL),
(78, 19, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463649985, NULL),
(79, 20, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttps://www.ets.kz/', '', 'a:0:{}', 1463657441, NULL),
(80, 20, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463657441, NULL),
(81, 20, 1, 0, 'Как фотка\n', '', 'a:0:{}', 1463657458, 'Посетитель'),
(82, 20, 1, 0, 'Появится или нет у меня\n', '', 'a:0:{}', 1463657491, 'Посетитель'),
(83, 20, 6, 0, 'Оператор Lyazzat Undirbekova включился в разговор', '', 'a:0:{}', 1463657512, NULL),
(84, 20, 2, 3, '555\n', '', 'a:0:{}', 1463657516, 'Lyazzat Undirbekova'),
(85, 20, 1, 0, 'Я вижу девушку или ее часть', '', 'a:0:{}', 1463657534, 'Посетитель'),
(86, 20, 3, 0, 'Посетитель закрыл окно диалога', '', 'a:0:{}', 1463657583, NULL),
(87, 19, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1463657593, NULL),
(88, 21, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', '', 'a:0:{}', 1463713401, NULL),
(89, 21, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463713401, NULL),
(90, 21, 1, 0, 'dffd', '', 'a:0:{}', 1463713489, 'Посетитель'),
(91, 21, 6, 0, 'Оператор Zhass включился в разговор', '', 'a:0:{}', 1463713493, NULL),
(92, 21, 1, 0, 'dffd', '', 'a:0:{}', 1463713498, 'Посетитель'),
(93, 21, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1463714031, NULL),
(94, 22, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463978590, NULL),
(95, 23, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', '', 'a:0:{}', 1463981568, NULL),
(96, 23, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463981568, NULL),
(97, 24, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s39', '', 'a:0:{}', 1463997540, NULL),
(98, 24, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1463997540, NULL),
(99, 24, 1, 0, 'Добрый день, где можно пройти регистрацию для поставщиков?', '', 'a:0:{}', 1463997574, 'Посетитель'),
(100, 24, 6, 0, 'Оператор Administrator включился в разговор', '', 'a:0:{}', 1464000729, NULL),
(101, 24, 3, 0, 'Посетитель закрыл окно диалога', '', 'a:0:{}', 1464000572, NULL),
(102, 25, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php', '', 'a:0:{}', 1464770838, NULL),
(103, 25, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1464770838, NULL),
(104, 25, 1, 0, 'test', '', 'a:0:{}', 1464770850, 'Посетитель'),
(105, 25, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1464771399, NULL),
(106, 26, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php', '', 'a:0:{}', 1464779674, NULL),
(107, 26, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1464779674, NULL),
(108, 26, 6, 0, 'Оператор Lyazzat Undirbekova включился в разговор', '', 'a:0:{}', 1464780184, NULL),
(109, 26, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1464780321, NULL),
(110, 27, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php', '', 'a:0:{}', 1464780325, NULL),
(111, 27, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1464780325, NULL),
(112, 27, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1464780335, NULL),
(113, 28, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', '', 'a:0:{}', 1465296200, NULL),
(114, 28, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1465296200, NULL),
(115, 28, 1, 0, 'привет привет красотка', '', 'a:0:{}', 1465296208, 'Посетитель'),
(116, 28, 1, 0, 'красотка прием\n', '', 'a:0:{}', 1465296236, 'Посетитель'),
(117, 28, 6, 0, 'Оператор Lyazzat Undirbekova включился в разговор', '', 'a:0:{}', 1465296270, NULL),
(118, 28, 2, 3, 'Удачи, до свиданья!', '', 'a:0:{}', 1465296275, 'Lyazzat Undirbekova'),
(119, 29, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php', '', 'a:0:{}', 1465296407, NULL),
(120, 29, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1465296407, NULL),
(121, 29, 1, 0, 'Добрый день! Скажите как мне связаться с Юрием Анатольевичем?\n', '', 'a:0:{}', 1465296443, 'Посетитель'),
(122, 29, 6, 0, 'Оператор Lyazzat Undirbekova включился в разговор', '', 'a:0:{}', 1465296506, NULL),
(123, 29, 2, 3, 'Добрый день, Вы можете позвонить по номеру 2445555 вн. 7429\n', '', 'a:0:{}', 1465296535, 'Lyazzat Undirbekova'),
(124, 29, 1, 0, 'Спасибо большое!\n\n', '', 'a:0:{}', 1465296589, 'Посетитель'),
(125, 30, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1465889024, NULL),
(126, 31, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1465889026, NULL),
(127, 32, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www1.ets.kz/a55/?gd=aa3d8baa645a49b4a9a8a8b3cd58066c', '', 'a:0:{}', 1465962025, NULL),
(128, 32, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1465962025, NULL),
(129, 32, 6, 0, 'Оператор Lyazzat Undirbekova включился в разговор', '', 'a:0:{}', 1465962031, NULL),
(130, 32, 2, 3, 'Здравствуйте! Чем я могу Вам помочь?', '', 'a:0:{}', 1465962040, 'Lyazzat Undirbekova'),
(131, 32, 1, 0, 'Доброе утро! скажите а машины у вас продаются?\n', '', 'a:0:{}', 1465962073, 'Посетитель'),
(132, 32, 2, 3, 'Информацию о всех объявленных аукционах можно посмотреть на странице http://ets.kz/ru/auctions.aspx \n', '', 'a:0:{}', 1465962145, 'Lyazzat Undirbekova'),
(133, 32, 1, 0, 'можно еще один вопрос?\n', '', 'a:0:{}', 1465962159, 'Посетитель'),
(134, 32, 3, 0, 'Посетитель закрыл окно диалога', '', 'a:0:{}', 1465962221, NULL),
(135, 32, 2, 3, 'Да, спрашивайте.', '', 'a:0:{}', 1465962259, 'Lyazzat Undirbekova'),
(136, 33, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1466139619, NULL),
(137, 33, 6, 0, 'Оператор Lyazzat Undirbekova включился в разговор', '', 'a:0:{}', 1466139796, NULL),
(138, 33, 2, 3, 'Здравствуйте! Чем я могу Вам помочь?', '', 'a:0:{}', 1466139803, 'Lyazzat Undirbekova'),
(139, 33, 6, 0, 'Оператор Lyazzat Undirbekova покинул диалог', '', 'a:0:{}', 1466140678, NULL),
(140, 34, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1466415183, NULL),
(141, 34, 6, 0, 'Оператор Lyazzat Undirbekova включился в разговор', '', 'a:0:{}', 1466415202, NULL),
(142, 34, 2, 3, 'Здравствуйте! Чем я могу Вам помочь?', '', 'a:0:{}', 1466415212, 'Lyazzat Undirbekova'),
(143, 34, 6, 0, 'Оператор Lyazzat Undirbekova покинул диалог', '', 'a:0:{}', 1466415588, NULL),
(144, 35, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', '', 'a:0:{}', 1466415602, NULL),
(145, 35, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1466415602, NULL),
(146, 35, 1, 0, 'mll,,cv ,', '', 'a:0:{}', 1466415622, 'Посетитель'),
(147, 35, 6, 0, 'Оператор Lyazzat Undirbekova включился в разговор', '', 'a:0:{}', 1466415626, NULL),
(148, 35, 2, 3, 'Здравствуйте! Чем я могу Вам помочь?', '', 'a:0:{}', 1466415630, 'Lyazzat Undirbekova'),
(149, 35, 6, 0, 'Посетитель Посетитель покинул диалог', '', 'a:0:{}', 1466415654, NULL),
(150, 35, 6, 0, 'Оператор Lyazzat Undirbekova покинул диалог', '', 'a:0:{}', 1466415791, NULL),
(151, 36, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/ru/members.aspx', '', 'a:0:{}', 1466654097, NULL),
(152, 36, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1466654097, NULL),
(153, 36, 6, 0, 'Оператор Lyazzat Undirbekova включился в разговор', '', 'a:0:{}', 1466654107, NULL),
(154, 36, 2, 3, 'Здравствуйте! Чем я могу Вам помочь?', '', 'a:0:{}', 1466654115, 'Lyazzat Undirbekova'),
(155, 36, 1, 0, 'Добрый день. Мы хотим принять участие в объявленном тендере. Брокер-инициатора ТОО "FB Capital"\n', '', 'a:0:{}', 1466654192, 'Посетитель'),
(156, 36, 1, 0, 'вопрос такой, мы должны пользоваться услугами только данного брокера ТОО "FB Capital"?\n\n', '', 'a:0:{}', 1466654227, 'Посетитель'),
(157, 36, 2, 3, 'В случаи если ТОО "FB Capital" является брокером Инициатора, то необходимо обратиться к услугам другого брокера имеющего доступ к торгам в Секции торговли специализированными товарами. Так как согласно Типовых правил биржевой торговли брокер не может представлять интересы как Инициатора так и Поставщика.\n', '', 'a:0:{}', 1466654487, 'Lyazzat Undirbekova'),
(158, 36, 2, 3, 'Контакты брокеров опубликованы на сайте www.ets.kz  в разделе Члены биржи.', '', 'a:0:{}', 1466654527, 'Lyazzat Undirbekova'),
(159, 36, 1, 0, 'странно они нам говорят, что они могут представлять наши интересы. Даже договор прислали на оказание услуг.\n\n', '', 'a:0:{}', 1466654602, 'Посетитель'),
(160, 36, 2, 3, 'а кто является Инициатором аукциона в котором Вы хотите принять участие?', '', 'a:0:{}', 1466654665, 'Lyazzat Undirbekova'),
(161, 36, 1, 0, 'Объявление аукциона http://fs.ets.kz/f/4664/prilozhenija-43-bayken.pdf назначенного на 1 июля 2016 года. Брокер-инициатора ТОО "FB Capital". Инициатор аукциона - ТОО «Байкен-U»', '', 'a:0:{}', 1466654718, 'Посетитель'),
(162, 36, 2, 3, 'Все верно, в данном аукционе ТОО "FB Capital" представляет интересы Инициатора, соответственно он не может представлять интересы Поставщика. Предлагаю поговорить с ними для разъяснения ситуации.', '', 'a:0:{}', 1466654827, 'Lyazzat Undirbekova'),
(163, 36, 1, 0, 'хорошо, то есть мне из списка брокеров надо выбрать, кто будет представлять наши интересы ', '', 'a:0:{}', 1466654885, 'Посетитель'),
(164, 36, 2, 3, 'да из списка брокеров, кто имеет доступ именно к Секции торговли специализированными товарами. ', '', 'a:0:{}', 1466654962, 'Lyazzat Undirbekova'),
(165, 36, 1, 0, 'Мы как юр. лицо, можем получить лицензию брокерскую, чтобы участвовать без посредников?', '', 'a:0:{}', 1466655038, 'Посетитель'),
(166, 36, 3, 0, 'Посетитель закрыл окно диалога', '', 'a:0:{}', 1466655250, NULL),
(167, 36, 2, 3, 'Если Вы в форме ТОО или АО, и имеете лицензию на занятие брокерской и дилерской деятельностью, то можно подать документы для рассмотрения чтобы стать Членом нашей биржи\n', '', 'a:0:{}', 1466655395, 'Lyazzat Undirbekova'),
(168, 36, 2, 3, 'на нашем сайте в разделе !Как начать торговать" опубликована пошаговая схема и ссылки на страницу со списком необходимых документов.', '', 'a:0:{}', 1466655457, 'Lyazzat Undirbekova'),
(169, 36, 6, 0, 'Оператор Lyazzat Undirbekova покинул диалог', '', 'a:0:{}', 1466655482, NULL),
(170, 37, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/ru/members.aspx', '', 'a:0:{}', 1466740805, NULL),
(171, 37, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1466740805, NULL),
(172, 37, 6, 0, 'Оператор Lyazzat Undirbekova включился в разговор', '', 'a:0:{}', 1466740856, NULL),
(173, 37, 2, 3, 'Здравствуйте! Чем я могу Вам помочь?', '', 'a:0:{}', 1466740862, 'Lyazzat Undirbekova'),
(174, 37, 1, 0, 'Добрый день.\nУ меня вопрос, если я не успел сдать документы брокеру Заказчика, до 9.30, по причине того, что они приходят на работу к 10.00. Я могу с этим что ни будь сделать?\n\n', '', 'a:0:{}', 1466741032, 'Посетитель'),
(175, 37, 2, 3, 'Согласно регламента торгов время на подачу заявок от Поставщиков дается 4 рабочих дня, необходимо придерживаться указанных сроков, вплоть до времени указанного в нем. О каком брокере идет речь, чтобы мы могли учесть Ваше замечания касательно начала рабочего времени брокера?', '', 'a:0:{}', 1466741279, 'Lyazzat Undirbekova'),
(176, 37, 1, 0, 'ТОО FB Capital ', '', 'a:0:{}', 1466741322, 'Посетитель'),
(177, 37, 1, 0, 'Согласно регламента торгов время на подачу заявок от Поставщиков дается 4 рабочих дня. Мы получили рассылку с объявлением, о том что объявлен Аукцион  \n"do-not-reply@ets.kz" <do-not-reply@ets.kz>\nКому: undisclosed-recipients:;\n\n21 июня, 16:20\nполучается, что на подачу документов есть еще сутки по Правилом бирже, почему тогда они прием осуществляют до 24.06.2016 (09:30)?', '', 'a:0:{}', 1466741620, 'Посетитель'),
(178, 37, 2, 3, 'Вы могли бы представиться, написать какую компанию представляете и указать Ваш номер чтобы мы с Вами связались\n', '', 'a:0:{}', 1466741740, 'Lyazzat Undirbekova'),
(179, 37, 1, 0, 'ТОО "Metall Solutions Kazakhstan", наш прокер ТОО "Alma Trade KZ"\nконт. номер 8 701 761 9030, 8 /727/ 261-61-70/80', '', 'a:0:{}', 1466741850, 'Посетитель'),
(180, 37, 1, 0, 'Ким Андрей Константинович\n\n', '', 'a:0:{}', 1466741870, 'Посетитель'),
(181, 37, 2, 3, 'Андрей Константинович, прошу Вас написать письменное обращение на биржу с этой проблемой и направить на электронный адрес ets@ets.kz ', '', 'a:0:{}', 1466742053, 'Lyazzat Undirbekova'),
(182, 37, 2, 3, 'Ваши документы ведь были переданы на рассмотрение через брокера, верно?', '', 'a:0:{}', 1466742090, 'Lyazzat Undirbekova'),
(183, 37, 1, 0, 'да', '', 'a:0:{}', 1466742169, 'Посетитель'),
(184, 37, 2, 3, 'Прошу написать официальное письмо для того, чтобы разобраться в сложившейся ситуации. Спасибо.', '', 'a:0:{}', 1466742224, 'Lyazzat Undirbekova'),
(185, 37, 1, 0, 'Надо адресовать данное письмо на чье то имя ?', '', 'a:0:{}', 1466742295, 'Посетитель'),
(186, 37, 2, 3, 'на имя Председателя Правления АО "Товарная биржа "ЕТС"- Оразаев Курмет Чайморданович', '', 'a:0:{}', 1466742348, 'Lyazzat Undirbekova'),
(187, 37, 2, 3, 'прошу указать подробности когда была подача, на какой аукцион, кому было передано и т.д.', '', 'a:0:{}', 1466742416, 'Lyazzat Undirbekova'),
(188, 37, 2, 3, 'Могу ли я Вам еще чем нибудь помочь?', '', 'a:0:{}', 1466742461, 'Lyazzat Undirbekova'),
(189, 37, 1, 0, 'Еще один вопрос, чтобы понять, нарушаются ли правила биржи, где можно увидеть дату опубликования аукциона, кроме срока подачи и срока проведения аукциона нет информации.', '', 'a:0:{}', 1466742714, 'Посетитель'),
(190, 37, 2, 3, 'Следить за новостями на сайте, т.к. новость об объявлении аукциона публикуются в этот же день и рассылается по базе аккредитованных поставщиков', '', 'a:0:{}', 1466742845, 'Lyazzat Undirbekova'),
(191, 37, 2, 3, 'также можно увидеть на сайте в разделе "Аукционы" - "Объявленные аукционы" полную информацию', '', 'a:0:{}', 1466742949, 'Lyazzat Undirbekova'),
(192, 37, 1, 0, 'получается датой публикации аукциона, является день получения рассылке от адресата:  do-not-reply@ets.kz, с темой письма "Опубликованы объявления новых специализированных биржевых аукционов"', '', 'a:0:{}', 1466743052, 'Посетитель'),
(193, 37, 1, 0, '?\n', '', 'a:0:{}', 1466743057, 'Посетитель'),
(194, 37, 2, 3, 'Прежде всего когда Аукцион объявлен на стр. http://ets.kz/ru/auctions.aspx ', '', 'a:0:{}', 1466743177, 'Lyazzat Undirbekova'),
(195, 37, 2, 3, 'После выгрузки публикуется новость на сайте', '', 'a:0:{}', 1466743202, 'Lyazzat Undirbekova'),
(196, 37, 2, 3, 'и только в последнюю очередь идет рассылка по базе аккредитованных поставщкиов', '', 'a:0:{}', 1466743228, 'Lyazzat Undirbekova'),
(197, 37, 1, 0, 'Это происходит за один день?', '', 'a:0:{}', 1466743278, 'Посетитель'),
(198, 37, 2, 3, 'за новыми аукционами также следят сами брокера, в связи с чем можно договориться со своим брокером об уведомлении', '', 'a:0:{}', 1466743279, 'Lyazzat Undirbekova'),
(199, 37, 2, 3, 'Согласно Типовых правил биржевой торговли Заявки на проведение аукциона рассматриваются Биржей в течении двух рабочих дней', '', 'a:0:{}', 1466743329, 'Lyazzat Undirbekova'),
(200, 37, 2, 3, 'Публикация на сайте аукциона, новость на сайте, рассылка по базе поставщиков производится в течении дня', '', 'a:0:{}', 1466743404, 'Lyazzat Undirbekova'),
(201, 37, 1, 0, 'спасибо, со сроками определились.\nХотя может я что то упускаю, но по моим расчетам  4 рабочих дня еще не прошло.\n', '', 'a:0:{}', 1466743520, 'Посетитель'),
(202, 37, 2, 3, 'на какое число объявлен аукцион в котором Вы планируете участвовать?', '', 'a:0:{}', 1466743586, 'Lyazzat Undirbekova'),
(203, 37, 1, 0, 'Срок подачи заявок на участие в Аукционе от Претендентов Брокеру-Инициатора: до 9:30:00 24.06.2016\nСрок подачи Списка Претендентов от Брокера-Инициатора на Биржу: до 17:00 27.06.2016\nСрок внесения Гарантийного обеспечения допущенными Претендентами: до 17:00 30.06.2016\n\nДата и время проведения Аукциона: 01.07.2016 c 15:00 до 17:00', '', 'a:0:{}', 1466743666, 'Посетитель'),
(204, 37, 2, 3, 'Если говорить об аукционе который объявлен на 01 июля 2016 года, то объявление было опубликовано и разослано 21 июня 2016 года. Счет идет со дня публикации аукциона 21,22,23, и 24 последний рабочий день.', '', 'a:0:{}', 1466743963, 'Lyazzat Undirbekova'),
(205, 37, 1, 0, 'получается нарушений нет? 09:30 утра это же не полный рабочий день? тогда по моему окончательный срок подачи документов должен быть до 18:00 24.06.2016 года.', '', 'a:0:{}', 1466744181, 'Посетитель'),
(206, 37, 1, 0, 'в реалии получается есть 2 рабочих дня, на расчеты и на подготовку документов ', '', 'a:0:{}', 1466744236, 'Посетитель'),
(207, 37, 2, 3, 'Правилами Биржи ЕТС утверждено время до 17:00, не менее 4 рабочих дней, брокер Инициатора, по согласованию с Инициатором,  вправе указать любое время до 17:00', '', 'a:0:{}', 1466744406, 'Lyazzat Undirbekova'),
(208, 37, 1, 0, 'я наверное назойлив как муха или я не правильно понимаю "не менее 4 рабочих дней", так есть нарушения по срокам или нет, может нам не стоит письмо писать?', '', 'a:0:{}', 1466744522, 'Посетитель'),
(209, 37, 2, 3, 'нарушений нет, т.к. время указано четвертого рабочего дня', '', 'a:0:{}', 1466744618, 'Lyazzat Undirbekova'),
(210, 37, 1, 0, 'спасибо. ', '', 'a:0:{}', 1466744708, 'Посетитель'),
(211, 37, 2, 3, 'Удачи, до свиданья!', '', 'a:0:{}', 1466744722, 'Lyazzat Undirbekova'),
(212, 37, 6, 0, 'Оператор Lyazzat Undirbekova покинул диалог', '', 'a:0:{}', 1466744727, NULL),
(213, 38, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/ru/newslist.aspx?ncat=101', '', 'a:0:{}', 1470222380, NULL),
(214, 38, 3, 0, 'E-Mail: rymzin@ets.kz', '', 'a:0:{}', 1470222380, NULL),
(215, 38, 1, 0, 'Тест', '', 'a:0:{}', 1470222380, 'Юрий'),
(216, 39, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1470222609, NULL),
(217, 39, 4, 0, 'Пожалуйста, подождите немного, к Вам присоединится оператор..', '', 'a:0:{}', 1470222609, NULL),
(218, 39, 1, 0, 'test', '', 'a:0:{}', 1470222615, 'Посетитель'),
(219, 39, 6, 0, 'Оператор Lyazzat Undirbekova включился в разговор', '', 'a:0:{}', 1470222629, NULL),
(220, 39, 2, 3, 'ererer', '', 'a:0:{}', 1470222632, 'Lyazzat Undirbekova'),
(221, 39, 3, 0, 'Посетитель закрыл окно диалога', '', 'a:0:{}', 1470222938, NULL),
(222, 40, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/ru/members.aspx', '', 'a:0:{}', 1470804694, NULL),
(223, 40, 3, 0, 'E-Mail: sv.kovalev@sibcem.ru', '', 'a:0:{}', 1470804694, NULL),
(224, 40, 1, 0, 'Здравствуйте. Я представляю компанию, которая занимается производством и реализацией цемента. Мы находимся в России, но при этом осуществляем поставки в Республику Казахстан. В связи с этим мне хотелось бы узнать, можем ли мы участвовать в торгах на Бирже ЕТС, и что для этого нужно?', '', 'a:0:{}', 1470804694, 'Станислав'),
(225, 41, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s219', '', 'a:0:{}', 1473921349, NULL),
(226, 41, 3, 0, 'E-Mail: 8881156@mail.ru', '', 'a:0:{}', 1473921349, NULL),
(227, 41, 1, 0, 'Добрый день!\nПодскажите пжл, как мне узнать какая пшеница торгуется мягких или твердых сортов???\nНигде не описывается в торгах !!!', '', 'a:0:{}', 1473921349, 'Канат'),
(228, 42, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', '', 'a:0:{}', 1483012392, NULL),
(229, 42, 3, 0, 'E-Mail: 2207_1982@mail.ru', '', 'a:0:{}', 1483012392, NULL),
(230, 42, 1, 0, 'Добрый вечер. Можно ли на Вашем сайте узнать приблизительную цену на пшеницу 5 класса?', '', 'a:0:{}', 1483012392, 'Посетитель'),
(231, 43, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', '', 'a:0:{}', 1484282530, NULL),
(232, 43, 3, 0, 'E-Mail: azimut-em@mail.ru', '', 'a:0:{}', 1484282530, NULL),
(233, 43, 1, 0, 'Здравствуйте, подскажите как можно получить справку по цене на пшеницу 3 класса с клейковиной 23 и 24 %, с 15.10.2016 по 21.10.2016 г.?', '', 'a:0:{}', 1484282530, 'Посетитель'),
(234, 44, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', '', 'a:0:{}', 1486976074, NULL),
(235, 44, 3, 0, 'E-Mail: ztokbayev@gmail.com', '', 'a:0:{}', 1486976074, NULL),
(236, 44, 1, 0, 'test', '', 'a:0:{}', 1486976074, 'Посетитель'),
(237, 45, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', '', 'a:0:{}', 1493375326, NULL),
(238, 45, 3, 0, 'E-Mail: rymzin@ets.kz', '', 'a:0:{}', 1493375326, NULL),
(239, 45, 1, 0, '1111', '', 'a:0:{}', 1493375326, 'Посетитель'),
(240, 46, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s233', '', 'a:0:{}', 1501235352, NULL),
(241, 46, 3, 0, 'E-Mail: aygerim.711@yandx.com', '', 'a:0:{}', 1501235352, NULL),
(242, 46, 1, 0, 'Добрый день!\nМожете дать краткую информацию о том, как принять участие в торгах, в частности поставить товар компании, размещающей информацию на сайте Вашей биржи. Каким образом можно связаться с дилерами Вашей биржи и на каких условиях они выполняют работу. ', '', 'a:0:{}', 1501235352, 'Айгерим'),
(243, 47, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1501235426, NULL),
(244, 47, 3, 0, 'E-Mail: aygerim.711@yandex.com', '', 'a:0:{}', 1501235426, NULL),
(245, 47, 1, 0, 'Добрый день!\nМожете дать краткую информацию о том, как принять участие в торгах, в частности поставить товар компании, размещающей информацию на сайте Вашей биржи. Каким образом можно связаться с дилерами Вашей биржи и на каких условиях они выполняют работу. ', '', 'a:0:{}', 1501235426, 'Айгерим'),
(246, 48, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', '', 'a:0:{}', 1503388747, NULL),
(247, 48, 3, 0, 'E-Mail: lostnamillion@bk.ru', '', 'a:0:{}', 1503388747, NULL),
(248, 48, 1, 0, 'В 2015 году я проходил регистрацию на бирже: ИП "ВЭСТ", ИИН 660722301009. Прошу уточнить, могу я работать с клиентами через биржу или необходима новая регистрация?', '', 'a:0:{}', 1503388747, 'Круглик Игорь Владимирович'),
(249, 49, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', '', 'a:0:{}', 1506061326, NULL),
(250, 49, 3, 0, 'E-Mail: boykoigor88@gmail.com', '', 'a:0:{}', 1506061326, NULL),
(251, 49, 1, 0, 'Здравствуйте, я хочу участвовать в качестве поставщика на вашем портале, где можно посмотреть информацию о регистрации?', '', 'a:0:{}', 1506061326, 'Игорь'),
(252, 50, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', '', 'a:0:{}', 1518763131, NULL),
(253, 50, 3, 0, 'E-Mail: kaz_energo@inbox.ru', '', 'a:0:{}', 1518763131, NULL),
(254, 50, 1, 0, 'Добрый день', '', 'a:0:{}', 1518763131, 'Посетитель'),
(255, 51, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s42', '', 'a:0:{}', 1519122816, NULL),
(256, 51, 3, 0, 'E-Mail: khimtrust.kz@mail.ru', '', 'a:0:{}', 1519122816, NULL),
(257, 51, 1, 0, 'Добрый день! Подскажите как зарегистрировать компанию для участия в торгах?', '', 'a:0:{}', 1519122816, 'Посетитель'),
(258, 52, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/a4329', '', 'a:0:{}', 1520834905, NULL),
(259, 52, 3, 0, 'E-Mail: to1305@mail.ru', '', 'a:0:{}', 1520834905, NULL),
(260, 52, 1, 0, 'на какой адрес отправить упрощенную анкету аккредитованных поставщиков?\n', '', 'a:0:{}', 1520834905, 'Посетитель'),
(261, 53, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/a4133/?print=1', '', 'a:0:{}', 1520848819, NULL),
(262, 53, 3, 0, 'E-Mail: prohorovs@mail.ru', '', 'a:0:{}', 1520848819, NULL),
(263, 53, 1, 0, '202\t26.03.2018\tСекции торговли специализированными товарами\tАО «КРК СП с ИИ «Заречное» (237) Юридический адрес: 160712, РК, ЮКО, Отрарский р-н, Тимурский с.о., ул. Б. Момышулы, дом 51 - Перевалочная база АО СП «Заречное». Адрес офиса в г.Шымкент: ЮКО, г. Шымкент, Абайский р-он, м-н Самал 1, ул. Рыскулова д.51 Тел.: 8(7252) 99-73-66 РНН 582100024815 БИН 030140000870 ИИК KZ7383201T0250192002 АО "Ситибанк Казахстан" БИК CITIKZKA\tFIVE\tКонтрольно-измерительные приборы / DDP Рудник ПСВ\tЛот № 1 0G77399\t5 560 800\tНедропользователи\tНа понижение\tДвухэтапный (8 дней)\t0,10\t14.03.2018 09:30\t20.03.2018\t0\tБез участия ТОО "Клиринговый центр ЕТС"\t15:00 – 16:00\t16:30 – 17:00\t', '', 'a:0:{}', 1520848819, 'Сергей Александрович Прохоров'),
(264, 54, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1523943678, NULL),
(265, 54, 3, 0, 'E-Mail: ungmar@yandex.ru', '', 'a:0:{}', 1523943678, NULL),
(266, 54, 1, 0, 'Сколько стоила пшеница 3 класса 24 февраля', '', 'a:0:{}', 1523943678, 'Посетитель'),
(267, 55, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1523944078, NULL),
(268, 55, 3, 0, 'E-Mail: ungmar@yandex.ru', '', 'a:0:{}', 1523944078, NULL),
(269, 55, 1, 0, 'Сколько стоила пшеница 3 класса 24 февраля', '', 'a:0:{}', 1523944078, 'Посетитель'),
(270, 56, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', '', 'a:0:{}', 1525515042, NULL),
(271, 56, 3, 0, 'E-Mail: tvoydom.zakaz@gmail.com', '', 'a:0:{}', 1525515042, NULL),
(272, 56, 1, 0, 'Здравствуйте! Хочу участвовать на торгах, что мне для этого необходимо? ', '', 'a:0:{}', 1525515042, 'Arman'),
(273, 57, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', '', 'a:0:{}', 1525517833, NULL),
(274, 57, 3, 0, 'E-Mail: tvoydom.zakaz@gmail.com', '', 'a:0:{}', 1525517833, NULL),
(275, 57, 1, 0, 'Здравствуйте! Хочу участвовать на торгах, что мне для этого необходимо? ', '', 'a:0:{}', 1525517833, 'Arman'),
(276, 58, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/a141', '', 'a:0:{}', 1528185677, NULL),
(277, 58, 3, 0, 'E-Mail: kon_a@list.ru', '', 'a:0:{}', 1528185677, NULL),
(278, 58, 1, 0, 'добрый день, сегодня увидел на вашей бирже объявления по поставке товаров на казминералс. подскажите как можно зарегистрироваться чтобы участвовать в аукционе? или можно работать только через брокера? ', '', 'a:0:{}', 1528185677, 'Посетитель'),
(279, 59, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/s114', '', 'a:0:{}', 1528357038, NULL),
(280, 59, 3, 0, 'E-Mail: to1305@mail.ru', '', 'a:0:{}', 1528357038, NULL),
(281, 59, 1, 0, 'Рассылки последнее время мне не приходят с биржи do-not-reply@ets.kz <do-not-reply@ets.kz>..есть мой адрес в списках? Я регистрировалась.\nТоргуем через брокера, но рассылки нужны для просмотра все равно. Вот брокер недавно сменился, заявка вышла, а нас никто не предупредил...и рассылки не было', '', 'a:0:{}', 1528357038, 'Ира'),
(282, 60, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/s114', '', 'a:0:{}', 1528357040, NULL),
(283, 60, 3, 0, 'E-Mail: to1305@mail.ru', '', 'a:0:{}', 1528357040, NULL),
(284, 60, 1, 0, 'Рассылки последнее время мне не приходят с биржи do-not-reply@ets.kz <do-not-reply@ets.kz>..есть мой адрес в списках? Я регистрировалась.\nТоргуем через брокера, но рассылки нужны для просмотра все равно. Вот брокер недавно сменился, заявка вышла, а нас никто не предупредил...и рассылки не было', '', 'a:0:{}', 1528357040, 'Ира'),
(285, 61, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/s114', '', 'a:0:{}', 1528357189, NULL),
(286, 61, 3, 0, 'E-Mail: to1305@mail.ru', '', 'a:0:{}', 1528357189, NULL),
(287, 61, 1, 0, 'Рассылки последнее время мне не приходят с биржи do-not-reply@ets.kz <do-not-reply@ets.kz>..есть мой адрес в списках? Я регистрировалась.\nТоргуем через брокера, но рассылки нужны для просмотра все равно. Вот брокер недавно сменился, заявка вышла, а нас никто не предупредил...и рассылки не было', '', 'a:0:{}', 1528357189, 'Ира'),
(288, 62, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s114', '', 'a:0:{}', 1530512098, NULL),
(289, 62, 3, 0, 'E-Mail: kerimbaev92@bk.ru', '', 'a:0:{}', 1530512098, NULL),
(290, 62, 1, 0, 'Салем', '', 'a:0:{}', 1530512098, 'Посетитель'),
(291, 63, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/', '', 'a:0:{}', 1531200873, NULL),
(292, 63, 3, 0, 'E-Mail: vk@hommal.ru', '', 'a:0:{}', 1531200873, NULL),
(293, 63, 1, 0, 'Может ли российская копания осуществлять поставки через Вашу биржу? Если Да, то что для этого надо?', '', 'a:0:{}', 1531200873, 'Valentin'),
(294, 64, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', '', 'a:0:{}', 1531372734, NULL),
(295, 64, 3, 0, 'E-Mail: Azat.Gabbassov@layher.com', '', 'a:0:{}', 1531372734, NULL),
(296, 64, 1, 0, 'Добрый день!\n\nМЫ недавно зарегистрировались у вас на сайте, чтобы получать рассылку о лотах.\n\nДля участия на аукционе как поставщику, что необходимо нам знать, также просим подсказать последовательность действии.\n\nСпасибо!\n', '', 'a:0:{}', 1531372734, 'Азат'),
(297, 65, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', '', 'a:0:{}', 1531373585, NULL),
(298, 65, 3, 0, 'E-Mail: Azat.Gabbassov@layher.com', '', 'a:0:{}', 1531373585, NULL),
(299, 65, 1, 0, 'Добрый день!\n\nМЫ недавно зарегистрировались у вас на сайте, чтобы получать рассылку о лотах.\n\nДля участия на аукционе как поставщику, что необходимо нам знать, также просим подсказать последовательность действии.\n\nСпасибо!\n', '', 'a:0:{}', 1531373585, 'Азат'),
(300, 66, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', '', 'a:0:{}', 1531373588, NULL),
(301, 66, 3, 0, 'E-Mail: Azat.Gabbassov@layher.com', '', 'a:0:{}', 1531373588, NULL),
(302, 66, 1, 0, 'Добрый день!\n\nМЫ недавно зарегистрировались у вас на сайте, чтобы получать рассылку о лотах.\n\nДля участия на аукционе как поставщику, что необходимо нам знать, также просим подсказать последовательность действии.\n\nСпасибо!\n', '', 'a:0:{}', 1531373588, 'Азат'),
(303, 67, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/', '', 'a:0:{}', 1531373591, NULL),
(304, 67, 3, 0, 'E-Mail: Azat.Gabbassov@layher.com', '', 'a:0:{}', 1531373591, NULL),
(305, 67, 1, 0, 'Добрый день!\n\nМЫ недавно зарегистрировались у вас на сайте, чтобы получать рассылку о лотах.\n\nДля участия на аукционе как поставщику, что необходимо нам знать, также просим подсказать последовательность действии.\n\nСпасибо!\n', '', 'a:0:{}', 1531373591, 'Азат'),
(306, 68, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1536818342, NULL),
(307, 68, 3, 0, 'E-Mail: sagadi@ets.kz', '', 'a:0:{}', 1536818342, NULL),
(308, 68, 1, 0, 'Мая Вы на связи?', '', 'a:0:{}', 1536818342, 'Ракым'),
(309, 69, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s51', '', 'a:0:{}', 1539580511, NULL),
(310, 69, 3, 0, 'E-Mail: e_7_a@mail.ru', '', 'a:0:{}', 1539580511, NULL),
(311, 69, 1, 0, 'Добрый день. наше ИП хотело бы участвовать в объявленных торгах компании Казминералс. Работали через портал государственных закупок и тендер ск. Можете объяснить как правильно зарегистрироваться у вас? кто такой биржевый брокер? или стать членом биржи?', '', 'a:0:{}', 1539580511, 'Посетитель'),
(312, 70, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s51', '', 'a:0:{}', 1539580600, NULL),
(313, 70, 3, 0, 'E-Mail: e_7_a@mail.ru', '', 'a:0:{}', 1539580600, NULL),
(314, 70, 1, 0, 'Добрый день. наше ИП хотело бы участвовать в объявленных торгах компании Казминералс. Работали через портал государственных закупок и тендер ск. Можете объяснить как правильно зарегистрироваться у вас? кто такой биржевый брокер? или стать членом биржи?', '', 'a:0:{}', 1539580600, 'Посетитель'),
(315, 71, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s46', '', 'a:0:{}', 1539584306, NULL),
(316, 71, 3, 0, 'E-Mail: e_7_a@mail.ru', '', 'a:0:{}', 1539584306, NULL),
(317, 71, 1, 0, 'Добрый день', '', 'a:0:{}', 1539584306, 'Посетитель'),
(318, 72, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/s68', '', 'a:0:{}', 1542355372, NULL),
(319, 72, 3, 0, 'E-Mail: zan-lex@yandex.kz', '', 'a:0:{}', 1542355372, NULL),
(320, 72, 1, 0, 'Добрый день. Перезвоните 8-777-607-77-79', '', 'a:0:{}', 1542355372, 'Аят'),
(321, 73, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://www.ets.kz/ru/members.aspx', '', 'a:0:{}', 1543411550, NULL),
(322, 73, 3, 0, 'E-Mail: 134@promsouz.com', '', 'a:0:{}', 1543411550, NULL),
(323, 73, 1, 0, 'Мы компания из России, хотел узнать, как участвовать у Вас на бирже.', '', 'a:0:{}', 1543411550, 'Александра Жиронкина'),
(324, 74, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1547297202, NULL),
(325, 74, 3, 0, 'E-Mail: xepavi@2mailnext.com', '', 'a:0:{}', 1547297202, NULL),
(326, 74, 1, 0, 'SFSDFGZSDXVFFZXDASXDZFCZDXFASFSXZ DXCFSDZFSADF', '', 'a:0:{}', 1547297202, 'DASDAS WWW.GOODLE.COM'),
(327, 75, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1547297233, NULL),
(328, 75, 3, 0, 'E-Mail: xepavi@2mailnext.com', '', 'a:0:{}', 1547297233, NULL),
(329, 75, 1, 0, 'SFSDFGZSDXVFFZXDASXDZFCZDXFASFSXZ DXCFSDZFSADF', '', 'a:0:{}', 1547297233, 'DASDAS WWW.GOODLE.COM'),
(330, 76, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1547297263, NULL),
(331, 76, 3, 0, 'E-Mail: xepavi@2mailnext.com', '', 'a:0:{}', 1547297263, NULL),
(332, 76, 1, 0, 'SFSDFGZSDXVFFZXDASXDZFCZDXFASFSXZ DXCFSDZFSADF', '', 'a:0:{}', 1547297263, 'DASDAS WWW.GOODLE.COM'),
(333, 77, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1547297328, NULL),
(334, 77, 3, 0, 'E-Mail: xepavi@2mailnext.com', '', 'a:0:{}', 1547297328, NULL),
(335, 77, 1, 0, 'sdfsdfasdfasdfsadfasd', '', 'a:0:{}', 1547297328, 'Посетитель www.google.com'),
(336, 78, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1547996982, NULL),
(337, 78, 3, 0, 'E-Mail: bk4495@uzrtsb.uz', '', 'a:0:{}', 1547996982, NULL),
(338, 78, 1, 0, 'пшеница керак\n+99897 348 48 48', '', 'a:0:{}', 1547996982, 'Илхом Жабборов'),
(339, 79, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1547997032, NULL),
(340, 79, 3, 0, 'E-Mail: bk4495@uzrtsb.uz', '', 'a:0:{}', 1547997032, NULL),
(341, 79, 1, 0, 'пшеница керак\n+99897 348 48 48', '', 'a:0:{}', 1547997032, 'Илхом Жабборов'),
(342, 80, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1547997033, NULL),
(343, 80, 3, 0, 'E-Mail: bk4495@uzrtsb.uz', '', 'a:0:{}', 1547997033, NULL),
(344, 80, 1, 0, 'пшеница керак\n+99897 348 48 48', '', 'a:0:{}', 1547997033, 'Илхом Жабборов'),
(345, 81, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1547997036, NULL),
(346, 81, 3, 0, 'E-Mail: bk4495@uzrtsb.uz', '', 'a:0:{}', 1547997036, NULL),
(347, 81, 1, 0, 'пшеница керак\n+99897 348 48 48', '', 'a:0:{}', 1547997036, 'Илхом Жабборов'),
(348, 82, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php?p=sent\nhttps://kc-ets.kz/post_qanda_ets.php', '', 'a:0:{}', 1547997039, NULL),
(349, 82, 3, 0, 'E-Mail: bk4495@uzrtsb.uz', '', 'a:0:{}', 1547997039, NULL),
(350, 82, 1, 0, 'пшеница керак\n+99897 348 48 48', '', 'a:0:{}', 1547997039, 'Илхом Жабборов'),
(351, 83, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/s51', '', 'a:0:{}', 1551779404, NULL),
(352, 83, 3, 0, 'E-Mail: oskemen1@urs.russvet.ru', '', 'a:0:{}', 1551779404, NULL),
(353, 83, 1, 0, 'Добрый день, на сайте в разделе С чего начать? есть действие - Внести биржевое обеспечение при аукционных торгах в Клиринговый центр ЕТС. Хотелось бы получить подробную информацию о данном действии. Прошу по возможности дать ответ в указанный электронный адрес или связаться со мной по контактному телефону 8-705-913-96-86.', '', 'a:0:{}', 1551779404, 'Роман'),
(354, 84, 3, 0, 'Посетитель пришел со страницы https://kc-ets.kz/qanda_ets.php\nhttp://ets.kz/s51', '', 'a:0:{}', 1551779465, NULL),
(355, 84, 3, 0, 'E-Mail: oskemen1@urs.russvet.ru', '', 'a:0:{}', 1551779465, NULL),
(356, 84, 1, 0, 'Добрый день, на сайте в разделе С чего начать? есть действие - Внести биржевое обеспечение при аукционных торгах в Клиринговый центр ЕТС. Хотелось бы получить подробную информацию о данном действии. Прошу по возможности дать ответ в указанный электронный адрес или связаться со мной по контактному телефону 8-705-913-96-86.', '', 'a:0:{}', 1551779465, 'Роман');

-- 
-- Вывод данных для таблицы mailtemplate
--
INSERT INTO mailtemplate VALUES
(1, 'en', 'user_history', 'Mibew: dialog history', 'Hello {0}!\n\nYour chat history: \n\n{1}\n--- \nRegards,\n{2} and Mibew\n{3}'),
(2, 'en', 'password_recovery', 'Reset your Mibew password', 'Hi, {0}\n\nPlease click on the link below or copy and paste the URL into your browser:\n{1}\n\nThis will let you choose another password.\n\nRegards,\nMibew'),
(3, 'en', 'leave_message', 'Question from {0}', 'Your have a message from {0}:\n\n{2}\n\nHis email: {1}\n{3}\n--- \nRegards,\nMibew'),
(4, 'ru', 'user_history', 'Мессенджер: история диалога', 'Здраствуйте, {0}!\n\nПо Вашему запросу, высылаем историю диалога с менеджером компании {2}: \n\n{1}\n--- \nС уважением,\n{2} и Mibew Мессенджер\n{3}'),
(5, 'ru', 'password_recovery', 'Сброс вашего пароля от Mibew', 'Здравствуйте, {0}\n\nПожалуйста перейдите по ссылке, расположенной ниже, или скопируйте URL в адресную строку вашего браузера:\n{1}\n\nЭто позволит вам выбрать другой пароль.\n\nС уважением,\nMibew'),
(6, 'ru', 'leave_message', 'Вопрос от {0}', 'Ваш посетитель ''{0}'' оставил сообщение:\n\n{2}\n\nЕmail: {1}\n{3}\n--- \nС уважением,\nВаш Веб Мессенджер');

-- 
-- Вывод данных для таблицы locale
--
INSERT INTO locale VALUES
(1, 'en', 'English', 1, 0, 'en_US', 'a:3:{s:4:"full";s:18:"%B %d, %Y %I:%M %p";s:4:"date";s:9:"%B %d, %Y";s:4:"time";s:8:"%I:%M %p";}'),
(2, 'ru', 'Русский', 1, 0, 'ru_RU.UTF8', 'a:3:{s:4:"full";s:15:"%d %B %Y, %H:%M";s:4:"date";s:8:"%d %B %Y";s:4:"time";s:5:"%H:%M";}');

-- 
-- Вывод данных для таблицы config
--
INSERT INTO config VALUES
(1, 'dbversion', '2.1.0'),
(2, '_instance_id', 'd1ba4851443038105917532cacf2f66d24f3eb7f7821f524b96becbb03d0c519'),
(3, '_threads_close_old_lock_time', '0'),
(4, 'email', 'support@ets.kz'),
(5, 'title', 'АО "Товарная биржа ЕТС"'),
(6, 'logo', 'https://kc-ets.kz/img/ets_logo_small.jpg'),
(7, 'hosturl', 'www.kc-ets.kz'),
(8, 'usernamepattern', '{name}'),
(9, 'chattitle', 'АО "Товарная биржа ЕТС"'),
(10, 'geolink', 'http://api.hostip.info/get_html.php?ip={ip}'),
(11, 'geolinkparams', 'width=440,height=100,toolbar=0,scrollbars=0,location=0,status=1,menubar=0,resizable=1'),
(12, 'cron_key', 'ee43e6e7c604b75f6fe53d05c89e173b'),
(13, 'sendmessagekey', 'center'),
(14, 'left_messages_locale', 'ru'),
(15, 'chat_style', 'default'),
(16, 'page_style', 'default'),
(17, '_last_cron_run', '1463394723'),
(18, 'enableban', '0'),
(19, 'usercanchangename', '1'),
(20, 'enablegroups', '0'),
(21, 'enablegroupsisolation', '0'),
(22, 'enablestatistics', '1'),
(23, 'enabletracking', '0'),
(24, 'enablessl', '0'),
(25, 'forcessl', '0'),
(26, 'enablepresurvey', '0'),
(27, 'surveyaskmail', '0'),
(28, 'surveyaskgroup', '0'),
(29, 'surveyaskmessage', '0'),
(30, 'enablepopupnotification', '1'),
(31, 'showonlineoperators', '0'),
(32, 'enablecaptcha', '0'),
(33, 'trackoperators', '0'),
(34, 'autocheckupdates', '1'),
(35, 'online_timeout', '30'),
(36, 'connection_timeout', '30'),
(37, 'updatefrequency_operator', '2'),
(38, 'updatefrequency_chat', '2'),
(39, 'max_connections_from_one_host', '0'),
(40, 'thread_lifetime', '600'),
(41, 'max_uploaded_file_size', '100000');

-- 
-- Вывод данных для таблицы cannedmessage
--
INSERT INTO cannedmessage VALUES
(1, 'en', NULL, 'Hello. How may I help you?', 'Hello. How may I help you?'),
(2, 'en', NULL, 'Hello! Welcome to our support. How may I help you?', 'Hello! Welcome to our support. How may I help you?'),
(3, 'ru', NULL, 'Здравствуйте! Чем я могу Вам помочь?', 'Здравствуйте! Чем я могу Вам помочь?'),
(4, 'ru', NULL, 'Подождите секунду, я переключу Вас на другого...', 'Подождите секунду, я переключу Вас на другого оператора.'),
(5, 'ru', NULL, 'Вы не могли бы уточнить, что Вы имеете ввиду...', 'Вы не могли бы уточнить, что Вы имеете ввиду...'),
(6, 'ru', NULL, 'Удачи, до свиданья!', 'Удачи, до свиданья!');

-- 
-- Вывод данных для таблицы ban
--
-- Таблица mibew.ban не содержит данных

-- 
-- Вывод данных для таблицы availableupdate
--
-- Таблица mibew.availableupdate не содержит данных

-- 
-- Восстановить предыдущий режим SQL (SQL mode)
-- 
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;

-- 
-- Включение внешних ключей
-- 
/*!40014 SET FOREIGN_KEY_CHECKS = @OLD_FOREIGN_KEY_CHECKS */;